# Patch 4: Videos im Dashboard ansehen + herunterladen
from pathlib import Path
d = Path('dashboard.py'); s = d.read_text(encoding='utf-8')

if '/video/' not in s:
    # Backend: Video ausliefern (mit Range-Support fuers Streamen)
    s = s.replace('''        elif pfad.startswith("/bild/"):''',
'''        elif pfad.startswith("/video/"):
            from urllib.parse import unquote
            name = unquote(pfad.split("/video/", 1)[1])
            ziel = ORDNER_VIDEOS / name / "video.mp4"
            if not ziel.exists():
                self.send_response(404); self.end_headers(); return
            groesse = ziel.stat().st_size
            bereich = self.headers.get("Range")
            with open(ziel, "rb") as f:
                if bereich and bereich.startswith("bytes="):
                    teile = bereich.replace("bytes=", "").split("-")
                    von = int(teile[0]) if teile[0] else 0
                    bis = int(teile[1]) if len(teile) > 1 and teile[1] else groesse - 1
                    bis = min(bis, groesse - 1)
                    f.seek(von)
                    daten = f.read(bis - von + 1)
                    self.send_response(206)
                    self.send_header("Content-Range", f"bytes {von}-{bis}/{groesse}")
                    self.send_header("Accept-Ranges", "bytes")
                    self.send_header("Content-Type", "video/mp4")
                    self.send_header("Content-Length", str(len(daten)))
                    self.end_headers()
                    self.wfile.write(daten)
                else:
                    self.send_response(200)
                    self.send_header("Content-Type", "video/mp4")
                    self.send_header("Content-Length", str(groesse))
                    self.send_header("Accept-Ranges", "bytes")
                    self.end_headers()
                    while True:
                        stueck = f.read(65536)
                        if not stueck:
                            break
                        self.wfile.write(stueck)

        elif pfad.startswith("/texte/"):
            from urllib.parse import unquote
            name = unquote(pfad.split("/texte/", 1)[1])
            ziel = ORDNER_VIDEOS / name / "texte.txt"
            if ziel.exists():
                self._sende(ziel.read_text(encoding="utf-8"), "text/plain")
            else:
                self.send_response(404); self.end_headers()

        elif pfad.startswith("/bild/"):''')

    # Frontend: Play-Button + Texte-Button pro Video
    alt = """    if(vidFrage===v.ordner){"""
    neu = """    if(v.fertig){
      h+='<button class="chip" style="margin:0" onclick="zeigVideo(\\''+v.ordner+'\\')">&#9654;</button>';
    }
    if(vidFrage===v.ordner){"""
    s = s.replace(alt, neu)

    # Video-Anzeige Funktion
    s = s.replace("function vidWeg(o){",
"""function zeigVideo(o){
  var alt=document.getElementById('vidbox');
  if(alt)alt.remove();
  var box=document.createElement('div');
  box.id='vidbox';
  box.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.92);z-index:200;display:flex;flex-direction:column;padding:12px;overflow:auto';
  box.innerHTML='<div style="display:flex;gap:8px;margin-bottom:10px">'
    +'<button class="chip" style="margin:0;background:#fff" onclick="document.getElementById(\\'vidbox\\').remove()">Schliessen</button>'
    +'<a class="chip" style="margin:0;background:#fff;text-decoration:none;display:inline-block" href="/video/'+o+'" download>Herunterladen</a>'
    +'<button class="chip" style="margin:0;background:#fff" onclick="zeigTexte(\\''+o+'\\')">Texte</button>'
    +'</div>'
    +'<video controls autoplay playsinline style="width:100%;max-height:60vh;background:#000;border-radius:10px" src="/video/'+o+'"></video>'
    +'<div id="txtbox" style="color:#fff;font-size:12px;white-space:pre-wrap;margin-top:12px;line-height:1.6"></div>';
  document.body.appendChild(box);
}
function zeigTexte(o){
  fetch('/texte/'+o).then(function(r){return r.text()}).then(function(t){
    document.getElementById('txtbox').textContent=t;
  });
}
function vidWeg(o){""")

    d.write_text(s, encoding='utf-8')
    print("dashboard.py: Video-Player + Download + Texte eingebaut")
else:
    print("schon vorhanden")
print("FERTIG")
