# ============================================
# Patch 22: Preis richtet sich nach dem aktiven Modell
# ============================================
from pathlib import Path

# ---------- 1. Preistabelle in einstellungen.py ----------
p = Path('einstellungen.py')
s = p.read_text(encoding='utf-8')

if 'PREISE' not in s:
    tabelle = '''
# Preise in Euro. Bei Bedarf hier anpassen.
# bild = pro Bild, stimme = pro Minute, text = pro Video, musik = pro Stueck
PREISE = {
    "bilder": {
        "flux/schnell":     0.003,
        "flux/dev":         0.025,
        "flux-pro/v1.1":    0.045,
        "flux-pro":         0.055,
        "recraft-v3":       0.045,
        "nano-banana":      0.035,
        "_standard":        0.04,
    },
    "stimme": {
        "elevenlabs":       0.18,
        "playht":           0.12,
        "_standard":        0.18,
    },
    "text": {
        "anthropic":        0.05,
        "_standard":        0.05,
    },
    "musik": {
        "stable-audio":     0.05,
        "_standard":        0.05,
    },
    "video": {
        "kling":            0.030,
        "veo":              0.180,
        "_standard":        0.050,
    },
}


def preis_fuer(kanal, slot):
    """Preis pro Einheit fuer die aktive AI dieses Slots."""
    tab = PREISE.get(slot, {})
    api = aktive_api(kanal, slot)
    if not api:
        return 0.0
    kennung = (api.get("url", "") + " " + api.get("name", "")).lower()
    for muster, wert in tab.items():
        if muster != "_standard" and muster in kennung:
            return wert
    return tab.get("_standard", 0.0)

'''
    s = s.replace('def laenge_in_minuten(k):', tabelle + '\ndef laenge_in_minuten(k):', 1)
    p.write_text(s, encoding='utf-8')
    print("1. Preistabelle angelegt")
else:
    print("1. Preistabelle: schon da")

# ---------- 2. Preise ans Dashboard liefern ----------
p = Path('dashboard.py')
s = p.read_text(encoding='utf-8')

if '"preise"' not in s:
    s = s.replace('''                "sprachen": einstellungen.SPRACHEN_LISTE,''',
'''                "sprachen": einstellungen.SPRACHEN_LISTE,
                "preise": {kid: {
                    "bild": einstellungen.preis_fuer(k, "bilder"),
                    "stimme": einstellungen.preis_fuer(k, "stimme"),
                    "text": einstellungen.preis_fuer(k, "text"),
                    "musik": einstellungen.preis_fuer(k, "musik"),
                    "bildname": (einstellungen.aktive_api(k, "bilder") or {}).get("name", "?"),
                } for kid, k in alle.items()},''')
    print("2. Preise werden ans Dashboard geliefert")

# ---------- 3. Kostenrechnung im Dashboard ----------
if 'preise[kid]' not in s:
    alt_start = s.find('function kostenText(k){')
    alt_ende = s.find('}', s.find('return zeit', alt_start)) + 1
    if alt_start > 0 and alt_ende > alt_start:
        neu = '''function kostenText(k, kid){
  var m = minuten(k), b = anzahlBilder(k);
  var pr = (D.preise && D.preise[kid]) ? D.preise[kid] : {bild:0.04, stimme:0.18, text:0.05, musik:0.05, bildname:'?'};
  var musikNoetig = (k.musik_an !== false) &&
                    !((D.musikdateien && D.musikdateien[kid] || []).some(function(x){return x.aktiv}));
  var euro = b * pr.bild + m * pr.stimme + pr.text + (musikNoetig ? pr.musik : 0);
  var zeit = (k.laenge_einheit === 'Sek') ? (k.laenge + ' Sek') : (k.laenge + ' Min');
  return zeit + ', ' + b + ' Bilder (' + pr.bildname + '), ca. ' + euro.toFixed(2) + ' EUR';
}'''
        s = s[:alt_start] + neu + s[alt_ende:]
        # alle Aufrufe mit kid versorgen
        s = s.replace('kostenText(k)', 'kostenText(k, kid)')
        s = s.replace("kostenText(k, kid).split('ca. ')[1]", "kostenText(k, kid).split('ca. ')[1]")
        print("3. Kostenrechnung nutzt jetzt das aktive Modell")
    else:
        print("3. WARNUNG: kostenText nicht gefunden")
else:
    print("3. Kostenrechnung: schon angepasst")

p.write_text(s, encoding='utf-8')
print("FERTIG - Seite neu laden")
