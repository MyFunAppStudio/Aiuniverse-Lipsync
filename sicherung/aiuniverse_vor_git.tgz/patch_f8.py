import os, re, shutil, subprocess, sys
BASIS = "/root/aiuniverse"
NEU = ("Das SKRIPT hat genau {anzahl_bilder} Szenen. Jede Szene ist EIN gesprochener "
       "Satz mit {max(4, int(laenge*60*1.8/max(1,anzahl_bilder)))} bis "
       "{max(6, int(laenge*60*1.8/max(1,anzahl_bilder))+3)} Woertern. "
       "Insgesamt rund {int(laenge*60*1.8)} Woerter. "
       "Zaehle die Woerter mit und halte dich exakt daran. "
       "Lieber etwas kuerzer als laenger!")
p = os.path.join(BASIS, "text_generator.py")
t = open(p, encoding="utf-8").read()
if not os.path.exists(p + ".bak_f8"):
    shutil.copy2(p, p + ".bak_f8")
if "Zaehle die Woerter mit" in t:
    print("INFO  Wortvorgabe war schon drin")
else:
    t, n = re.subn(r"Das SKRIPT muss daher ca\..*?daran!", NEU, t, count=1)
    print("OK    Wortvorgabe eingebaut" if n else "ACHT  Stelle im Prompt nicht gefunden")
if "_lb_ziel_sek" in t:
    t = t.replace("grenze = int(budget * 1.15)", "grenze = int(budget * 1.25)")
    t = t.replace("if len(_lb_text(sz)) > grenze:", "if len(_lb_text(sz)) > int(budget * 1.6):")
    print("OK    Notbremse entschaerft")
else:
    print("INFO  Keine Laengenbremse vorhanden - nur Prompt geaendert")
open(p, "w", encoding="utf-8").write(t)
r = subprocess.run([sys.executable, "-m", "py_compile", p], capture_output=True, text=True)
if r.returncode:
    shutil.copy2(p + ".bak_f8", p)
    print("ACHT  Syntaxfehler, zurueckgesetzt:", r.stderr[-200:])
else:
    for s in (15, 30, 60, 90):
        print("  %d Sekunden -> rund %d Woerter" % (s, int(s * 1.8)))
    print("FERTIG")
