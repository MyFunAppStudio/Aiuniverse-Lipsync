# ============================================
# Patch 19: Eingabefelder statt Regler,
# Musikverwaltung im Dashboard, Doppel-Untertitel weg
# ============================================
from pathlib import Path
import re

p = Path('dashboard.py')
s = p.read_text(encoding='utf-8')
Path('dashboard_vor19.py').write_text(s, encoding='utf-8')

# ---------- 1. Doppelte Untertitel-Karte entfernen ----------
marke = 'h2>Untertitel</h2>'
if s.count(marke) > 1:
    zeilen = s.split('\n')
    treffer = [i for i, z in enumerate(zeilen) if marke in z]
    # zweites Vorkommen samt Block entfernen
    start = treffer[1]
    ende = start + 1
    while ende < len(zeilen) and "h+='</div></div>';" not in zeilen[ende]:
        ende += 1
    del zeilen[start:ende + 1]
    s = '\n'.join(zeilen)
    print(f"1. Doppelte Untertitel-Karte entfernt (Zeilen {start + 1}-{ende + 1})")
else:
    print("1. Untertitel: kein Doppel gefunden")

# ---------- 2. Videolaenge: Eingabefeld ----------
if 'laengeFeld' not in s:
    s = s.replace("function laengeKnopf(kid,k){",
"""function laengeFeld(kid,k){
  var min = (k.laenge_einheit==='Sek') ? 5 : 1;
  var max = (k.laenge_einheit==='Sek') ? 1200 : 60;
  return '<div style="display:flex;gap:8px;align-items:center">'
    +'<input type="number" min="'+min+'" max="'+max+'" step="1" value="'+k.laenge+'" '
    +'style="width:110px;text-align:center;font-size:17px;font-weight:800" '
    +'onchange="laengeSetz(\\''+kid+'\\',this.value,'+min+','+max+')">'
    +'<span style="font-size:14px;font-weight:700;color:#5a6480">'+k.laenge_einheit+'</span></div>'
    +'<div class="mini">Erlaubt: '+min+' bis '+max+' '+k.laenge_einheit
    +(k.laenge_einheit==='Sek' ? ' - ab 60 Sek gibt es Geld auf TikTok und YouTube' : '')+'</div>';
}
function laengeSetz(kid,wert,min,max){
  var v = parseInt(wert,10);
  if(isNaN(v)) { zeichne(); return; }
  if(v<min) v=min;
  if(v>max) v=max;
  setz(kid,'laenge',v);
}

function laengeKnopf(kid,k){""", 1)
    s = s.replace("+laengeKnopf(kid,k)", "+laengeFeld(kid,k)")
    print("2. Videolaenge: freies Eingabefeld")
else:
    print("2. Videolaenge: schon Eingabefeld")

# ---------- 3. Restliche Regler zu Eingabefeldern ----------
def regler_zu_feld(text):
    """Wandelt uebrige type=range in Zahlenfelder um."""
    muster = re.compile(
        r"""<input type="range"[^>]*?min="(?P<min>[^"]*)"[^>]*?max="(?P<max>[^"]*)"[^>]*?>""")
    def ersatz(m):
        rest = m.group(0)
        wert = re.search(r'value="([^"]*)"', rest)
        onch = re.search(r'onchange="([^"]*)"', rest)
        return ('<input type="number" min="' + m.group('min') + '" max="' + m.group('max') + '"'
                + (' value="' + wert.group(1) + '"' if wert else '')
                + ' style="width:100px;text-align:center;font-weight:700"'
                + (' onchange="' + onch.group(1) + '"' if onch else '') + '>')
    return muster.sub(ersatz, text)

vorher = s.count('type="range"')
s = regler_zu_feld(s)
nachher = s.count('type="range"')
print(f"3. Regler umgestellt: {vorher} -> {nachher} uebrig")

# ---------- 4. Backend: Musikverwaltung ----------
if 'api/musik' not in s:
    s = s.replace('''def videos_liste():''',
'''def musik_liste(kanal_id):
    ordner = BASIS / "musik" / kanal_id
    ordner.mkdir(parents=True, exist_ok=True)
    treffer = []
    for f in sorted(ordner.iterdir()):
        if f.is_file() and f.suffix.lower() in (".mp3", ".wav", ".m4a", ".ogg"):
            treffer.append({"name": f.name,
                            "groesse": f"{f.stat().st_size/(1024*1024):.1f} MB"})
    return treffer


def musik_speichern(kanal_id, dateiname, base64_daten):
    import base64 as b64
    ordner = BASIS / "musik" / kanal_id
    ordner.mkdir(parents=True, exist_ok=True)
    if "," in base64_daten:
        base64_daten = base64_daten.split(",", 1)[1]
    sicher = "".join(c for c in dateiname if c.isalnum() or c in "._- ")
    if not sicher:
        sicher = "musik.mp3"
    (ordner / sicher).write_bytes(b64.b64decode(base64_daten))
    return sicher


def musik_loeschen(kanal_id, name):
    ziel = BASIS / "musik" / kanal_id / name
    if ziel.exists() and ziel.is_file():
        ziel.unlink()
        return True
    return False


def videos_liste():''')

    s = s.replace('''                "sprachen": einstellungen.SPRACHEN_LISTE,''',
'''                "sprachen": einstellungen.SPRACHEN_LISTE,
                "musikdateien": {kid: musik_liste(kid) for kid in alle},''')

    s = s.replace('''        elif self.path == "/api/bild_loeschen":''',
'''        elif self.path == "/api/musik_hoch":
            d = json.loads(self._body())
            name = musik_speichern(d["kanal"], d["name"], d["daten"])
            self._sende(json.dumps({"ok": True, "name": name}))

        elif self.path == "/api/musik_weg":
            d = json.loads(self._body())
            musik_loeschen(d["kanal"], d["name"])
            self._sende(json.dumps({"ok": True}))

        elif self.path == "/api/bild_loeschen":''')
    print("4. Backend: Musik hochladen, anzeigen, loeschen")

# ---------- 5. Frontend: Musikliste ----------
if 'musikWeg' not in s:
    s = s.replace("""     +'<div class="mini">Eigene Musik: Dateien in den Ordner musik/'+kid+'/ legen</div></div>';""",
"""     +'</div>';
    var md=(D.musikdateien&&D.musikdateien[kid])?D.musikdateien[kid]:[];
    h+='<div class="feld"><div class="lbl">Eigene Musikdateien ('+md.length+')</div>';
    if(md.length===0){
      h+='<div class="mini">Keine eigenen Dateien - es wird KI-Musik erzeugt.</div>';
    }
    md.forEach(function(f){
      h+='<div class="zeile"><span style="font-size:18px">MP3</span>'
        +'<div class="txt"><div class="t1" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+esc(f.name)+'</div>'
        +'<div class="t2">'+f.groesse+'</div></div>';
      if(musikFrage===kid+f.name){
        h+='<button class="chip" style="margin:0;border-color:#ff4060;color:#ff4060" onclick="musikWeg(\\''+kid+'\\',\\''+esc(f.name)+'\\')">Wirklich</button>'
         +'<button class="chip" style="margin:0" onclick="musikFrage=null;zeichne()">Nein</button>';
      }else{
        h+='<button class="chip" style="margin:0" onclick="musikFrage=\\''+kid+esc(f.name)+'\\';zeichne()">Loeschen</button>';
      }
      h+='</div>';
    });
    h+='<label class="btn d" style="display:block;text-align:center;cursor:pointer">Musik hochladen'
      +'<input type="file" accept="audio/*" multiple style="display:none" onchange="musikHoch(\\''+kid+'\\',this)"></label>'
      +'<div class="mini">Eigene Dateien werden bevorzugt und zufaellig gewaehlt.</div></div>';""")

    s = s.replace("var D={}, seite='dash',", "var musikFrage=null;\nvar D={}, seite='dash',", 1)

    s = s.replace("function bildHoch(kid,el){",
"""function musikHoch(kid,el){
  var dateien=Array.prototype.slice.call(el.files);
  var offen=dateien.length;
  if(!offen)return;
  melde(offen+' Datei(en) werden hochgeladen...');
  dateien.forEach(function(f){
    var leser=new FileReader();
    leser.onload=function(){
      fetch('/api/musik_hoch',{method:'POST',body:JSON.stringify({kanal:kid,name:f.name,daten:leser.result})})
        .then(function(){offen--;if(offen===0){melde('Hochgeladen');laden();}});
    };
    leser.readAsDataURL(f);
  });
}
function musikWeg(kid,name){
  musikFrage=null;
  fetch('/api/musik_weg',{method:'POST',body:JSON.stringify({kanal:kid,name:name})})
    .then(function(){melde('Geloescht');laden();});
}
function bildHoch(kid,el){""", 1)
    print("5. Frontend: Musikliste mit Upload und Loeschen")

p.write_text(s, encoding='utf-8')
print("FERTIG - Seite neu laden")
