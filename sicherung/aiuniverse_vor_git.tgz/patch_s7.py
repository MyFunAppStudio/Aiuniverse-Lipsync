# -*- coding: utf-8 -*-
import os, shutil, subprocess, sys
B = "/root/aiuniverse"
fehler = []


def tausche(datei, paare, merkmal, pruefen=True):
    p = os.path.join(B, datei)
    t = open(p, encoding="utf-8").read()
    if merkmal in t:
        print("INFO  %s war schon angepasst" % datei)
        return
    for alt, neu in paare:
        if alt not in t:
            print("ACHT  %s: Stelle nicht gefunden -> %r" % (datei, alt[:46]))
            fehler.append(datei)
            return
    shutil.copy2(p, p + ".bak_s7")
    for alt, neu in paare:
        t = t.replace(alt, neu, 1)
    open(p, "w", encoding="utf-8").write(t)
    if pruefen:
        r = subprocess.run([sys.executable, "-m", "py_compile", p], capture_output=True, text=True)
        if r.returncode:
            shutil.copy2(p + ".bak_s7", p)
            print("ACHT  %s zurueckgesetzt: %s" % (datei, r.stderr[-150:]))
            fehler.append(datei)
            return
    print("OK    %s" % datei)


# ---------- 1. szenen.py: Stimmung je Szene ----------
tausche("szenen.py", [
    ('PASSEN = ["fuellen", "ganz"]',
     'PASSEN = ["fuellen", "ganz"]\n'
     'STIMMUNGEN = [["", "wie beim Kanal"], ["ruhig", "ruhig"], ["sachlich", "sachlich"],\n'
     '              ["normal", "normal"], ["lebendig", "lebendig"], ["dramatisch", "dramatisch"]]\n'
     'ENERGIE = {"ruhig": 0.15, "sachlich": 0.35, "normal": 0.55,\n'
     '           "lebendig": 0.75, "dramatisch": 0.92}'),
    ('        if s.get("passen") not in PASSEN:\n            s["passen"] = "fuellen"',
     '        if s.get("passen") not in PASSEN:\n            s["passen"] = "fuellen"\n'
     '        if s.get("stimmung") not in ENERGIE:\n            s["stimmung"] = ""'),
    ('"figur": "", "passen": "fuellen",',
     '"figur": "", "passen": "fuellen", "stimmung": "",'),
    ('    elif feld == "passen":',
     '    elif feld == "stimmung":\n'
     '        w = str(wert or "")\n'
     '        if w and w not in ENERGIE:\n'
     '            return {"ok": False, "fehler": "Unbekannt"}\n'
     '        d["szenen"][i]["stimmung"] = w\n'
     '    elif feld == "passen":'),
    ('            "passen": s.get("passen", "fuellen"),',
     '            "passen": s.get("passen", "fuellen"),\n'
     '            "stimmung": s.get("stimmung", ""),'),
    ('            "passenarten": [[p, PASSEN_NAME[p]] for p in PASSEN]}',
     '            "passenarten": [[p, PASSEN_NAME[p]] for p in PASSEN],\n'
     '            "stimmungen": [list(x) for x in STIMMUNGEN]}'),
], "STIMMUNGEN")

# ---------- 2. szenen_video.py: Stimme und Stimmung je Szene nutzen ----------
ALT_ST = '''        if s["gesprochen"] and text:
            ton = os.path.join(ordner, "sz_%02d.mp3" % (nr + 1))
            try:
                medien.erzeuge_stimme(kanal, text, ton, stimme_id=None)
            except TypeError:
                medien.erzeuge_stimme(kanal, text, ton)'''
NEU_ST = '''        if s["gesprochen"] and text:
            ton = os.path.join(ordner, "sz_%02d.mp3" % (nr + 1))
            k2 = dict(kanal)
            if s.get("stimmung") and s["stimmung"] in szenen.ENERGIE:
                k2["stimme_energie"] = szenen.ENERGIE[s["stimmung"]]
            eigene = _stimme_fuer(kanal, s.get("figur"))
            try:
                medien.erzeuge_stimme(k2, text, ton, stimme_id=eigene)
            except TypeError:
                medien.erzeuge_stimme(k2, text, ton)'''

HILFE_ST = '''def _stimme_fuer(kanal, figur):
    """Sucht die Stimme einer Figur in der Stimmenliste des Kanals."""
    name = (figur or "").strip().lower()
    if not name:
        return None
    for e in (kanal.get("stimmen") or []):
        if isinstance(e, dict) and (e.get("name") or "").strip().lower() == name:
            return (e.get("id") or "").strip() or None
    return None


'''

tausche("szenen_video.py", [
    ("def plan_bauen(", HILFE_ST + "def plan_bauen("),
    (ALT_ST, NEU_ST),
    ('"passen": s.get("passen", "fuellen"),',
     '"passen": s.get("passen", "fuellen"),\n'
     '                     "stimmung": s.get("stimmung", ""), "figur": s.get("figur", ""),'),
], "def _stimme_fuer")

# ---------- 3. Oberflaeche: Stimmen beim Kanal, Stimmung je Szene ----------
ST_JS = r'''
/* ---------- Stimmen (Patch S7) ---------- */
var STIMMUNG=[["ruhig","ruhig"],["sachlich","sachlich"],["normal","normal"],["lebendig","lebendig"],["dramatisch","dramatisch"]];
var ENERGIE={ruhig:0.15,sachlich:0.35,normal:0.55,lebendig:0.75,dramatisch:0.92};
function stimmungName(e){
  e=Number(e); if(isNaN(e))e=0.6;
  var beste="normal",ab=9;
  for(var k in ENERGIE){var d=Math.abs(ENERGIE[k]-e); if(d<ab){ab=d;beste=k}}
  return beste;
}
function stimmenListe(){return (S.einst.stimmen||[]).filter(function(x){return x&&x.name})}
function stimmenKarte(){
  var li=stimmenListe(), aktiv=(S.einst.stimme_id||"");
  var o='<div class="karte p"><h2 class="kt">Stimmen</h2><div class="liste">';
  if(!li.length)o+='<div class="leer">keine eingetragen — dann nimmt er die Standardstimme des Modells</div>';
  li.forEach(function(e,i){
    var an=(e.id&&e.id===aktiv);
    o+='<div class="e"><button class="ik" style="'+(an?"background:#FF6A1A;border-color:#FF6A1A;color:#140B04":"")+'"'
      +' onclick="stimmeAktiv('+i+')">'+(an?"●":"○")+'</button>'
      +'<div class="tx" onclick="stimmeBearbeiten('+i+')"><div class="ti">'+h(e.name)+'</div>'
      +'<div class="me">'+h(e.id||"ohne ID")+'</div></div>'
      +'<button class="ik rot" onclick="stimmeWeg('+i+',\''+h(e.name).replace(/'/g,"")+'\')">✕</button></div>';
  });
  o+='</div><button class="knopf" style="width:100%;margin:9px 0 4px" onclick="stimmeNeu()">+ Stimme</button>'
   +reihe("Grundstimmung",knoepfeStimmung(stimmungName(S.einst.stimme_energie)),"gilt, wo bei der Szene nichts anderes steht")
   +'<div class="hinw" style="margin-top:8px">Die ID steht in deinem ElevenLabs-Konto bei der Stimme. '
   +'Der Name ist frei wählbar und wird im Szenen-Editor unter „Figur“ benutzt.</div></div>';
  return o;
}
function knoepfeStimmung(jetzt){
  return '<div class="pills">'+STIMMUNG.map(function(o){
    return '<button class="'+(jetzt===o[0]?"an":"")+'" onclick="setz(\'stimme_energie\','+ENERGIE[o[0]]+')">'+h(o[1])+'</button>'}).join("")+'</div>';
}
function stimmeForm(titel,i,e){
  e=e||{};
  el("dialog").innerHTML='<div class="dim"><div class="dlg"><h2>'+h(titel)+'</h2>'
   +'<input type="text" id="stn" class="breit" placeholder="Name, z.B. Erzähler oder Oma" value="'+h(e.name||"")+'" style="margin-bottom:8px">'
   +'<input type="text" id="sti" class="breit" placeholder="Stimm-ID aus ElevenLabs" value="'+h(e.id||"")+'" style="margin-bottom:14px">'
   +'<div class="zw"><button class="knopf" onclick="zu()">Abbrechen</button>'
   +'<button class="knopf or" onclick="stimmeSpeichern('+i+')">Speichern</button></div></div></div>';
}
function stimmeNeu(){stimmeForm("Stimme",-1,{})}
function stimmeBearbeiten(i){stimmeForm("Stimme ändern",i,stimmenListe()[i])}
function stimmeSpeichern(i){
  var n=(el("stn").value||"").trim(), id=(el("sti").value||"").trim();
  if(!n)return melde("Name darf nicht leer sein.");
  var li=stimmenListe().slice();
  if(i<0)li.push({name:n,id:id}); else li[i]={name:n,id:id};
  stimmenSichern(li,function(){zu()});
}
function stimmeWeg(i,n){
  frage("Stimme löschen?","<b>"+h(n)+"</b><br><br>Der Eintrag wird entfernt.","Löschen",function(){
    var li=stimmenListe().slice(); li.splice(i,1); stimmenSichern(li);},true);
}
function stimmeAktiv(i){
  var e=stimmenListe()[i]||{};
  S.einst.stimme_id=e.id||"";
  api("/api/kanal?k="+S.kanal,{stimme_id:S.einst.stimme_id}).then(zeichne);
}
function stimmenSichern(li,danach){
  S.einst.stimmen=li;
  api("/api/kanal?k="+S.kanal,{stimmen:li}).then(function(){if(danach)danach();zeichne()});
}
'''

tausche("dashboard2.html", [
    ("/* ---------- Start ---------- */", ST_JS + "\n/* ---------- Start ---------- */"),
    ('''  o+='<div class="karte">'
   +reihe("Stimme an",schalter("stimme_an",S.einst.stimme_an!==false),"aus für Build-Videos")''',
     '''  o+=stimmenKarte();
  o+='<div class="karte">'
   +reihe("Stimme an",schalter("stimme_an",S.einst.stimme_an!==false),"aus für Build-Videos")'''),
    ('''    o+='<div class="szz"><span class="szh">Figur</span>''',
     '''    o+='<div class="szz"><span class="szh">Stimmung</span><select onchange="szeneSetz(\\''+s.id+'\\',\\'stimmung\\',this.value)">'
      +(d.stimmungen||[]).map(function(x){return '<option value="'+x[0]+'"'+(s.stimmung===x[0]?" selected":"")+'>'+h(x[1])+'</option>'}).join("")
      +'</select></div>';
    o+='<div class="szz"><span class="szh">Figur</span>'''),
], "function stimmenKarte", pruefen=False)

print()
print("NICHT FERTIG:", ", ".join(sorted(set(fehler))) if fehler else "alles durch")
print("TEIL 7 FERTIG")
