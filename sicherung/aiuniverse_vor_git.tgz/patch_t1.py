import os, re, shutil, subprocess, sys
B = "/root/aiuniverse"

p = os.path.join(B, "einstellungen.py")
t = open(p, encoding="utf-8").read()
if "_key" in t and "_laden_alt" in t:
    print("INFO  einstellungen: Kanalschluessel war schon drin")
else:
    shutil.copy2(p, p + ".bak_t1")
    t += """

# ===== Kanalschluessel im Einstellungs-Paket (Patch T1) =====
_laden_alt = laden
_speichern_alt = speichern


def laden():
    d = _laden_alt()
    try:
        for k, v in d.items():
            if isinstance(v, dict):
                v["_key"] = k
    except Exception:
        pass
    return d


def speichern(neue_daten):
    try:
        sauber = {}
        for k, v in (neue_daten or {}).items():
            if isinstance(v, dict):
                v = dict((kk, vv) for kk, vv in v.items() if kk != "_key")
            sauber[k] = v
    except Exception:
        sauber = neue_daten
    return _speichern_alt(sauber)
"""
    open(p, "w", encoding="utf-8").write(t)
    r = subprocess.run([sys.executable, "-m", "py_compile", p], capture_output=True, text=True)
    if r.returncode:
        shutil.copy2(p + ".bak_t1", p)
        print("ACHT  einstellungen zurueckgesetzt:", r.stderr[-200:])
        raise SystemExit(1)
    print("OK    einstellungen: Kanalschluessel steckt jetzt im Paket")

p = os.path.join(B, "text_generator.py")
t = open(p, encoding="utf-8").read()
if "_tl_hinweis" in t:
    print("INFO  text_generator: Themenliste war schon drin")
else:
    shutil.copy2(p, p + ".bak_t1")
    t2, n = re.subn(r"Das SKRIPT hat genau", "{_tl_hinweis(kanal)}Das SKRIPT hat genau", t, count=1)
    if n:
        t = t2
        print("OK    text_generator: Gedaechtnis in den Prompt eingehaengt")
    else:
        print("ACHT  text_generator: Prompt-Stelle nicht gefunden")
    t += """

# ===== Themenliste (Patch T1) =====
import themen as _tl

_erzeuge_paket_tl = erzeuge_paket


def _tl_hinweis(kanal):
    try:
        return _tl.hinweis(kanal)
    except Exception:
        return ""


def erzeuge_paket(kanal, eigenes_thema=None):
    gewaehlt = (eigenes_thema or "").strip() or None
    if not gewaehlt:
        gewaehlt = _tl.naechstes(kanal)
        if gewaehlt:
            print("  Thema aus der Liste: %s" % gewaehlt)
        else:
            print("  Themenliste leer - Claude waehlt frei")
    d = _erzeuge_paket_tl(kanal, gewaehlt)
    try:
        if d and gewaehlt:
            _tl.erledigt(kanal, gewaehlt)
            rest = len(_tl.laden(kanal)["offen"])
            print("  Thema abgehakt, noch %d offen" % rest)
    except Exception as ex:
        print("  Themenliste: %s" % ex)
    return d
"""
    open(p, "w", encoding="utf-8").write(t)
    r = subprocess.run([sys.executable, "-m", "py_compile", p], capture_output=True, text=True)
    if r.returncode:
        shutil.copy2(p + ".bak_t1", p)
        print("ACHT  text_generator zurueckgesetzt:", r.stderr[-200:])
        raise SystemExit(1)
    print("OK    text_generator: Themenliste eingebaut")
print("FERTIG")
