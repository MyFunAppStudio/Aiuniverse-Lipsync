#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""patch_f2.py  -  Nachzug: feste 1280/720 raus, Bildformat in medien.py."""
import ast, os, re, shutil, subprocess, sys

BASIS = "/root/aiuniverse"
BERICHT = []


def ok(m):
    BERICHT.append("OK    " + m)


def info(m):
    BERICHT.append("INFO  " + m)


def warn(m):
    BERICHT.append("ACHT  " + m)


def P(n):
    return os.path.join(BASIS, n)


def lese(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def schreibe(p, t):
    if not os.path.exists(p + ".bak_f2"):
        shutil.copy2(p, p + ".bak_f2")
    with open(p, "w", encoding="utf-8") as f:
        f.write(t)


def pruefe(p):
    r = subprocess.run([sys.executable, "-m", "py_compile", p],
                       capture_output=True, text=True)
    return r.returncode == 0, (r.stderr or "")[-400:]


def zurueck(p):
    if os.path.exists(p + ".bak_f2"):
        shutil.copy2(p + ".bak_f2", p)


def import_rein(t, zeile):
    if re.search(r"^\s*" + re.escape(zeile) + r"\s*$", t, re.M):
        return t
    zl = t.splitlines()
    letzte = None
    for i, z in enumerate(zl[:80]):
        if re.match(r"^(import |from )\S", z):
            letzte = i
    if letzte is None:
        stelle = 0
        while stelle < len(zl) and (zl[stelle].startswith("#!")
                                    or "coding" in zl[stelle][:30]):
            stelle += 1
        zl.insert(stelle, zeile)
    else:
        zl.insert(letzte + 1, zeile)
    return "\n".join(zl)


def kette(src, pos):
    """Alle Funktionen, in denen die Zeichenposition pos liegt (aussen -> innen)."""
    try:
        baum = ast.parse(src)
    except SyntaxError:
        return []
    zeile = src.count("\n", 0, pos) + 1
    k = [n for n in ast.walk(baum)
         if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
         and n.lineno <= zeile <= (n.end_lineno or n.lineno)]
    k.sort(key=lambda n: n.lineno)
    return k


def kanal_da(k):
    """Ist 'kanal' in einer der Funktionen der Kette verfuegbar?"""
    for n in k:
        a = n.args
        namen = [x.arg for x in list(a.posonlyargs or []) + list(a.args) + list(a.kwonlyargs)]
        if "kanal" in namen:
            return True
        for nd in ast.walk(n):
            if isinstance(nd, ast.Name) and isinstance(nd.ctx, ast.Store) and nd.id == "kanal":
                return True
            if isinstance(nd, ast.arg) and nd.arg == "kanal":
                return True
    return False


# ============ video_bauen.py: feste Masse raus ============

def patch_vb():
    p = P("video_bauen.py")
    if not os.path.exists(p):
        warn("video_bauen.py nicht gefunden")
        return
    t = lese(p)
    alt = t
    zl = t.splitlines()
    getan, offen = 0, []
    for i, z in enumerate(zl):
        if z.strip().startswith("#"):
            continue
        if not (re.search(r"\b1280\b", z) and re.search(r"\b720\b", z)):
            continue
        if "PlayRes" in z or "alt_b" in z:
            continue
        if re.search(r"""f["']""", z):
            neu = re.sub(r"\b1280\b", "{BREITE}", z)
            neu = re.sub(r"\b720\b", "{HOEHE}", neu)
            zl[i] = neu
            getan += 1
        else:
            offen.append((i + 1, z.strip()))
    if getan:
        t = "\n".join(zl)
        ok("video_bauen.py: %d Zeile(n) von 1280x720 auf Kanalformat umgestellt" % getan)
    else:
        info("video_bauen.py: keine festen f-String-Masse mehr gefunden")
    for nr, z in offen:
        warn("video_bauen.py Zeile %d kein f-String: %s" % (nr, z[:80]))
    if t != alt:
        schreibe(p, t)
        g, f = pruefe(p)
        if not g:
            zurueck(p)
            warn("video_bauen.py: Syntaxfehler, zurueckgesetzt: " + f)
            return
    rest = lese(p)
    uebrig = [z.strip() for z in rest.splitlines()
              if re.search(r"\b(1280|720)\b", z) and not z.strip().startswith("#")
              and "PlayRes" not in z and "alt_b" not in z]
    if uebrig:
        for z in uebrig[:5]:
            warn("video_bauen.py Rest: " + z[:80])
    else:
        ok("video_bauen.py: keine festen Masse mehr drin")


# ============ medien.py: Bildformat ============

def patch_medien():
    p = P("medien.py")
    if not os.path.exists(p):
        warn("medien.py nicht gefunden")
        return
    t = lese(p)
    if "einstellungen.bild_format" in t:
        info("medien.py: war schon umgestellt")
        return
    m = re.search(r'"image_size"\s*:\s*"[^"]*"', t)
    if not m:
        m = re.search(r"'image_size'\s*:\s*'[^']*'", t)
    if not m:
        warn("medien.py: image_size nicht gefunden")
        return
    k = kette(t, m.start())
    namen = " > ".join(n.name for n in k) or "(Modulebene)"
    info("medien.py: image_size steht in %s" % namen)
    if not kanal_da(k):
        warn("medien.py: 'kanal' in %s nicht erreichbar - bitte melden" % namen)
        return
    neu = import_rein(t, "import einstellungen")
    neu = re.sub(r'"image_size"\s*:\s*"[^"]*"',
                 '"image_size": einstellungen.bild_format(kanal)', neu)
    neu = re.sub(r"'image_size'\s*:\s*'[^']*'",
                 "'image_size': einstellungen.bild_format(kanal)", neu)
    schreibe(p, neu)
    g, f = pruefe(p)
    if not g:
        zurueck(p)
        warn("medien.py: Syntaxfehler, zurueckgesetzt: " + f)
        return
    ok("medien.py: Bilder werden jetzt im Kanalformat erzeugt")


def main():
    if not os.path.isdir(BASIS):
        print("FEHLER: %s fehlt" % BASIS)
        return 1
    patch_vb()
    patch_medien()
    os.system("systemctl restart dashboard >/dev/null 2>&1")
    print("=" * 46)
    for z in BERICHT:
        print(z)
    print("=" * 46)
    try:
        sys.path.insert(0, BASIS)
        import einstellungen as E
        import video_bauen as V
        for kk in ("a", "b"):
            V._setze_format(kk)
            print("Kanal %s: %s  %dx%d  Bilder: %s"
                  % (kk, E.format_name(kk), V.BREITE, V.HOEHE, E.bild_format(kk)))
    except Exception as e:
        print("Pruefung uebersprungen: %s" % e)
    print("FERTIG")
    return 0


if __name__ == "__main__":
    sys.exit(main())
