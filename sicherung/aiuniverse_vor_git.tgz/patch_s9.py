# -*- coding: utf-8 -*-
import os, shutil
B = "/root/aiuniverse"
p = os.path.join(B, "dashboard2.html")
t = open(p, encoding="utf-8").read()
if "function promptAendern" in t:
    print("INFO  Oberflaeche: Abfrage war schon drin")
    raise SystemExit(0)

JS = r'''
/* ---------- Masterprompt mit Abfrage (Patch S9) ---------- */
function promptAendern(neu){
  var alt=S.einst.prompt||"";
  if(neu===alt)return;
  var leer=!neu.trim();
  var vorschau=leer?"<b>Der Masterprompt wird komplett geleert.</b>"
    :"Neu:<br><br><i>"+h(neu.slice(0,180))+(neu.length>180?"…":"")+"</i>";
  var text="Der Masterprompt bestimmt, wie Claude jedes Video für diesen Kanal schreibt.<br><br>"+vorschau;
  el("dialog").innerHTML='<div class="dim"><div class="dlg"><h2>Masterprompt ändern?</h2>'
   +'<p>'+text+'</p><div class="zw">'
   +'<button class="knopf" id="pnein">Verwerfen</button>'
   +'<button class="knopf '+(leer?"":"or")+'" id="pja"'
   +(leer?' style="background:#B02A2A;border-color:#B02A2A;color:#fff;font-weight:700"':'')
   +'>Speichern</button></div></div></div>';
  el("pnein").onclick=function(){zu();zeichne()};
  el("pja").onclick=function(){zu();setz("prompt",neu)};
}
'''

paare = [
    ("/* ---------- Start ---------- */", JS + "\n/* ---------- Start ---------- */"),
    ("""   +'<textarea onchange="setz(\\'prompt\\',this.value)">'+h(S.einst.prompt||"")+'</textarea></div>';""",
     """   +'<textarea onchange="promptAendern(this.value)">'+h(S.einst.prompt||"")+'</textarea>'
   +'<div class="hinw" style="margin-top:8px">Änderungen werden erst nach einer Abfrage gespeichert.</div></div>';"""),
]
for a, b in paare:
    if a not in t:
        print("ACHT  Stelle nicht gefunden, nichts geaendert:", a[:50].replace("\n", " "))
        raise SystemExit(1)
shutil.copy2(p, p + ".bak_s9")
for a, b in paare:
    t = t.replace(a, b, 1)
open(p, "w", encoding="utf-8").write(t)
print("OK    Masterprompt fragt jetzt vor dem Speichern nach")
print("TEIL 9 FERTIG")
