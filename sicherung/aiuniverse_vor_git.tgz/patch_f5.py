#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""patch_f5.py  -  Untertitel-Timing nach echtem Sprechfluss."""
import ast, os, re, shutil, subprocess, sys

BASIS = "/root/aiuniverse"
B = []
TT2 = '\n# ===== Untertitel-Timing nach echtem Sprechfluss (TT_V2) =====\n_TT_TON = None\n\n\ndef _tt_ton_setzen(pfad):\n    global _TT_TON\n    _TT_TON = str(pfad) if pfad else None\n    return _TT_TON\n\n\ndef _tt_silben(wort):\n    w = wort.lower()\n    gruppen = re.findall(r"[aeiouyäöü]+", w)\n    n = len(gruppen)\n    return n if n > 0 else 1\n\n\ndef _tt_dauer(pfad):\n    try:\n        r = subprocess.run(["ffprobe", "-v", "error", "-show_entries",\n                            "format=duration", "-of", "csv=p=0", str(pfad)],\n                           capture_output=True, text=True, timeout=30)\n        return float((r.stdout or "0").strip())\n    except Exception:\n        return 0.0\n\n\ndef _tt_sprachsegmente(pfad, gesamt):\n    """Abschnitte, in denen wirklich gesprochen wird."""\n    stille = []\n    try:\n        r = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", str(pfad),\n                            "-af", "silencedetect=noise=-33dB:d=0.16", "-f", "null", "-"],\n                           capture_output=True, text=True, timeout=120)\n        txt = (r.stderr or "")\n        anf = None\n        for m in re.finditer(r"silence_(start|end):\\s*(-?[0-9.]+)", txt):\n            art, wert = m.group(1), float(m.group(2))\n            if art == "start":\n                anf = wert\n            elif anf is not None:\n                stille.append((max(0.0, anf), max(0.0, wert)))\n                anf = None\n        if anf is not None:\n            stille.append((max(0.0, anf), gesamt))\n    except Exception:\n        stille = []\n\n    seg, pos = [], 0.0\n    for s, e in stille:\n        if s > pos:\n            seg.append((pos, min(s, gesamt)))\n        pos = max(pos, e)\n    if pos < gesamt:\n        seg.append((pos, gesamt))\n    seg = [(s, e) for s, e in seg if e - s > 0.12]\n    if not seg:\n        seg = [(0.0, gesamt)]\n    return seg\n\n\ndef _tt_wand(seg):\n    """Umrechner: Sprechzeit -> echte Zeit im Video."""\n    laengen = [e - s for s, e in seg]\n    summe = sum(laengen) or 1.0\n\n    def wand(t):\n        t = max(0.0, min(summe, t))\n        rest = t\n        for i, (s, e) in enumerate(seg):\n            d = laengen[i]\n            if rest <= d or i == len(seg) - 1:\n                return s + min(rest, d)\n            rest -= d\n        return seg[-1][1]\n\n    return wand, summe\n\n\ndef baue_untertitel_ass(*a, **k):\n    """Haeppchen-Untertitel, zeitlich am echten Sprechfluss ausgerichtet."""\n    text = k.get("text") if "text" in k else (a[0] if len(a) > 0 else "")\n    gesamt = k.get("gesamt_sek") if "gesamt_sek" in k else (a[1] if len(a) > 1 else 0)\n    ziel = k.get("ziel") if "ziel" in k else (a[2] if len(a) > 2 else None)\n    kanal = k.get("kanal") if "kanal" in k else (a[4] if len(a) > 4 else None)\n    gesamt = float(gesamt or 0)\n    if not ziel:\n        return None\n    if kanal:\n        try:\n            _setze_format(kanal)\n        except Exception:\n            pass\n\n    e = {}\n    try:\n        e = (einstellungen.laden().get(kanal) or {}) if kanal else {}\n    except Exception:\n        e = {}\n    try:\n        fak = float(e.get("untertitel_groesse", 48) or 48) / 48.0\n    except Exception:\n        fak = 1.0\n    fak = max(0.5, min(2.0, fak))\n    caps = e.get("untertitel_caps", True)\n    try:\n        pro = int(e.get("untertitel_woerter", 3) or 3)\n    except Exception:\n        pro = 3\n    pro = max(1, min(5, pro))\n\n    hoch = HOEHE >= BREITE\n    fs = max(20, int(BREITE * (0.088 if hoch else 0.052) * fak))\n    rand = max(2, int(fs * 0.12))\n    schatten = max(1, int(fs * 0.035))\n    ml = int(BREITE * 0.08)\n    mv = int(HOEHE * (0.30 if hoch else 0.09))\n\n    kopf = _tt_ass_kopf(fs, rand, schatten, ml, mv, _tt_schrift())\n    stuecke = _tt_stuecke(text, max_w=pro, max_z=15)\n    if not stuecke:\n        with open(ziel, "w", encoding="utf-8") as f:\n            f.write(kopf)\n        return ziel\n\n    # echte Tonlaenge und Sprechabschnitte\n    ton = _TT_TON if (_TT_TON and os.path.exists(_TT_TON)) else None\n    if ton:\n        d = _tt_dauer(ton)\n        if d > 0.5:\n            gesamt = d\n    if gesamt <= 0:\n        gesamt = max(1.0, len(stuecke) * 0.8)\n    seg = _tt_sprachsegmente(ton, gesamt) if ton else [(0.0, gesamt)]\n    wand, sprechzeit = _tt_wand(seg)\n\n    # Saetze bilden (Haeppchen bis zum Satzzeichen)\n    saetze, akt = [], []\n    for st in stuecke:\n        akt.append(st)\n        if st and st[-1][-1:] in ".!?":\n            saetze.append(akt)\n            akt = []\n    if akt:\n        saetze.append(akt)\n\n    def gewicht(st):\n        g = sum(_tt_silben(w) for w in st) + 0.35 * len(st)\n        if st and st[-1][-1:] in ".!?":\n            g += 0.45\n        elif st and st[-1][-1:] in ",;:":\n            g += 0.25\n        return max(0.6, g)\n\n    # Satzgrenzen auf die Sprechabschnitte legen\n    if len(saetze) == len(seg):\n        bereiche = list(seg)\n    else:\n        sg = [sum(gewicht(x) for x in s_) for s_ in saetze]\n        ges = float(sum(sg)) or 1.0\n        luecken = [(seg[i][1] + seg[i + 1][0]) / 2.0 for i in range(len(seg) - 1)]\n        grenzen, lauf = [], 0.0\n        for g in sg[:-1]:\n            lauf += g\n            z = wand(sprechzeit * lauf / ges)\n            if luecken:\n                nah = min(luecken, key=lambda x: abs(x - z))\n                if abs(nah - z) < 0.9:\n                    z = nah\n            grenzen.append(z)\n        grenzen = sorted(set(grenzen))\n        kanten = [seg[0][0]] + grenzen + [seg[-1][1]]\n        bereiche = [(kanten[i], max(kanten[i] + 0.3, kanten[i + 1]))\n                    for i in range(len(kanten) - 1)]\n        while len(bereiche) < len(saetze):\n            bereiche.append((seg[-1][1] - 0.3, seg[-1][1]))\n        bereiche = bereiche[:len(saetze)]\n\n    zeilen = []\n    for si, satz in enumerate(saetze):\n        a0, a1 = bereiche[si]\n        sg = [gewicht(x) for x in satz]\n        su = float(sum(sg)) or 1.0\n        lauf = a0\n        for j, st in enumerate(satz):\n            d = (a1 - a0) * sg[j] / su\n            t0 = lauf\n            t1 = a1 if j == len(satz) - 1 else min(a1, lauf + d)\n            lauf = t1\n            if t1 - t0 < 0.28:\n                t1 = t0 + 0.28\n            zent = [max(10, int(round((t1 - t0) * 100 * _tt_silben(w) /\n                                      float(sum(_tt_silben(x) for x in st) or 1))))\n                    for w in st]\n            diff = int(round((t1 - t0) * 100)) - sum(zent)\n            if zent:\n                zent[-1] = max(10, zent[-1] + diff)\n            inhalt = "".join("{\\\\k%d}%s " % (zent[q], (w.upper() if caps else w))\n                             for q, w in enumerate(st)).strip()\n            vor = "{\\\\fad(60,60)\\\\fscx86\\\\fscy86\\\\t(0,120,\\\\fscx100\\\\fscy100)}"\n            zeilen.append("Dialogue: 0,%s,%s,TT,,0,0,0,,%s%s"\n                          % (_tt_zeit(t0), _tt_zeit(t1), vor, inhalt))\n    with open(ziel, "w", encoding="utf-8") as f:\n        f.write(kopf + "\\n".join(zeilen) + "\\n")\n    return ziel\n'


def main():
    p = os.path.join(BASIS, "video_bauen.py")
    if not os.path.exists(p):
        print("FEHLER: video_bauen.py fehlt")
        return 1
    with open(p, encoding="utf-8") as f:
        t = f.read()
    if "_tt_stuecke" not in t:
        print("FEHLER: patch_f4 fehlt noch - erst den einspielen")
        return 1
    if not os.path.exists(p + ".bak_f5"):
        shutil.copy2(p, p + ".bak_f5")

    if "_tt_sprachsegmente" in t:
        B.append("INFO  Sprechfluss-Timing war schon drin")
    else:
        t = t.rstrip() + "\n" + TT2
        B.append("OK    Sprechfluss-Timing ergaenzt")

    # Tonpfad an die Untertitel durchreichen
    knoten = None
    try:
        for nd in ast.walk(ast.parse(t)):
            if isinstance(nd, ast.FunctionDef) and nd.name == "baue_video":
                knoten = nd
    except SyntaxError as ex:
        print("FEHLER beim Lesen: %s" % ex)
        return 1
    if knoten is None:
        B.append("ACHT  baue_video nicht gefunden")
    else:
        q = "\n".join(t.splitlines()[knoten.lineno - 1:(knoten.end_lineno or knoten.lineno)])
        namen = [x.arg for x in knoten.args.args]
        if "_tt_ton_setzen(" in q:
            B.append("INFO  Tonpfad war schon verdrahtet")
        elif "ton_pfad" not in namen:
            B.append("ACHT  baue_video hat kein ton_pfad: %s" % ", ".join(namen))
        else:
            erst = knoten.body[0]
            ln, ein = erst.lineno, erst.col_offset
            if (isinstance(erst, ast.Expr) and isinstance(erst.value, ast.Constant)
                    and isinstance(erst.value.value, str)):
                ln = knoten.body[1].lineno if len(knoten.body) > 1 else erst.end_lineno + 1
                ein = knoten.body[1].col_offset if len(knoten.body) > 1 else ein
            zl = t.splitlines()
            zl.insert(ln - 1, " " * ein + "_tt_ton_setzen(ton_pfad)")
            t = "\n".join(zl)
            B.append("OK    Tonpfad an die Untertitel verdrahtet")

    with open(p, "w", encoding="utf-8") as f:
        f.write(t)
    r = subprocess.run([sys.executable, "-m", "py_compile", p],
                       capture_output=True, text=True)
    if r.returncode != 0:
        shutil.copy2(p + ".bak_f5", p)
        print("ACHT  Syntaxfehler, zurueckgesetzt: " + (r.stderr or "")[-300:])
        return 1

    os.system("systemctl restart dashboard >/dev/null 2>&1")
    print("=" * 46)
    for z in B:
        print(z)
    print("=" * 46)
    try:
        sys.path.insert(0, BASIS)
        import video_bauen as V
        V._setze_format("b")
        d = sorted([x for x in os.listdir(os.path.join(BASIS, "fertige_videos"))], reverse=True)
        ton = None
        for o in d:
            k = os.path.join(BASIS, "fertige_videos", o, "stimme.mp3")
            if os.path.exists(k):
                ton = k
                break
        if ton:
            V._tt_ton_setzen(ton)
            dd = V._tt_dauer(ton)
            sg = V._tt_sprachsegmente(ton, dd)
            print("Pruefton: %.1fs, %d Sprechabschnitte" % (dd, len(sg)))
            print("  " + ", ".join("%.1f-%.1f" % (a, b) for a, b in sg[:8]))
        else:
            print("Kein stimme.mp3 zum Pruefen gefunden")
    except Exception as ex:
        print("Pruefung uebersprungen: %s" % ex)
    print("FERTIG")
    return 0


if __name__ == "__main__":
    sys.exit(main())
