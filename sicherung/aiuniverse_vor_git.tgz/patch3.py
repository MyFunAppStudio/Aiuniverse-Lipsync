# Patch 3: Module lesen Keys aus dem Dashboard (einstellungen.json)
from pathlib import Path

# ---------- text_generator.py ----------
p = Path('text_generator.py')
s = p.read_text(encoding='utf-8')
if 'aktive_api' not in s:
    s = s.replace('''import config


def _claude_anfrage(prompt, max_tokens=4000):
    """Fragt Claude ueber die API."""''',
'''import config
import einstellungen


def _claude_anfrage(prompt, max_tokens=4000, kanal=None):
    """Fragt Claude ueber die API. Key kommt aus dem Dashboard."""
    api = einstellungen.aktive_api(kanal, "text") if kanal else None
    schluessel = (api or {}).get("key") or config.ANTHROPIC_KEY
    basis = (api or {}).get("url") or "https://api.anthropic.com"
    if not schluessel:
        raise RuntimeError("Kein Anthropic-Key im Dashboard eingetragen (Kanal -> APIs -> TEXT)")''')

    s = s.replace('''    anfrage = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=daten,
        headers={
            "x-api-key": config.ANTHROPIC_KEY,''',
'''    anfrage = urllib.request.Request(
        basis.rstrip("/") + "/v1/messages",
        data=daten,
        headers={
            "x-api-key": schluessel,''')

    s = s.replace('    antwort = _claude_anfrage(prompt)',
                  '    antwort = _claude_anfrage(prompt, kanal=kanal)')
    p.write_text(s, encoding='utf-8')
    print("text_generator.py: liest Key aus Dashboard")
else:
    print("text_generator.py: schon angepasst")

# ---------- medien.py ----------
p = Path('medien.py')
s = p.read_text(encoding='utf-8')
if 'aktive_api' not in s:
    s = s.replace('import config\n', 'import config\nimport einstellungen\n', 1)

    s = s.replace('''def _fal_anfrage(url, daten):
    """Ruft ein fal.ai Modell auf."""
    anfrage = urllib.request.Request(
        url,
        data=json.dumps(daten).encode(),
        headers={
            "Authorization": f"Key {config.FAL_KEY}",
            "Content-Type": "application/json",
        }
    )''',
'''def _modell_url(pfad):
    """Macht aus 'fal-ai/flux/schnell' eine volle URL."""
    if pfad.startswith("http"):
        return pfad
    return "https://fal.run/" + pfad.strip("/")


def _fal_anfrage(url, daten, schluessel=None):
    """Ruft ein Modell auf. Key kommt aus dem Dashboard."""
    schluessel = schluessel or config.FAL_KEY
    if not schluessel:
        raise RuntimeError("Kein fal.ai-Key im Dashboard eingetragen (Kanal -> APIs)")
    anfrage = urllib.request.Request(
        _modell_url(url),
        data=json.dumps(daten).encode(),
        headers={
            "Authorization": f"Key {schluessel}",
            "Content-Type": "application/json",
        }
    )''')

    s = s.replace('''            print(f"[Bild] {i+1}/{len(bild_prompts)}: {prompt[:45]}...")
            ergebnis = _fal_anfrage(FAL_BILD, {''',
'''            api = einstellungen.aktive_api(kanal, "bilder") or {}
            print(f"[Bild] {i+1}/{len(bild_prompts)} ({api.get('name','?')}): {prompt[:40]}...")
            ergebnis = _fal_anfrage(api.get("url") or FAL_BILD, {''')
    s = s.replace('''                "num_images": 1,
            })''',
'''                "num_images": 1,
            }, api.get("key"))''')

    s = s.replace('''    print(f"[Stimme] {kanal['name']}: erzeuge Audio...")
    daten = {"text": text}
    if stimme_id:
        daten["voice"] = stimme_id
    ergebnis = _fal_anfrage(FAL_STIMME, daten)''',
'''    api = einstellungen.aktive_api(kanal, "stimme") or {}
    print(f"[Stimme] {kanal['name']} ({api.get('name','?')}): erzeuge Audio...")
    daten = {"text": text}
    if stimme_id:
        daten["voice"] = stimme_id
    ergebnis = _fal_anfrage(api.get("url") or FAL_STIMME, daten, api.get("key"))''')
    p.write_text(s, encoding='utf-8')
    print("medien.py: liest Keys aus Dashboard")
else:
    print("medien.py: schon angepasst")

# ---------- api_check.py ----------
p = Path('api_check.py')
s = p.read_text(encoding='utf-8')
if 'aktive_api' not in s:
    s = s.replace('import config\n', 'import config\nimport einstellungen\n', 1)
    s = s.replace('''    fehlt = []
    if not config.ANTHROPIC_KEY:
        fehlt.append("Anthropic (Text)")
    if not config.FAL_KEY:
        fehlt.append("fal.ai (Bilder/Stimme/Video)")
    if kanal["mit_avatar"] and not config.HEDRA_KEY:
        fehlt.append("Hedra (Avatar)")

    return len(fehlt) == 0, fehlt''',
'''    fehlt = []
    noetig = [("text", "Text/Skript"), ("stimme", "Stimme"), ("bilder", "Bilder")]
    for slot, bez in noetig:
        api = einstellungen.aktive_api(kanal, slot)
        if not api:
            fehlt.append(f"{bez}: keine AI aktiv")
        elif not api.get("key"):
            fehlt.append(f"{bez}: Key fehlt ({api.get('name','?')})")

    return len(fehlt) == 0, fehlt''')
    p.write_text(s, encoding='utf-8')
    print("api_check.py: prueft Dashboard-Keys")
else:
    print("api_check.py: schon angepasst")

print("FERTIG")
