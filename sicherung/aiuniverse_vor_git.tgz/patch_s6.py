# -*- coding: utf-8 -*-
import os, shutil, subprocess, sys
B = "/root/aiuniverse"
fehler = []


def tausche(datei, paare, merkmal, pruefen=True):
    p = os.path.join(B, datei)
    t = open(p, encoding="utf-8").read()
    if merkmal in t:
        print("INFO  %s war schon angepasst" % datei)
        return
    for alt, neu in paare:
        if alt not in t:
            print("ACHT  %s: Stelle nicht gefunden -> %r" % (datei, alt[:46]))
            fehler.append(datei)
            return
    shutil.copy2(p, p + ".bak_s6")
    for alt, neu in paare:
        t = t.replace(alt, neu, 1)
    open(p, "w", encoding="utf-8").write(t)
    if pruefen:
        r = subprocess.run([sys.executable, "-m", "py_compile", p], capture_output=True, text=True)
        if r.returncode:
            shutil.copy2(p + ".bak_s6", p)
            print("ACHT  %s zurueckgesetzt: %s" % (datei, r.stderr[-150:]))
            fehler.append(datei)
            return
    print("OK    %s" % datei)


# ---------- 1. telegram_sender.py: Datei wirklich hochladen ----------
ALT_TG = '''    print(f"[Telegram] {kanal['name']}: sende Video ({groesse_mb:.1f} MB)...")
    # Video-Upload braucht multipart - hier vorerst Hinweis + Text
    return sende_text(kanal, f"{kanal['emoji']} Video fertig:\\n{pfad}\\n\\n{beschreibung}")'''

NEU_TG = '''    print(f"[Telegram] {kanal['name']}: sende Video ({groesse_mb:.1f} MB)...")
    ergebnis = _post_datei(token, "sendVideo", {
        "chat_id": chat, "caption": _bildunterschrift(kanal, pfad, beschreibung),
        "supports_streaming": "true"}, "video", pfad, "video/mp4")
    if ergebnis.get("ok"):
        print(f"[Telegram] {kanal['name']}: Video gesendet")
        return True
    print(f"[Telegram] Video-Upload fehlgeschlagen -> {ergebnis}")
    return _notfall(kanal, pfad, beschreibung, groesse_mb)'''

ANHANG_TG = '''

# ---------- Datei-Upload (Patch S6) ----------
import os as _os
import time as _time


def _bildunterschrift(kanal, pfad, beschreibung):
    text = "%s %s" % (kanal.get("emoji", ""), (beschreibung or "Video fertig").strip())
    link = _link(kanal, pfad)
    if link:
        text += "\\n\\n" + link
    return text[:1024]


def _link(kanal, pfad):
    basis = (kanal.get("dashboard_adresse") or "").strip().rstrip("/")
    if not basis:
        return ""
    return "%s/laden/%s" % (basis, Path(pfad).parent.name)


def _post_datei(token, methode, felder, feldname, pfad, mime):
    """Schickt eine Datei als multipart an Telegram."""
    grenze = "AiUniverse%d" % int(_time.time() * 1000)
    teile = []
    for k, v in felder.items():
        teile.append(("--%s\\r\\nContent-Disposition: form-data; name=\\"%s\\"\\r\\n\\r\\n%s\\r\\n"
                      % (grenze, k, v)).encode("utf-8"))
    teile.append(("--%s\\r\\nContent-Disposition: form-data; name=\\"%s\\"; filename=\\"%s\\"\\r\\n"
                  "Content-Type: %s\\r\\n\\r\\n"
                  % (grenze, feldname, _os.path.basename(str(pfad)), mime)).encode("utf-8"))
    try:
        with open(str(pfad), "rb") as f:
            teile.append(f.read())
    except Exception as fehler:
        return {"ok": False, "fehler": str(fehler)}
    teile.append(("\\r\\n--%s--\\r\\n" % grenze).encode("utf-8"))
    koerper = b"".join(teile)
    url = "https://api.telegram.org/bot%s/%s" % (token, methode)
    anfrage = urllib.request.Request(url, koerper, {
        "Content-Type": "multipart/form-data; boundary=%s" % grenze,
        "Content-Length": str(len(koerper))})
    try:
        with urllib.request.urlopen(anfrage, timeout=300) as antwort:
            return json.loads(antwort.read().decode())
    except Exception as fehler:
        return {"ok": False, "fehler": str(fehler)}


def _notfall(kanal, pfad, beschreibung, groesse_mb):
    """Zu gross oder Upload gescheitert: Vorschaubild plus Zeile zum Herunterladen."""
    token = kanal.get("telegram_token", "")
    chat = kanal.get("telegram_chat", "")
    text = _bildunterschrift(kanal, pfad, beschreibung)
    vorschau = Path(pfad).parent / "thumbnail.jpg"
    if vorschau.exists() and token and chat:
        e = _post_datei(token, "sendPhoto", {"chat_id": chat, "caption": text},
                        "photo", str(vorschau), "image/jpeg")
        if e.get("ok"):
            print("[Telegram] Vorschaubild gesendet (%.1f MB Video)" % groesse_mb)
            return True
    return sende_text(kanal, text + ("\\n\\n%.1f MB" % groesse_mb))
'''

p_tg = os.path.join(B, "telegram_sender.py")
t_tg = open(p_tg, encoding="utf-8").read()
if "_post_datei" in t_tg:
    print("INFO  telegram_sender.py war schon angepasst")
else:
    if ALT_TG not in t_tg:
        print("ACHT  telegram_sender.py: Stelle nicht gefunden - nichts geaendert")
        fehler.append("telegram_sender.py")
    else:
        shutil.copy2(p_tg, p_tg + ".bak_s6")
        t_tg = t_tg.replace(ALT_TG, NEU_TG, 1)
        alt_gross = '''        hinweis = ('''
        if alt_gross in t_tg:
            t_tg = t_tg.replace(
                '''        return sende_text(kanal, hinweis)''',
                '''        return _notfall(kanal, pfad, beschreibung, groesse_mb)''', 1)
        open(p_tg, "w", encoding="utf-8").write(t_tg + ANHANG_TG)
        r = subprocess.run([sys.executable, "-m", "py_compile", p_tg], capture_output=True, text=True)
        if r.returncode:
            shutil.copy2(p_tg + ".bak_s6", p_tg)
            print("ACHT  telegram_sender.py zurueckgesetzt:", r.stderr[-200:])
            fehler.append("telegram_sender.py")
        else:
            print("OK    telegram_sender.py: schickt das Video selbst")

# ---------- 2. dashboard2.py: Telegram-Schnittstellen ----------
TG_HILFE = '''def telegram_lesen(key):
    d = einstellungen.laden().get(key) or {}
    return {"token": maske(d.get("telegram_token") or ""),
            "chat": d.get("telegram_chat") or "",
            "adresse": d.get("dashboard_adresse") or "",
            "bereit": bool(d.get("telegram_token") and d.get("telegram_chat"))}


def telegram_schreiben(key, b):
    alles = einstellungen.laden()
    d = alles.get(key)
    if not isinstance(d, dict):
        return {"ok": False, "fehler": "Kanal unbekannt"}
    if (b.get("token") or "").strip():
        d["telegram_token"] = b["token"].strip()
    if b.get("chat") is not None:
        d["telegram_chat"] = (b.get("chat") or "").strip()
    if b.get("adresse") is not None:
        d["dashboard_adresse"] = (b.get("adresse") or "").strip().rstrip("/")
    einstellungen.speichern(alles)
    return {"ok": True}


def telegram_test(key):
    d = dict(einstellungen.laden().get(key) or {})
    d.setdefault("id", key)
    d.setdefault("name", d.get("name") or key)
    d.setdefault("emoji", d.get("emoji") or "\\U0001F3AC")
    if not d.get("telegram_token") or not d.get("telegram_chat"):
        return {"ok": False, "fehler": "Token oder Chat-ID fehlt"}
    try:
        import telegram_sender
        ok = telegram_sender.sende_text(d, "%s Test aus dem Dashboard - Telegram funktioniert."
                                        % d.get("emoji", ""))
        return {"ok": bool(ok)} if ok else {"ok": False, "fehler": "Telegram hat abgelehnt"}
    except Exception as e:
        return {"ok": False, "fehler": str(e)[:200]}


'''

tausche("dashboard2.py", [
    ("def api_stand(", TG_HILFE + "def api_stand("),
    ('        if w == "/api/modelle":\n            return self.sende(modelle_lesen(k))',
     '        if w == "/api/telegram":\n            return self.sende(telegram_lesen(k))\n\n'
     '        if w == "/api/modelle":\n            return self.sende(modelle_lesen(k))'),
    ('        if w == "/api/modelle":\n            return self.sende(modelle_schreiben(k, b))',
     '        if w == "/api/telegram":\n            return self.sende(telegram_schreiben(k, b))\n\n'
     '        if w == "/api/telegram_test":\n            return self.sende(telegram_test(k))\n\n'
     '        if w == "/api/modelle":\n            return self.sende(modelle_schreiben(k, b))'),
], "def telegram_lesen")

# ---------- 3. Oberflaeche: Telegram-Bereich in KI & Technik ----------
TG_JS = r'''
/* ---------- Telegram (Patch S6) ---------- */
function ladeTelegram(){return api("/api/telegram?k="+S.kanal).then(function(d){S.tg=d;zeichne()})}
function tgKarte(){
  var t=S.tg;
  if(!t){ladeTelegram();return '<div class="karte p"><div class="leer">lade…</div></div>'}
  var o='<div class="karte p"><h2 class="kt">Telegram</h2>'
   +'<div class="r" style="padding-top:0"><div><div class="lb">Stand</div>'
   +'<div class="hint">'+(t.bereit?"Token und Chat hinterlegt":"noch nicht eingerichtet")+'</div></div>'
   +'<span class="w '+(t.bereit?"gruen":"grau")+'" style="font-size:12px;font-weight:600">'
   +(t.bereit?"bereit":"fehlt")+'</span></div>'
   +'<input type="text" id="tgtok" class="breit" placeholder="'+(t.token?"Token ersetzen (leer = behalten)":"Bot-Token")+'" style="margin-bottom:8px">'
   +'<input type="text" id="tgchat" class="breit" placeholder="Chat-ID" value="'+h(t.chat||"")+'" style="margin-bottom:8px">'
   +'<input type="text" id="tgadr" class="breit" placeholder="Adresse des Dashboards" value="'+h(t.adresse||location.origin)+'" style="margin-bottom:12px">'
   +'<div class="zw"><button class="knopf" onclick="tgTest()">Test senden</button>'
   +'<button class="knopf or" onclick="tgSpeichern()">Speichern</button></div>'
   +'<div class="hinw" style="margin-top:10px">Das fertige Video wird als Datei geschickt. '
   +'Ab etwa 50 MB kommt stattdessen das Vorschaubild mit einer Zeile zum Herunterladen.</div></div>';
  return o;
}
function tgSpeichern(){
  api("/api/telegram?k="+S.kanal,{token:el("tgtok").value,chat:el("tgchat").value,adresse:el("tgadr").value})
    .then(function(r){if(!r.ok)return melde(r.fehler||"ging nicht");ladeTelegram()});
}
function tgTest(){
  api("/api/telegram?k="+S.kanal,{token:el("tgtok").value,chat:el("tgchat").value,adresse:el("tgadr").value})
   .then(function(){return api("/api/telegram_test?k="+S.kanal,{})})
   .then(function(r){ladeTelegram();melde(r.ok?"Testnachricht ist raus — schau in Telegram.":(r.fehler||"ging nicht"))});
}
'''

tausche("dashboard2.html", [
    ("/* ---------- Start ---------- */", TG_JS + "\n/* ---------- Start ---------- */"),
    ("""  o+='<div class="karte p"><div class="hinw" style="padding:0">Der orange Punkt links ist das Modell, das benutzt wird. '""",
     """  o+=tgKarte();
  o+='<div class="karte p"><div class="hinw" style="padding:0">Der orange Punkt links ist das Modell, das benutzt wird. '"""),
    ('videos:[],preis:{},modelle:null,szenen:null,vorlagen:{}',
     'videos:[],preis:{},modelle:null,szenen:null,tg:null,vorlagen:{}'),
    ('function waehle(k){S.kanal=k;S.tab="start";S.modelle=null;S.szenen=null;laden()}',
     'function waehle(k){S.kanal=k;S.tab="start";S.modelle=null;S.szenen=null;S.tg=null;laden()}'),
], "function tgKarte", pruefen=False)

print()
print("NICHT FERTIG:", ", ".join(sorted(set(fehler))) if fehler else "alles durch")
print("TEIL 6 FERTIG")
