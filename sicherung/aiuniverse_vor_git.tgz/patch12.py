# Patch 12: Profi-Bildstil + Kamerafuehrung als Standard
from pathlib import Path

STIL_A = ("cinematic true crime documentary still, 35mm film grain, "
          "deep shadows with pools of light, desaturated cold palette "
          "with one warm accent, shallow depth of field, volumetric fog, "
          "police evidence aesthetic, no faces visible, unsettling and "
          "atmospheric, anamorphic lens flare, moody night photography, "
          "hyperdetailed, professional cinematography")

STIL_B = ("bright bold 3D illustration, cinematic lighting, vibrant orange "
          "and teal palette, soft shadows and rim light, shallow depth of "
          "field, dynamic camera angle, finance symbols (coins, rising "
          "charts, wallet, piggy bank), happy relatable people, optimistic "
          "energetic mood, clean modern look, professional render, "
          "eye-catching social media graphic")

KAMERA_A = """
=== BILDBESCHREIBUNGEN (sehr wichtig fuer den Look) ===
Zeige KONKRETE MOMENTE, keine allgemeinen Motive.
Nenne in JEDER Beschreibung:
1. Kameraeinstellung - wechsle staendig ab:
   extreme close-up / close-up / medium shot / wide shot /
   POV / over-the-shoulder / overhead / low angle / dutch angle
2. Lichtquelle: Taschenlampenkegel, Strassenlaterne, Scheinwerfer
   im Nebel, blaues Polizeilicht, Mondlicht, Neonschild, Kerze
3. Ein erzaehlendes Detail: offene Autotuer, ein Schuh auf der
   Strasse, umgeworfener Stuhl, Polaroid an der Pinnwand,
   roter Faden, Beweistuete, unfertiges Essen, Uhr die stehen blieb

KEINE ganzen Gesichter - nur Silhouetten, Haende, Rueckenansicht,
Umrisse im Gegenlicht.

Schlecht: "dark forest at night"
Gut: "POV shot, flashlight beam cutting through dense fog,
      bare tree trunks blurred at frame edges, wet leaves underfoot"

Schlecht: "old house"
Gut: "wide shot, front door left ajar, warm light spilling onto
      wooden porch, yellowed newspaper still lying on the mat, dusk"

Schlecht: "police investigation"
Gut: "overhead shot of cluttered desk, case file open, three
      polaroids and a red thread, single desk lamp, cold blue window light"
"""

KAMERA_B = """
=== BILDBESCHREIBUNGEN (sehr wichtig fuer den Look) ===
Zeige KONKRETE Situationen statt abstrakter Symbole.
Nenne in JEDER Beschreibung:
1. Kameraeinstellung - wechsle ab:
   close-up / medium shot / wide shot / overhead / low angle /
   dynamic angle
2. Was der Zuschauer davon hat - zeige das ERGEBNIS:
   jemand freut sich, Kontostand waechst, entspannte Person,
   Haekchen, Pfeil nach oben
3. Ein klares Finanz-Symbol im Bild: Muenzen, steigender Chart,
   Sparschwein, Geldbeutel, Rechner, Kalender

Schlecht: "money"
Gut: "close-up of hands holding phone showing growing green chart,
      warm sunlight, coffee cup blurred in foreground"

Schlecht: "saving"
Gut: "overhead shot of coins stacking into three neat piles on a
      bright desk, small calendar and pen beside them, cheerful colors"
"""


def feld_setzen(s, kanal_key, feld, wert):
    """Ersetzt den Standardwert eines Feldes in einstellungen.py."""
    import re
    start = s.find(f'    "{kanal_key}": {{')
    if start < 0:
        return s, False
    ende = s.find('\n    },', start)
    block = s[start:ende]
    muster = re.compile(r'(        "' + feld + r'": ")(.*?)(",\n)', re.S)
    if muster.search(block):
        neu_block = muster.sub(lambda m: m.group(1) + wert + m.group(3), block, count=1)
        return s[:start] + neu_block + s[ende:], True
    return s, False


p = Path('einstellungen.py')
s = p.read_text(encoding='utf-8')

s, ok1 = feld_setzen(s, 'a', 'bildstil', STIL_A)
s, ok2 = feld_setzen(s, 'b', 'bildstil', STIL_B)
print("Bildstil A:", "gesetzt" if ok1 else "NICHT gefunden")
print("Bildstil B:", "gesetzt" if ok2 else "NICHT gefunden")

# Kamerafuehrung in die Master-Prompts
if 'BILDBESCHREIBUNGEN (sehr wichtig' not in s:
    s = s.replace('\nEIGENE THEMEN HIER:', KAMERA_A + '\nEIGENE THEMEN HIER:', 1)
    s = s.replace('\nNEUE THEMEN HIER:', KAMERA_B + '\nNEUE THEMEN HIER:', 1)
    print("Kamerafuehrung in beide Master-Prompts eingebaut")
else:
    print("Kamerafuehrung schon vorhanden")

p.write_text(s, encoding='utf-8')

# Bestehende gespeicherte Werte mitziehen
import json
d = Path('regeln/einstellungen.json')
if d.exists():
    try:
        daten = json.loads(d.read_text(encoding='utf-8'))
        import einstellungen as e
        for kid, stil in (('a', STIL_A), ('b', STIL_B)):
            if kid in daten:
                daten[kid]['bildstil'] = stil
                std = e.STANDARD[kid]['prompt']
                alt = daten[kid].get('prompt', '')
                if 'BILDBESCHREIBUNGEN (sehr wichtig' not in alt:
                    daten[kid]['prompt'] = std
        d.write_text(json.dumps(daten, indent=2, ensure_ascii=False), encoding='utf-8')
        print("Gespeicherte Einstellungen aktualisiert")
    except Exception as f:
        print("Hinweis: gespeicherte Werte nicht angepasst:", str(f)[:80])
print("FERTIG")
