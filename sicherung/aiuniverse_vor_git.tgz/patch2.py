# Patch 2: Videos im Dashboard loeschen
d = open('dashboard.py').read()

if 'video_loeschen' not in d:
    # Backend: Loesch-Funktion
    d = d.replace('''def video_starten(kanal_id, thema=None):''',
'''def video_loeschen(ordner_name):
    import shutil
    ziel = ORDNER_VIDEOS / ordner_name
    if ziel.exists() and ziel.is_dir() and not ordner_name.startswith("_"):
        shutil.rmtree(ziel)
        return True
    return False


def video_starten(kanal_id, thema=None):''')

    # Backend: API-Endpunkt
    d = d.replace('''        elif self.path == "/api/bild_loeschen":''',
'''        elif self.path == "/api/video_loeschen":
            v = json.loads(self._body())
            ok = video_loeschen(v["ordner"])
            self._sende(json.dumps({"ok": ok}))

        elif self.path == "/api/bild_loeschen":''')

    # Frontend: Loesch-Button pro Video
    alt = """    h+='<div class="zeile"><span style="font-size:22px">'+v.emoji+'</span>'
      +'<div class="txt"><div class="t1" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+esc(v.titel)+'</div>'
      +'<div class="t2">'+esc(v.kanal)+' &middot; '+esc(v.ordner)+'</div></div>'
      +'<span style="font-size:10px;font-weight:800;padding:3px 9px;border-radius:20px;background:'
      +(v.fertig?'#e8faf4;color:#008f56':'#fff9e6;color:#cc8800')+'">'+(v.fertig?v.groesse:'laeuft')+'</span></div>';"""
    neu = """    h+='<div class="zeile"><span style="font-size:22px">'+v.emoji+'</span>'
      +'<div class="txt"><div class="t1" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+esc(v.titel)+'</div>'
      +'<div class="t2">'+esc(v.kanal)+' &middot; '+esc(v.ordner)+'</div></div>'
      +'<span style="font-size:10px;font-weight:800;padding:3px 9px;border-radius:20px;background:'
      +(v.fertig?'#e8faf4;color:#008f56':'#fff9e6;color:#cc8800')+'">'+(v.fertig?v.groesse:'laeuft')+'</span>';
    if(vidFrage===v.ordner){
      h+='<button class="chip" style="margin:0;border-color:#ff4060;color:#ff4060" onclick="vidWeg(\\''+v.ordner+'\\')">Wirklich</button>'
       +'<button class="chip" style="margin:0" onclick="vidFrage=null;zeichne()">Nein</button>';
    }else{
      h+='<button class="chip" style="margin:0" onclick="vidFrage=\\''+v.ordner+'\\';zeichne()">&times;</button>';
    }
    h+='</div>';"""
    d = d.replace(alt, neu)

    # Frontend: Variable + Funktion
    d = d.replace("loeschFrage=null, apiFrage=null;", "loeschFrage=null, apiFrage=null, vidFrage=null;")
    if "apiFrage=null;" in d and "vidFrage" not in d.split("var D={}")[1][:200]:
        d = d.replace("var D={}, seite='dash', tab='Einstellungen', loeschFrage=null;",
                      "var D={}, seite='dash', tab='Einstellungen', loeschFrage=null, vidFrage=null;")

    d = d.replace("function start(kid){",
"""function vidWeg(o){
  vidFrage=null;
  fetch('/api/video_loeschen',{method:'POST',body:JSON.stringify({ordner:o})})
    .then(function(){melde('Video geloescht');laden();});
}
function start(kid){""")

    open('dashboard.py','w').write(d)
    print("dashboard.py: Video-Loeschen ergaenzt")
else:
    print("schon vorhanden")
print("FERTIG")
