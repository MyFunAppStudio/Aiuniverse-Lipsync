# -*- coding: utf-8 -*-
import os, shutil, subprocess, sys
B = "/root/aiuniverse"
fehler = []


def tausche(datei, paare, merkmal, pruefen=True):
    p = os.path.join(B, datei)
    t = open(p, encoding="utf-8").read()
    if merkmal in t:
        print("INFO  %s war schon angepasst" % datei)
        return
    for alt, neu in paare:
        if alt not in t:
            print("ACHT  %s: Stelle nicht gefunden -> %r" % (datei, alt[:46]))
            fehler.append(datei)
            return
    shutil.copy2(p, p + ".bak_s10")
    for alt, neu in paare:
        t = t.replace(alt, neu, 1)
    open(p, "w", encoding="utf-8").write(t)
    if pruefen:
        r = subprocess.run([sys.executable, "-m", "py_compile", p], capture_output=True, text=True)
        if r.returncode:
            shutil.copy2(p + ".bak_s10", p)
            print("ACHT  %s zurueckgesetzt: %s" % (datei, r.stderr[-150:]))
            fehler.append(datei)
            return
    print("OK    %s" % datei)


# ---------- 1. szenen.py: Pose, Platz, Groesse je Szene ----------
tausche("szenen.py", [
    ('PASSEN = ["fuellen", "ganz"]',
     'PASSEN = ["fuellen", "ganz"]\n'
     'PLAETZE = ["links_unten", "mitte_unten", "rechts_unten",\n'
     '           "links_oben", "mitte", "rechts_oben"]'),
    ('        if s.get("stimmung") not in ENERGIE:\n            s["stimmung"] = ""',
     '        if s.get("stimmung") not in ENERGIE:\n            s["stimmung"] = ""\n'
     '        s.setdefault("pose", "")\n'
     '        if s.get("platz") not in PLAETZE:\n'
     '            s["platz"] = "rechts_unten"\n'
     '        try:\n'
     '            s["figur_groesse"] = max(10, min(100, int(s.get("figur_groesse") or 55)))\n'
     '        except Exception:\n'
     '            s["figur_groesse"] = 55'),
    ('"passen": "fuellen", "stimmung": "",',
     '"passen": "fuellen", "stimmung": "", "pose": "",\n'
     '                        "platz": "rechts_unten", "figur_groesse": 55,'),
    ('    elif feld == "stimmung":',
     '    elif feld == "pose":\n'
     '        d["szenen"][i]["pose"] = str(wert or "").strip()[:30]\n'
     '    elif feld == "platz":\n'
     '        if str(wert) not in PLAETZE:\n'
     '            return {"ok": False, "fehler": "Unbekannt"}\n'
     '        d["szenen"][i]["platz"] = str(wert)\n'
     '    elif feld == "figur_groesse":\n'
     '        try:\n'
     '            d["szenen"][i]["figur_groesse"] = max(10, min(100, int(float(str(wert).replace(",", ".")))))\n'
     '        except Exception:\n'
     '            return {"ok": False, "fehler": "Zahl zwischen 10 und 100"}\n'
     '    elif feld == "stimmung":'),
    ('            "stimmung": s.get("stimmung", ""),',
     '            "stimmung": s.get("stimmung", ""),\n'
     '            "pose": s.get("pose", ""),\n'
     '            "platz": s.get("platz", "rechts_unten"),\n'
     '            "figur_groesse": s.get("figur_groesse", 55),'),
], "PLAETZE")

# ---------- 2. szenen_video.py: Figur ins Bild kopieren ----------
ALT_BILD = '''def _stueck_bild(quelle, ziel, bewegung, nr, dauer, b, h, fps, passen="fuellen"):
    hinten = ["-r", str(fps), "-pix_fmt", "yuv420p", "-c:v", "libx264",
              "-preset", "veryfast", "-crf", "22", "-an", str(ziel)]
    vorn = ["ffmpeg", "-y", "-loglevel", "error", "-loop", "1", "-i", str(quelle),
            "-t", "%.3f" % dauer]
    if passen == "ganz":
        befehl = vorn + ["-filter_complex", _ganz(bewegung, nr, dauer, b, h, fps),
                         "-map", "[v]"] + hinten
    else:
        befehl = vorn + ["-vf", _zoompan(bewegung, nr, dauer, b, h, fps)] + hinten
    return _lauf(befehl).returncode == 0'''

NEU_BILD = '''def _figur_filter(platz, groesse, b, h, rein, raus):
    """Haengt die freigestellte Figur ins Bild."""
    rand = int(b * 0.045)
    unten = int(h * 0.20)
    hoehe = max(40, int(h * max(10, min(100, groesse)) / 100.0))
    x = {"links_unten": str(rand), "mitte_unten": "(W-w)/2", "rechts_unten": "W-w-%d" % rand,
         "links_oben": str(rand), "rechts_oben": "W-w-%d" % rand,
         "mitte": "(W-w)/2"}.get(platz, "W-w-%d" % rand)
    y = {"links_unten": "H-h-%d" % unten, "mitte_unten": "H-h-%d" % unten,
         "rechts_unten": "H-h-%d" % unten, "links_oben": str(rand),
         "rechts_oben": str(rand), "mitte": "(H-h)/2"}.get(platz, "H-h-%d" % unten)
    return ("[1:v]scale=-2:%d:force_original_aspect_ratio=decrease,format=rgba[fig];"
            "%s[fig]overlay=%s:%s:format=auto%s" % (hoehe, rein, x, y, raus))


def _stueck_bild(quelle, ziel, bewegung, nr, dauer, b, h, fps, passen="fuellen", figur=None):
    vorn = ["ffmpeg", "-y", "-loglevel", "error", "-loop", "1", "-i", str(quelle)]
    if passen == "ganz":
        grund = _ganz(bewegung, nr, dauer, b, h, fps)
    else:
        grund = "[0:v]" + _zoompan(bewegung, nr, dauer, b, h, fps) + "[v]"
    if figur and os.path.exists(figur.get("pfad") or ""):
        vorn += ["-loop", "1", "-i", str(figur["pfad"])]
        stelle = grund.rfind("[v]")
        grund = (grund[:stelle] + "[v0];"
                 + _figur_filter(figur.get("platz"), figur.get("groesse", 55), b, h, "[v0]", "[v]"))
    return _lauf(vorn + ["-filter_complex", grund, "-map", "[v]", "-t", "%.3f" % dauer,
                         "-r", str(fps), "-pix_fmt", "yuv420p", "-c:v", "libx264",
                         "-preset", "veryfast", "-crf", "22", "-an", str(ziel)]).returncode == 0'''

ALT_CLIP = '''def _stueck_clip(quelle, ziel, dauer, b, h, fps):
    vf = ("scale=%d:%d:force_original_aspect_ratio=increase,crop=%d:%d,"
          "setsar=1,fps=%d,tpad=stop_mode=clone:stop_duration=%.3f" % (b, h, b, h, fps, dauer))
    r = _lauf(["ffmpeg", "-y", "-loglevel", "error", "-i", str(quelle),
               "-vf", vf, "-t", "%.3f" % dauer, "-r", str(fps),
               "-pix_fmt", "yuv420p", "-c:v", "libx264", "-preset", "veryfast",
               "-crf", "22", "-an", str(ziel)])
    return r.returncode == 0'''

NEU_CLIP = '''def _stueck_clip(quelle, ziel, dauer, b, h, fps, figur=None):
    grund = ("[0:v]scale=%d:%d:force_original_aspect_ratio=increase,crop=%d:%d,"
             "setsar=1,fps=%d,tpad=stop_mode=clone:stop_duration=%.3f[v]"
             % (b, h, b, h, fps, dauer))
    vorn = ["ffmpeg", "-y", "-loglevel", "error", "-i", str(quelle)]
    if figur and os.path.exists(figur.get("pfad") or ""):
        vorn += ["-loop", "1", "-i", str(figur["pfad"])]
        grund = (grund[:grund.rfind("[v]")] + "[v0];"
                 + _figur_filter(figur.get("platz"), figur.get("groesse", 55), b, h, "[v0]", "[v]"))
    r = _lauf(vorn + ["-filter_complex", grund, "-map", "[v]", "-t", "%.3f" % dauer,
                      "-r", str(fps), "-pix_fmt", "yuv420p", "-c:v", "libx264",
                      "-preset", "veryfast", "-crf", "22", "-an", str(ziel)])
    return r.returncode == 0'''

ALT_RUF = '''        ok = (_stueck_clip(s["quelle"], ziel, s["dauer"], b, h, fps) if s["typ"] == "clip"
              else _stueck_bild(s["quelle"], ziel, s["bewegung"], i, s["dauer"], b, h, fps,
                                s.get("passen", "fuellen")))'''
NEU_RUF = '''        fig = _figur_fuer(kanal, s)
        ok = (_stueck_clip(s["quelle"], ziel, s["dauer"], b, h, fps, fig) if s["typ"] == "clip"
              else _stueck_bild(s["quelle"], ziel, s["bewegung"], i, s["dauer"], b, h, fps,
                                s.get("passen", "fuellen"), fig))'''

HILFE = '''def _figur_fuer(kanal, s):
    """Welche Figur in welcher Pose kommt in diese Szene."""
    name = (s.get("figur") or "").strip()
    if not name:
        return None
    try:
        import figuren
        pfad = figuren.pose_pfad(kanal, name, s.get("pose"))
    except Exception as e:
        print("[Szenen] Figur nicht nutzbar:", e)
        return None
    if not pfad or not os.path.exists(pfad):
        return None
    return {"pfad": pfad, "platz": s.get("platz", "rechts_unten"),
            "groesse": s.get("figur_groesse", 55)}


'''

tausche("szenen_video.py", [
    (ALT_BILD, NEU_BILD),
    (ALT_CLIP, NEU_CLIP),
    ("def _stimme_fuer(", HILFE + "def _stimme_fuer("),
    (ALT_RUF, NEU_RUF),
    ('"stimmung": s.get("stimmung", ""), "figur": s.get("figur", ""),',
     '"stimmung": s.get("stimmung", ""), "figur": s.get("figur", ""),\n'
     '                     "pose": s.get("pose", ""), "platz": s.get("platz", "rechts_unten"),\n'
     '                     "figur_groesse": s.get("figur_groesse", 55),'),
], "def _figur_filter")

# Stimme der Figur hat Vorrang vor der Stimmenliste
tausche("szenen_video.py", [
    ('''    for e in (kanal.get("stimmen") or []):
        if isinstance(e, dict) and (e.get("name") or "").strip().lower() == name:
            return (e.get("id") or "").strip() or None
    return None''',
     '''    try:
        import figuren
        f = figuren.holen(kanal, name)
        if f and (f.get("stimme") or "").strip():
            return f["stimme"].strip()
    except Exception:
        pass
    for e in (kanal.get("stimmen") or []):
        if isinstance(e, dict) and (e.get("name") or "").strip().lower() == name:
            return (e.get("id") or "").strip() or None
    return None'''),
], "import figuren\n        f = figuren.holen")

# ---------- 3. dashboard2.py: Figuren-Schnittstellen ----------
FIG_HILFE = '''def figuren_lesen(key):
    d = figuren.fuer_anzeige(key)
    d["stimmen"] = [[e.get("name", ""), e.get("id", "")]
                    for e in ((einstellungen.laden().get(key) or {}).get("stimmen") or [])
                    if isinstance(e, dict) and e.get("name")]
    return d


def figuren_schreiben(key, b):
    a = b.get("aktion") or ""
    name = b.get("name") or ""
    if a == "neu":
        return figuren.anlegen(key, name)
    if a == "weg":
        return figuren.entfernen(key, name)
    if a in ("umbenennen", "stimme", "beschreibung"):
        feld = "name" if a == "umbenennen" else a
        return figuren.aendern(key, name, feld, b.get("wert"))
    if a == "pose_weg":
        return figuren.pose_weg(key, name, b.get("datei") or "")
    if a == "freistellen":
        return figuren.pose_freistellen(key, name, b.get("datei") or "")
    return {"ok": False, "fehler": "Aktion unbekannt"}


'''

tausche("dashboard2.py", [
    ("sys.path.insert(0, BASIS)\nimport szenen",
     "sys.path.insert(0, BASIS)\nimport szenen\nimport figuren"),
    ("def telegram_lesen(", FIG_HILFE + "def telegram_lesen("),
    ('        if w == "/api/telegram":\n            return self.sende(telegram_lesen(k))',
     '        if w == "/api/figuren":\n            return self.sende(figuren_lesen(k))\n\n'
     '        if w == "/api/telegram":\n            return self.sende(telegram_lesen(k))'),
    ('        if w == "/api/telegram":\n            return self.sende(telegram_schreiben(k, b))',
     '        if w == "/api/figuren":\n            return self.sende(figuren_schreiben(k, b))\n\n'
     '        if w == "/api/telegram":\n            return self.sende(telegram_schreiben(k, b))'),
    ('        if w.startswith("/eigen/"):\n'
     '            return self.datei(szenen.datei_pfad(k, unquote(w[7:])))',
     '        if w.startswith("/figur/"):\n'
     '            return self.datei(figuren.datei_pfad(k, unquote(w[7:])))\n\n'
     '        if w.startswith("/eigen/"):\n'
     '            return self.datei(szenen.datei_pfad(k, unquote(w[7:])))'),
    ('        if zweck == "musik" and a != "ton":',
     '        if zweck == "figur":\n'
     '            if a != "bild":\n'
     '                return self.sende({"ok": False, "fehler": "Nur Bilder, am besten PNG"}, code=400)\n'
     '            fig = (q.get("figur") or [""])[0]\n'
     '            if not figuren.holen(k, fig):\n'
     '                return self.sende({"ok": False, "fehler": "Figur unbekannt"}, code=400)\n'
     '            zname = szenen.sauberer_name(name)\n'
     '            ziel = os.path.join(figuren.ordner(k), zname)\n'
     '            rest = n\n'
     '            try:\n'
     '                with open(ziel, "wb") as f:\n'
     '                    while rest > 0:\n'
     '                        stueck = self.rfile.read(min(262144, rest))\n'
     '                        if not stueck:\n'
     '                            break\n'
     '                        f.write(stueck)\n'
     '                        rest -= len(stueck)\n'
     '            except Exception:\n'
     '                rest = -1\n'
     '            if rest != 0:\n'
     '                try:\n'
     '                    os.remove(ziel)\n'
     '                except Exception:\n'
     '                    pass\n'
     '                return self.sende({"ok": False, "fehler": "Hochladen abgebrochen"}, code=400)\n'
     '            figuren.pose_dazu(k, fig, zname, (q.get("pose") or [""])[0])\n'
     '            return self.sende({"ok": True, "datei": zname})\n\n'
     '        if zweck == "musik" and a != "ton":'),
], "def figuren_lesen")

# ---------- 4. Oberflaeche: Charaktere-Reiter und Figur je Szene ----------
FIG_JS = r'''
/* ---------- Charaktere (Patch S10) ---------- */
function ladeFiguren(){return api("/api/figuren?k="+S.kanal).then(function(d){S.fig=d;zeichne()})}
function figSetz(name,aktion,wert,datei){
  var d={aktion:aktion,name:name};
  if(wert!==undefined)d.wert=wert;
  if(datei!==undefined)d.datei=datei;
  return api("/api/figuren?k="+S.kanal,d).then(function(r){
    if(!r.ok){melde(r.fehler||"ging nicht");return r}
    return ladeFiguren().then(function(){return r})});
}
function figNeu(){
  el("dialog").innerHTML='<div class="dim"><div class="dlg"><h2>Neue Figur</h2>'
   +'<p>Der Name steht später im Szenen-Editor zur Auswahl.</p>'
   +'<input type="text" id="fign" class="breit" placeholder="z.B. Oma, Monster, Maskottchen" style="margin-bottom:14px">'
   +'<div class="zw"><button class="knopf" onclick="zu()">Abbrechen</button>'
   +'<button class="knopf or" onclick="figAnlegen()">Anlegen</button></div></div></div>';
}
function figAnlegen(){
  var n=(el("fign").value||"").trim();
  if(!n)return melde("Name darf nicht leer sein.");
  figSetz(n,"neu").then(function(r){if(r&&r.ok)zu()});
}
function figWeg(n){
  frage("Figur löschen?","<b>"+h(n)+"</b><br><br>Die Figur und alle ihre Posen werden gelöscht.",
    "Löschen",function(){figSetz(n,"weg")},true);
}
function poseWeg(n,d){
  frage("Pose löschen?","Die Bilddatei wird gelöscht.","Löschen",function(){figSetz(n,"pose_weg",undefined,d)},true);
}
function poseFrei(n,d){
  melde("Hintergrund wird entfernt…");
  figSetz(n,"freistellen",undefined,d).then(function(r){if(r&&r.ok)zu()});
}
function poseHoch(n){
  var i=document.createElement("input");
  i.type="file"; i.accept="image/*";
  i.onchange=function(){
    var f=i.files&&i.files[0];if(!f)return;
    if(f.size>20*1024*1024){melde("Bild zu groß — höchstens 20 MB.");return}
    var pose=prompt("Name der Pose (z.B. winkt, zeigt, erstaunt)","Pose");
    el("dialog").innerHTML='<div class="dim"><div class="dlg"><h2>Lädt hoch</h2><p id="hpro">'+h(f.name)+' · 0 %</p></div></div>';
    var x=new XMLHttpRequest();
    x.open("POST","/api/hochladen?k="+encodeURIComponent(S.kanal)+"&zweck=figur&figur="
      +encodeURIComponent(n)+"&pose="+encodeURIComponent(pose||"")+"&name="+encodeURIComponent(f.name));
    x.upload.onprogress=function(e){if(e.lengthComputable&&el("hpro"))el("hpro").textContent=f.name+" · "+Math.round(e.loaded/e.total*100)+" %"};
    x.onload=function(){zu();var r={};try{r=JSON.parse(x.responseText)}catch(err){}
      if(!r.ok)return melde(r.fehler||"Hochladen ging nicht");ladeFiguren()};
    x.onerror=function(){zu();melde("Hochladen fehlgeschlagen")};
    x.send(f);
  };
  i.click();
}
function tFiguren(){
  var d=S.fig;
  if(!d){ladeFiguren();return '<div class="karte p"><div class="leer">lade…</div></div>'}
  var o='';
  if(!(d.figuren||[]).length)
    o+='<div class="karte p"><div class="leer">noch keine Figur angelegt</div></div>';
  (d.figuren||[]).forEach(function(f){
    o+='<div class="karte p"><div class="kopf" style="display:flex;align-items:center;gap:8px;margin-bottom:8px">'
     +'<h2 class="kt" style="flex:1;margin:0">'+h(f.name)+'</h2>'
     +'<button class="ik rot" onclick="figWeg(\''+h(f.name).replace(/'/g,"")+'\')">✕</button></div>';
    o+='<div class="szz"><span class="szh">Stimme</span><select onchange="figSetz(\''+h(f.name).replace(/'/g,"")+'\',\'stimme\',this.value)">'
     +'<option value="">Kanalstimme</option>'
     +(d.stimmen||[]).map(function(s){return '<option value="'+h(s[1])+'"'+(f.stimme===s[1]?" selected":"")+'>'+h(s[0])+'</option>'}).join("")
     +'</select></div>';
    o+='<div class="liste" style="margin-top:9px">';
    if(!f.posen.length)o+='<div class="leer">keine Pose — lade ein Bild hoch</div>';
    f.posen.forEach(function(p){
      o+='<div class="e"><img src="/figur/'+encodeURIComponent(p.datei)+'?k='+S.kanal+'" '
       +'style="width:44px;height:58px;object-fit:contain;background:#0B0B0D;border-radius:7px">'
       +'<div class="tx"><div class="ti">'+h(p.name)+'</div><div class="me">'+h(p.datei)+'</div></div>'
       +'<button class="ik" title="Hintergrund entfernen" onclick="poseFrei(\''+h(f.name).replace(/'/g,"")+'\',\''+h(p.datei).replace(/'/g,"")+'\')">✂</button>'
       +'<button class="ik rot" onclick="poseWeg(\''+h(f.name).replace(/'/g,"")+'\',\''+h(p.datei).replace(/'/g,"")+'\')">✕</button></div>';
    });
    o+='</div><button class="knopf" style="width:100%;margin-top:9px" onclick="poseHoch(\''+h(f.name).replace(/'/g,"")+'\')">+ Pose hochladen</button></div>';
  });
  o+='<button class="knopf or" style="width:100%;margin-bottom:10px" onclick="figNeu()">+ Neue Figur</button>';
  o+='<div class="karte p"><div class="hinw" style="padding:0">Eine Figur ist ein Satz freigestellter Bilder — dieselbe Figur in verschiedenen Posen. '
   +'Mit der Schere entfernst du einen einfarbigen Hintergrund. Im Szenen-Editor wählst du pro Szene Figur, Pose, Platz und Größe; '
   +'die hier zugeordnete Stimme spricht dann diese Szene.</div></div>';
  return o;
}
function figurNamen(){return ((S.fig||{}).figuren||[]).map(function(f){return f.name})}
function posenVon(n){
  var f=((S.fig||{}).figuren||[]).filter(function(x){return x.name===n})[0];
  return f?f.posen.map(function(p){return p.name}):[];
}
'''

ALT_FIGZEILE = '''    o+='<div class="szz"><span class="szh">Figur</span><input type="text" style="width:104px" placeholder="Kanalstimme" value="'
      +h(s.figur||"")+'" onchange="szeneSetz(\\''+s.id+'\\',\\'figur\\',this.value)"></div>';'''

NEU_FIGZEILE = '''    if(!S.fig)ladeFiguren();
    var fn=figurNamen();
    o+='<div class="szz"><span class="szh">Figur</span><select onchange="szeneSetz(\\''+s.id+'\\',\\'figur\\',this.value)">'
      +'<option value="">keine</option>'
      +fn.map(function(n){return '<option value="'+h(n)+'"'+(s.figur===n?" selected":"")+'>'+h(n)+'</option>'}).join("")
      +'</select></div>';
    if(s.figur){
      var po=posenVon(s.figur);
      o+='<div class="szz"><span class="szh">Pose</span><select onchange="szeneSetz(\\''+s.id+'\\',\\'pose\\',this.value)">'
        +'<option value="">erste</option>'
        +po.map(function(n){return '<option value="'+h(n)+'"'+(s.pose===n?" selected":"")+'>'+h(n)+'</option>'}).join("")
        +'</select></div>';
      o+='<div class="szz"><span class="szh">Platz</span><select onchange="szeneSetz(\\''+s.id+'\\',\\'platz\\',this.value)">'
        +(((S.fig||{}).plaetze)||[]).map(function(x){return '<option value="'+x[0]+'"'+(s.platz===x[0]?" selected":"")+'>'+h(x[1])+'</option>'}).join("")
        +'</select><span class="szh">Größe</span><input type="text" style="width:54px" value="'+h(String(s.figur_groesse||55))
        +'" onchange="szeneSetz(\\''+s.id+'\\',\\'figur_groesse\\',this.value)"><span class="szh">%</span></div>';
    }'''

tausche("dashboard2.html", [
    ("/* ---------- Start ---------- */", FIG_JS + "\n/* ---------- Start ---------- */"),
    (ALT_FIGZEILE, NEU_FIGZEILE),
    ('["figuren","Charaktere","Feste Figuren mit eigener Stimme und eigene Bilder. Kommt im nächsten Schritt."]',
     '["figuren","Charaktere","Figuren mit fester Stimme und freigestellten Posen. Im Szenen-Editor waehlst du, wer wo im Bild steht."]'),
    ('videos:[],preis:{},modelle:null,szenen:null,tg:null,vorlagen:{}',
     'videos:[],preis:{},modelle:null,szenen:null,tg:null,fig:null,vorlagen:{}'),
    ('function waehle(k){S.kanal=k;S.tab="start";S.modelle=null;S.szenen=null;S.tg=null;laden()}',
     'function waehle(k){S.kanal=k;S.tab="start";S.modelle=null;S.szenen=null;S.tg=null;S.fig=null;laden()}'),
    ('''  return '<div class="karte p"><h2 class="kt">Charaktere &amp; Bilder</h2>''',
     '''  return tFiguren();
}
function tFigurenAlt(){
  return '<div class="karte p"><h2 class="kt">Charaktere &amp; Bilder</h2>'''),
], "function ladeFiguren", pruefen=False)

print()
print("NICHT FERTIG:", ", ".join(sorted(set(fehler))) if fehler else "alles durch")
print("TEIL 10 FERTIG")
