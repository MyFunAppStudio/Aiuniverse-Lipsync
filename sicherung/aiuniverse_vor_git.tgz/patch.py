# Patch: APIs pro Kanal (mehrere Anbieter, Aktiv-Button)
import re

# --- 1. einstellungen.py ---
s = open('einstellungen.py').read()
if '"apis"' not in s:
    blk = '''        "apis": {
            "text":   [{"name":"Anthropic Claude","key":"","url":"https://api.anthropic.com","aktiv":True}],
            "stimme": [{"name":"ElevenLabs (fal.ai)","key":"","url":"fal-ai/elevenlabs/tts/multilingual-v2","aktiv":True},
                       {"name":"ElevenLabs direkt","key":"","url":"https://api.elevenlabs.io","aktiv":False}],
            "video":  [{"name":"Kling (fal.ai)","key":"","url":"fal-ai/kling-video/v2/standard","aktiv":True},
                       {"name":"Veo 3.1 (fal.ai)","key":"","url":"fal-ai/veo3","aktiv":False},
                       {"name":"Kling direkt","key":"","url":"https://api.klingai.com","aktiv":False},
                       {"name":"Grok","key":"","url":"https://api.x.ai","aktiv":False}],
            "bilder": [{"name":"Flux (fal.ai)","key":"","url":"fal-ai/flux/schnell","aktiv":True},
                       {"name":"Flux Pro (fal.ai)","key":"","url":"fal-ai/flux-pro","aktiv":False}],
            "avatar": [{"name":"Hedra","key":"","url":"https://api.hedra.com","aktiv":True},
                       {"name":"HeyGen","key":"","url":"https://api.heygen.com","aktiv":False}],
            "sound":  [{"name":"Freesound","key":"","url":"https://freesound.org/apiv2","aktiv":True}],
        },
'''
    s = s.replace('        "telegram_token": "",', blk + '        "telegram_token": "",')
    s = s.replace('SPRACHEN_LISTE = ', '''API_SLOTS = [
    ("text","TEXT / Skript","Skripte, Titel, Beschreibungen"),
    ("stimme","STIMME","Erzaehler- oder Charakterstimme"),
    ("video","VIDEO","Charakter animieren, Clips (Kling, Veo, Grok)"),
    ("bilder","BILDER","Hintergrundbilder, Thumbnails, Grafiken"),
    ("avatar","AVATAR","Lippensync - Gesicht zum Sprechen bringen"),
    ("sound","SOUNDEFFEKTE","Wind, Schritte, Atmosphaere"),
]

SPRACHEN_LISTE = ''', 1)
    s = s.replace('def laenge_in_minuten(k):', '''def aktive_api(kanal, slot):
    for e in kanal.get("apis", {}).get(slot, []):
        if e.get("aktiv"):
            return e
    return None


def laenge_in_minuten(k):''', 1)
    open('einstellungen.py','w').write(s)
    print("einstellungen.py: APIs ergaenzt")
else:
    print("einstellungen.py: schon vorhanden")

# --- 2. dashboard.py ---
d = open('dashboard.py').read()
if 'tabApis' not in d:
    d = d.replace("var tabs=['Einstellungen','Bilder','Texte & CTA','Prompt','Manuell'];",
                  "var tabs=['Einstellungen','Bilder','APIs','Texte & CTA','Prompt','Manuell'];")
    d = d.replace("  else if(tab=='Texte & CTA')h+=tabTexte(kid,k);",
                  "  else if(tab=='APIs')h+=tabApis(kid,k);\n  else if(tab=='Texte & CTA')h+=tabTexte(kid,k);")
    d = d.replace("var D={}, seite='dash', tab='Einstellungen', loeschFrage=null;",
                  "var D={}, seite='dash', tab='Einstellungen', loeschFrage=null, apiFrage=null;")
    d = d.replace('"sprachen": einstellungen.SPRACHEN_LISTE,',
                  '"sprachen": einstellungen.SPRACHEN_LISTE,\n                "apislots": einstellungen.API_SLOTS,')
    neu = r'''
function tabApis(kid,k){
  var h='<div class="info">Pro Funktion mehrere Anbieter - nur der GRUENE ist aktiv. Waehlst du "Kling (fal.ai)" traegst du deinen fal.ai Key ein. Waehlst du "Kling direkt" den Kling-Key.</div>';
  h+='<div class="info w">fal.ai = EIN Key fuer Kling, Veo, Flux, ElevenLabs. Nur die URL unterscheidet sich.</div>';
  D.apislots.forEach(function(sl){
    var slot=sl[0], titel=sl[1], hin=sl[2];
    if(slot=='avatar' && !k.mit_avatar) return;
    var liste=(k.apis&&k.apis[slot])?k.apis[slot]:[];
    var akt='';
    liste.forEach(function(e){ if(e.aktiv) akt=e.name; });
    h+='<div class="karte"><h2>'+titel+'</h2><div class="inh">';
    h+='<div class="mini" style="margin-bottom:10px">'+hin+' &middot; <b style="color:'+(akt?'#00997a':'#cc2244')+'">'+(akt?'Aktiv: '+esc(akt):'keine aktiv!')+'</b></div>';
    liste.forEach(function(e,i){
      var an=!!e.aktiv;
      h+='<div style="border:1.5px solid '+(an?'#00c97a':'#e4e8f2')+';background:'+(an?'#e8faf4':'#fafbfe')+';border-radius:9px;padding:9px;margin-bottom:8px">';
      h+='<div style="display:flex;gap:7px;align-items:center;margin-bottom:7px">';
      h+='<button class="chip '+(an?'an':'')+'" style="margin:0" onclick="apiAktiv(\''+kid+'\',\''+slot+'\','+i+')">'+(an?'Aktiv &#10003;':'Aktivieren')+'</button>';
      h+='<div style="flex:1"></div>';
      if(apiFrage===kid+slot+i){
        h+='<button class="chip" style="margin:0;border-color:#ff4060;color:#ff4060" onclick="apiWeg(\''+kid+'\',\''+slot+'\','+i+')">Wirklich</button>';
        h+='<button class="chip" style="margin:0" onclick="apiFrage=null;zeichne()">Nein</button>';
      }else{
        h+='<button class="chip" style="margin:0" onclick="apiFrage=\''+kid+slot+i+'\';zeichne()">Loeschen</button>';
      }
      h+='</div>';
      h+='<input type="text" style="margin-bottom:6px" placeholder="Name" value="'+esc(e.name)+'" onchange="apiSetz(\''+kid+'\',\''+slot+'\','+i+',\'name\',this.value)">';
      h+='<input type="password" style="margin-bottom:6px;background:#f2f4f9" placeholder="API Key" value="'+esc(e.key)+'" onchange="apiSetz(\''+kid+'\',\''+slot+'\','+i+',\'key\',this.value)">';
      h+='<input type="text" style="font-size:11px;color:#8b95b0" placeholder="URL" value="'+esc(e.url)+'" onchange="apiSetz(\''+kid+'\',\''+slot+'\','+i+',\'url\',this.value)">';
      h+='</div>';
    });
    h+='<button class="chip" style="width:100%;border-style:dashed;padding:9px" onclick="apiNeu(\''+kid+'\',\''+slot+'\')">+ Weitere Option</button>';
    h+='</div></div>';
  });
  return h;
}
function apiSetz(kid,slot,i,f,w){ D.kanaele[kid].apis[slot][i][f]=w; sichern(); }
function apiAktiv(kid,slot,i){ D.kanaele[kid].apis[slot].forEach(function(e,j){e.aktiv=(j===i)}); zeichne(); sichern(); }
function apiNeu(kid,slot){ if(!D.kanaele[kid].apis[slot])D.kanaele[kid].apis[slot]=[];
  D.kanaele[kid].apis[slot].push({name:'',key:'',url:'',aktiv:false}); zeichne(); sichern(); }
function apiWeg(kid,slot,i){ apiFrage=null; D.kanaele[kid].apis[slot].splice(i,1); zeichne(); sichern(); }
'''
    d = d.replace('\nfunction viewSys(){', neu + '\nfunction viewSys(){', 1)
    open('dashboard.py','w').write(d)
    print("dashboard.py: APIs-Tab ergaenzt")
else:
    print("dashboard.py: schon vorhanden")

print("FERTIG")
