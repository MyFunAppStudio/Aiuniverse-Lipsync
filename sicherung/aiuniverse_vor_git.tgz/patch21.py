# ============================================
# Patch 21: Videolaenge ueberall in SEKUNDEN
# ============================================
from pathlib import Path
import json

# ---------- 1. Standardwerte auf Sekunden ----------
p = Path('einstellungen.py')
s = p.read_text(encoding='utf-8')

if '"laenge": 7,' in s and '"laenge_einheit": "Min"' in s:
    s = s.replace('        "laenge": 7,\n        "laenge_einheit": "Min",\n'
                  '        "laenge_min": 1,\n        "laenge_max": 60,',
                  '        "laenge": 120,\n        "laenge_einheit": "Sek",\n'
                  '        "laenge_min": 10,\n        "laenge_max": 3600,')
    print("1. Kanal A: Standard jetzt 120 Sekunden")

# Kanal B Grenzen erweitern (ab 10 Sek testen)
s = s.replace('        "laenge_min": 15,\n        "laenge_max": 600,',
              '        "laenge_min": 10,\n        "laenge_max": 1800,')
p.write_text(s, encoding='utf-8')
print("   Kanal B: 10 bis 1800 Sekunden erlaubt")

# ---------- 2. Gespeicherte Werte umrechnen ----------
d = Path('regeln/einstellungen.json')
if d.exists():
    try:
        daten = json.loads(d.read_text(encoding='utf-8'))
        geaendert = False
        for kid in list(daten.keys()):
            k = daten[kid]
            if k.get('laenge_einheit') == 'Min':
                alt = k.get('laenge', 2)
                k['laenge'] = int(alt * 60)
                k['laenge_einheit'] = 'Sek'
                k['laenge_min'] = 10
                k['laenge_max'] = 3600
                geaendert = True
                print(f"2. {kid}: {alt} Min -> {k['laenge']} Sek umgerechnet")
            else:
                k['laenge_min'] = 10
                k['laenge_max'] = 1800 if kid == 'b' else 3600
                geaendert = True
        if geaendert:
            d.write_text(json.dumps(daten, indent=2, ensure_ascii=False), encoding='utf-8')
    except Exception as f:
        print("2. Hinweis:", str(f)[:100])

# ---------- 3. Dashboard: Minuten daneben anzeigen ----------
p = Path('dashboard.py')
s = p.read_text(encoding='utf-8')

if 'alsMinuten' not in s:
    s = s.replace("""function laengeFeld(kid,k){""",
"""function alsMinuten(sek){
  if(sek < 60) return sek+' Sek';
  var m = Math.floor(sek/60), r = sek%60;
  return m+':'+(r<10?'0':'')+r+' Min';
}

function laengeFeld(kid,k){""", 1)

    # Anzeige unter dem Feld erweitern
    s = s.replace("""    +'<div class="mini">Erlaubt: '+min+' bis '+max+' '+k.laenge_einheit""",
"""    +'<div class="mini" style="font-size:13px;color:#0f1623;font-weight:700;margin-top:6px">'
    +'Das sind: '+alsMinuten(k.laenge_einheit==='Sek'?k.laenge:k.laenge*60)+'</div>'
    +'<div class="mini">Erlaubt: '+min+' bis '+max+' '+k.laenge_einheit""")

    print("3. Dashboard: Minuten-Anzeige unter dem Eingabefeld")
else:
    print("3. Dashboard: schon ok")

# ---------- 4. Kostenanzeige auf Sekunden anpassen ----------
if "k.laenge_einheit==='Sek') ? (k.laenge/60) : k.laenge" in s:
    print("4. Kostenrechnung: passt bereits")

p.write_text(s, encoding='utf-8')
print("FERTIG - Seite neu laden")
