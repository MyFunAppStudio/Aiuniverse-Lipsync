# Patch 14: Wartungs-Reiter - Patches bequem im Browser einfuegen
from pathlib import Path
import secrets

p = Path('dashboard.py'); s = p.read_text(encoding='utf-8')
if 'api/patch' in s:
    print("schon eingebaut")
else:
    # Token erzeugen
    tdat = Path('regeln/wartung.txt')
    tdat.parent.mkdir(parents=True, exist_ok=True)
    if tdat.exists():
        token = tdat.read_text().strip()
    else:
        token = secrets.token_urlsafe(12)
        tdat.write_text(token)

    # --- Backend ---
    s = s.replace('''        elif pfad == "/api/daten":''',
'''        elif pfad == "/api/wartung":
            from urllib.parse import urlparse, parse_qs
            q = parse_qs(urlparse(self.path).query)
            gegeben = q.get("t", [""])[0]
            echt = (BASIS / "regeln" / "wartung.txt").read_text().strip()
            self._sende(json.dumps({"frei": gegeben == echt}))

        elif pfad == "/api/daten":''')

    s = s.replace('''        if self.path == "/api/einstellungen":''',
'''        if self.path.startswith("/api/patch"):
            from urllib.parse import urlparse, parse_qs
            import base64, zlib, subprocess, traceback
            q = parse_qs(urlparse(self.path).query)
            echt = (BASIS / "regeln" / "wartung.txt").read_text().strip()
            if q.get("t", [""])[0] != echt:
                self._sende(json.dumps({"ok": False, "text": "Kein Zugang"}))
                return
            roh = self._body().strip()
            try:
                sauber = "".join(roh.split())
                daten = base64.b64decode(sauber)
                try:
                    daten = zlib.decompress(daten, 47)
                except Exception:
                    pass
                ziel = BASIS / "patch_neu.py"
                ziel.write_bytes(daten)
                lauf = subprocess.run(["python3", str(ziel)], cwd=str(BASIS),
                                      capture_output=True, text=True, timeout=180)
                ausgabe = (lauf.stdout + lauf.stderr)[-2000:]
                self._sende(json.dumps({"ok": lauf.returncode == 0, "text": ausgabe}))
            except Exception as f:
                self._sende(json.dumps({"ok": False,
                                        "text": "Fehler: " + str(f)[:300]}))

        elif self.path == "/api/einstellungen":''')

    # --- Frontend: Reiter ---
    s = s.replace("""  n+='<button class="'+(seite=='sys'?'an':'')+'" onclick="geh(\\'sys\\')">System</button>';""",
"""  n+='<button class="'+(seite=='sys'?'an':'')+'" onclick="geh(\\'sys\\')">System</button>';
  if(WTOKEN){n+='<button class="'+(seite=='wartung'?'an':'')+'" onclick="geh(\\'wartung\\')">Wartung</button>';}""")

    s = s.replace("""  else if(seite=='sys')h=viewSys();""",
"""  else if(seite=='sys')h=viewSys();
  else if(seite=='wartung')h=viewWartung();""")

    s = s.replace("""function viewSys(){""",
"""var WTOKEN=(location.search.match(/[?&]t=([^&]+)/)||[])[1]||'';

function viewWartung(){
  return '<div class="karte"><h2>Patch einspielen</h2><div class="inh">'
    +'<div class="info">Den Code-Block hier einfuegen und auf Einspielen druecken. Danach startet das Dashboard automatisch neu.</div>'
    +'<textarea id="pfeld" class="hoch" placeholder="Code hier einfuegen..." style="font-size:11px"></textarea>'
    +'<button class="btn d" onclick="patchLos()">Einspielen</button>'
    +'<div id="pergebnis" style="margin-top:12px;font-family:monospace;font-size:11px;white-space:pre-wrap;line-height:1.6"></div>'
    +'</div></div>';
}
function patchLos(){
  var e=document.getElementById('pergebnis');
  e.innerHTML='<span style="color:#cc8800">Wird eingespielt...</span>';
  fetch('/api/patch?t='+WTOKEN,{method:'POST',body:document.getElementById('pfeld').value})
   .then(function(r){return r.json()}).then(function(d){
     e.innerHTML='<span style="color:'+(d.ok?'#008f56':'#cc2244')+'">'
       +(d.ok?'ERFOLG':'FEHLER')+'</span>\\n'+esc(d.text);
     if(d.ok){setTimeout(function(){location.reload()},4000);}
   }).catch(function(f){e.textContent='Fehler: '+f;});
}

function viewSys(){""")

    p.write_text(s, encoding='utf-8')
    print("dashboard.py: Wartungs-Reiter eingebaut")
    print("")
    print("=" * 46)
    print("DEIN ZUGANGSLINK (als Lesezeichen speichern!):")
    print(f"  http://134.209.239.28:8090/?t={token}")
    print("=" * 46)
print("FERTIG")
