# ============================================
# AIUNIVERSE DASHBOARD - komplett
# ============================================
import json
import base64
import subprocess
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from datetime import datetime
import einstellungen

BASIS = Path(__file__).parent
ORDNER_BILDER = BASIS / "bilder"
ORDNER_VIDEOS = BASIS / "fertige_videos"
ORDNER_LOGS = BASIS / "logs"
PORT = 8090

LAUFEND = {}


def env_lesen():
    d = BASIS / ".env"
    return d.read_text(encoding="utf-8") if d.exists() else ""


def env_schreiben(text):
    (BASIS / ".env").write_text(text, encoding="utf-8")


def bilder_liste(kanal_id):
    ordner = ORDNER_BILDER / kanal_id
    ordner.mkdir(parents=True, exist_ok=True)
    zustand_datei = ordner / "_aktiv.json"
    zustand = {}
    if zustand_datei.exists():
        try:
            zustand = json.loads(zustand_datei.read_text())
        except Exception:
            zustand = {}
    ergebnis = []
    for f in sorted(ordner.iterdir()):
        if f.name.startswith("_") or not f.is_file():
            continue
        if f.suffix.lower() not in (".jpg", ".jpeg", ".png", ".webp"):
            continue
        ergebnis.append({"name": f.name, "aktiv": zustand.get(f.name, True)})
    return ergebnis


def bild_aktiv_setzen(kanal_id, name, aktiv):
    ordner = ORDNER_BILDER / kanal_id
    ordner.mkdir(parents=True, exist_ok=True)
    datei = ordner / "_aktiv.json"
    zustand = {}
    if datei.exists():
        try:
            zustand = json.loads(datei.read_text())
        except Exception:
            zustand = {}
    zustand[name] = aktiv
    datei.write_text(json.dumps(zustand, indent=2))


def bild_speichern(kanal_id, dateiname, base64_daten):
    ordner = ORDNER_BILDER / kanal_id
    ordner.mkdir(parents=True, exist_ok=True)
    if "," in base64_daten:
        base64_daten = base64_daten.split(",", 1)[1]
    sicher = "".join(c for c in dateiname if c.isalnum() or c in "._-")
    if not sicher:
        sicher = f"bild_{datetime.now().strftime('%H%M%S')}.jpg"
    (ordner / sicher).write_bytes(base64.b64decode(base64_daten))
    bild_aktiv_setzen(kanal_id, sicher, True)
    return sicher


def bild_loeschen(kanal_id, name):
    ziel = ORDNER_BILDER / kanal_id / name
    if ziel.exists() and ziel.is_file():
        ziel.unlink()
        return True
    return False


def musik_liste(kanal_id):
    ordner = BASIS / "musik" / kanal_id
    ordner.mkdir(parents=True, exist_ok=True)
    treffer = []
    for f in sorted(ordner.iterdir()):
        if f.is_file() and f.suffix.lower() in (".mp3", ".wav", ".m4a", ".ogg"):
            treffer.append({"name": f.name,
                            "groesse": f"{f.stat().st_size/(1024*1024):.1f} MB"})
    return treffer


def musik_speichern(kanal_id, dateiname, base64_daten):
    import base64 as b64
    ordner = BASIS / "musik" / kanal_id
    ordner.mkdir(parents=True, exist_ok=True)
    if "," in base64_daten:
        base64_daten = base64_daten.split(",", 1)[1]
    sicher = "".join(c for c in dateiname if c.isalnum() or c in "._- ")
    if not sicher:
        sicher = "musik.mp3"
    (ordner / sicher).write_bytes(b64.b64decode(base64_daten))
    return sicher


def musik_loeschen(kanal_id, name):
    ziel = BASIS / "musik" / kanal_id / name
    if ziel.exists() and ziel.is_file():
        ziel.unlink()
        return True
    return False


def musik_liste(kanal_id):
    ordner = BASIS / "musik" / kanal_id
    ordner.mkdir(parents=True, exist_ok=True)
    zustand = {}
    z = ordner / "_aktiv.json"
    if z.exists():
        try:
            zustand = json.loads(z.read_text())
        except Exception:
            zustand = {}
    treffer = []
    for f in sorted(ordner.iterdir()):
        if f.name.startswith("_") or not f.is_file():
            continue
        if f.suffix.lower() in (".mp3", ".wav", ".m4a", ".ogg"):
            treffer.append({"name": f.name,
                            "groesse": f"{f.stat().st_size/(1024*1024):.1f} MB",
                            "aktiv": zustand.get(f.name, True)})
    return treffer


def musik_aktiv_setzen(kanal_id, name, aktiv):
    ordner = BASIS / "musik" / kanal_id
    ordner.mkdir(parents=True, exist_ok=True)
    datei = ordner / "_aktiv.json"
    zustand = {}
    if datei.exists():
        try:
            zustand = json.loads(datei.read_text())
        except Exception:
            zustand = {}
    zustand[name] = aktiv
    datei.write_text(json.dumps(zustand, indent=2))


def musik_speichern(kanal_id, dateiname, base64_daten):
    import base64 as b64
    ordner = BASIS / "musik" / kanal_id
    ordner.mkdir(parents=True, exist_ok=True)
    if "," in base64_daten:
        base64_daten = base64_daten.split(",", 1)[1]
    sicher = "".join(c for c in dateiname if c.isalnum() or c in "._- ")
    if not sicher:
        sicher = "musik.mp3"
    (ordner / sicher).write_bytes(b64.b64decode(base64_daten))
    musik_aktiv_setzen(kanal_id, sicher, True)
    return sicher


def musik_loeschen(kanal_id, name):
    ziel = BASIS / "musik" / kanal_id / name
    if ziel.exists() and ziel.is_file():
        ziel.unlink()
        return True
    return False


def videos_liste():
    eintraege = []
    if not ORDNER_VIDEOS.exists():
        return eintraege
    alle = einstellungen.laden()
    for ordner in sorted(ORDNER_VIDEOS.iterdir(), reverse=True):
        if not ordner.is_dir() or ordner.name.startswith("_"):
            continue
        kid = ordner.name.split("_")[0]
        k = alle.get(kid, alle["a"])
        video = ordner / "video.mp4"
        titel = ordner.name
        p = ordner / "paket.json"
        if p.exists():
            try:
                titel = json.loads(p.read_text(encoding="utf-8")).get("titel", titel)
            except Exception:
                pass
        eintraege.append({
            "ordner": ordner.name,
            "titel": titel,
            "kanal": k["name"],
            "emoji": k["emoji"],
            "groesse": f"{video.stat().st_size/(1024*1024):.1f} MB" if video.exists() else "-",
            "fertig": video.exists(),
        })
    return eintraege[:25]


def video_loeschen(ordner_name):
    import shutil
    ziel = ORDNER_VIDEOS / ordner_name
    if ziel.exists() and ziel.is_dir() and not ordner_name.startswith("_"):
        shutil.rmtree(ziel)
        return True
    return False


PROZESSE = {}


def video_stoppen(kanal_id):
    pr = PROZESSE.get(kanal_id)
    if pr and pr.poll() is None:
        pr.terminate()
        try:
            pr.wait(timeout=5)
        except Exception:
            pr.kill()
        LAUFEND[kanal_id] = False
        return True
    return False


def video_starten(kanal_id, thema=None):
    if LAUFEND.get(kanal_id):
        return False, "Laeuft bereits"

    def arbeit():
        LAUFEND[kanal_id] = True
        try:
            befehl = ["python3", str(BASIS / "erstelle_video.py"), kanal_id]
            if thema:
                befehl.append(thema)
            log = ORDNER_LOGS / f"lauf_{kanal_id}.log"
            log.parent.mkdir(parents=True, exist_ok=True)
            with open(log, "w") as f:
                pr = subprocess.Popen(befehl, cwd=str(BASIS), stdout=f,
                                      stderr=subprocess.STDOUT)
                PROZESSE[kanal_id] = pr
                pr.wait()
        finally:
            LAUFEND[kanal_id] = False

    threading.Thread(target=arbeit, daemon=True).start()
    return True, "Gestartet"
SEITE = r"""<!DOCTYPE html>
<html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Studio</title>
<style>
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
body{font-family:system-ui,-apple-system,sans-serif;background:#f2f4f9;color:#0f1623;padding-bottom:60px;font-size:14px}
.top{background:#0f1623;position:sticky;top:0;z-index:50;overflow-x:auto;white-space:nowrap}
.top .inner{display:flex;align-items:center;padding:0 12px;min-width:max-content}
.top .marke{color:#fff;font-size:13px;font-weight:800;padding:14px 12px 14px 0;border-right:1px solid rgba(255,255,255,.15);margin-right:8px}
.top button{padding:14px 11px;font-size:12px;font-weight:700;color:rgba(255,255,255,.45);background:none;border:none;border-bottom:2.5px solid transparent;font-family:inherit;max-width:150px;overflow:hidden;text-overflow:ellipsis}
.top button.an{color:#fff;border-bottom-color:#00c97a}
.wrap{max-width:820px;margin:0 auto;padding:14px 12px}
.karte{background:#fff;border:1px solid #e4e8f2;border-radius:12px;margin-bottom:16px;overflow:hidden;box-shadow:0 2px 10px rgba(0,0,0,.07);border-left:5px solid #cfd6e4}
.karte>h2{padding:13px 15px;border-bottom:2px solid #eef1f7;font-size:15px;font-weight:800;background:linear-gradient(180deg,#fafbfe,#f4f6fb);letter-spacing:.2px}
.karte:nth-of-type(6n+1){border-left-color:#00c97a}
.karte:nth-of-type(6n+2){border-left-color:#ffaa00}
.karte:nth-of-type(6n+3){border-left-color:#7755ff}
.karte:nth-of-type(6n+4){border-left-color:#ff4060}
.karte:nth-of-type(6n+5){border-left-color:#1db954}
.karte:nth-of-type(6n){border-left-color:#229ED9}
.feld{margin-bottom:16px;padding-bottom:14px;border-bottom:1px dashed #e8ecf4}
.feld:last-child{border-bottom:none;padding-bottom:0}
.lbl{font-size:11px;font-weight:800;color:#5a6480;text-transform:uppercase;letter-spacing:1.2px;margin-bottom:7px}
.karte>.inh{padding:14px 15px}
.lbl{font-size:10px;font-weight:800;color:#8b95b0;text-transform:uppercase;letter-spacing:1.4px;margin-bottom:6px}
.feld{margin-bottom:14px}
input[type=text],input[type=time],input[type=number],input[type=password],textarea,select{width:100%;padding:9px 11px;border:1.5px solid #e4e8f2;border-radius:9px;font-size:13px;font-family:inherit;outline:none;background:#fff}
textarea{min-height:120px;font-family:ui-monospace,monospace;font-size:12px;line-height:1.7;resize:vertical}
textarea.hoch{min-height:230px}
input[type=range]{width:100%;accent-color:#00c97a}
.tabs{display:flex;border-bottom:1px solid #e4e8f2;margin-bottom:14px;overflow-x:auto;white-space:nowrap}
.tabs button{padding:10px 13px;font-size:12px;font-weight:700;color:#8b95b0;background:none;border:none;border-bottom:2.5px solid transparent;font-family:inherit}
.tabs button.an{color:#0f1623;border-bottom-color:#00c97a}
.btn{display:block;width:100%;padding:13px;border:none;border-radius:10px;font-size:14px;font-weight:800;font-family:inherit;margin-top:8px;color:#fff;background:#00c97a}
.btn.o{background:#ffaa00;color:#111}.btn.d{background:#0f1623}.btn.r{background:#ff4060}
.btn:disabled{background:#ccc}
.chip{display:inline-block;padding:6px 12px;border-radius:20px;border:1.5px solid #e4e8f2;background:#fff;color:#8b95b0;font-size:12px;font-weight:700;margin:0 6px 6px 0;font-family:inherit}
.chip.an{border-color:#00c97a;background:#00c97a22;color:#00997a}
.zeile{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:9px;background:#fafbfe;border:1.5px solid #e4e8f2;margin-bottom:8px}
.zeile.an{background:#e8faf4;border-color:#00c97a}
.zeile .txt{flex:1;min-width:0}
.zeile .t1{font-size:12px;font-weight:800}
.zeile .t2{font-size:11px;color:#8b95b0;margin-top:2px}
.hak{width:20px;height:20px;border-radius:6px;border:1.5px solid #ccc;background:#fff;flex-shrink:0;display:flex;align-items:center;justify-content:center;color:#fff;font-size:12px;font-weight:800}
.hak.an{background:#00c97a;border-color:#00c97a}
.sw{width:44px;height:24px;border-radius:12px;background:#ccc;position:relative;flex-shrink:0}
.sw.an{background:#00c97a}
.sw i{position:absolute;width:18px;height:18px;background:#fff;border-radius:9px;top:3px;left:3px;transition:left .2s;box-shadow:0 1px 4px rgba(0,0,0,.3)}
.sw.an i{left:23px}
.gal{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:10px}
.bild{width:92px}
.bild .rahmen{width:92px;height:92px;border-radius:10px;overflow:hidden;border:2.5px solid #e4e8f2;position:relative;background:#f2f4f9}
.bild .rahmen.an{border-color:#00c97a}
.bild img{width:100%;height:100%;object-fit:cover}
.bild .x{position:absolute;top:3px;right:3px;width:22px;height:22px;border-radius:11px;border:none;background:rgba(255,64,96,.92);color:#fff;font-size:13px;font-weight:800;line-height:1}
.bild .frage{position:absolute;inset:0;background:rgba(15,22,35,.88);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:5px}
.bild .frage span{color:#fff;font-size:10px;font-weight:700}
.bild .frage button{padding:3px 8px;border-radius:5px;border:none;font-size:10px;font-weight:800;font-family:inherit}
.bild .u{width:100%;margin-top:5px;padding:4px 0;border-radius:7px;border:1.5px solid #e4e8f2;background:#fff;color:#8b95b0;font-size:11px;font-weight:800;font-family:inherit}
.bild .u.an{border-color:#00c97a;background:#00c97a22;color:#00997a}
.plus{width:92px;height:92px;border-radius:10px;border:2px dashed #cfd6e4;display:flex;flex-direction:column;align-items:center;justify-content:center;color:#8b95b0;font-size:26px;background:#fff}
.info{padding:10px 13px;border-radius:10px;font-size:12px;font-weight:600;line-height:1.55;margin-bottom:12px;background:#e8faf4;color:#008f56;border:1px solid #00c97a44}
.info.w{background:#fff9e6;color:#cc8800;border-color:#ffaa0044}
.info.r{background:#fff1f3;color:#cc2244;border-color:#ff406044}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.kk{background:#fff;border:1px solid #e4e8f2;border-radius:12px;padding:13px;box-shadow:0 1px 8px rgba(0,0,0,.05)}
.kk .kopf{display:flex;align-items:center;gap:9px;margin-bottom:9px}
.kk .ico{width:40px;height:40px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0}
.kk .nm{font-size:13px;font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.kk .pl{font-size:10px;color:#8b95b0;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.balken{height:5px;background:#f2f4f9;border-radius:3px;overflow:hidden;margin:6px 0 4px}
.balken i{display:block;height:100%;background:#00c97a;border-radius:3px}
.mini{font-size:11px;color:#8b95b0;font-weight:600;margin-top:5px;line-height:1.5}
.toast{position:fixed;left:12px;right:12px;bottom:14px;background:#0f1623;color:#fff;padding:13px 15px;border-radius:11px;font-size:13px;font-weight:700;z-index:99;box-shadow:0 4px 20px rgba(0,0,0,.3);display:none}
.rowsp{display:flex;gap:8px}
.rowsp input{flex:1}
.rowsp button{padding:9px 15px;border:none;border-radius:9px;background:#00c97a;color:#fff;font-size:13px;font-weight:800;font-family:inherit;flex-shrink:0}
.klein{padding:7px 12px;font-size:12px;width:auto;display:inline-block;margin-right:8px}
</style></head><body>
<div class="top"><div class="inner" id="nav"></div></div>
<div class="wrap" id="inhalt">Laedt...</div>
<div class="toast" id="toast"></div>
<script>
var musikFrage=null;
var musikFrage=null;
var D={}, seite='dash', tab='Einstellungen', loeschFrage=null, apiFrage=null, vidFrage=null;

function melde(t){var e=document.getElementById('toast');e.textContent=t;e.style.display='block';
  clearTimeout(window._tt);window._tt=setTimeout(function(){e.style.display='none'},3500);}

function laden(cb){fetch('/api/daten').then(function(r){return r.json()}).then(function(d){D=d;if(cb)cb();zeichne()});}

function sichern(){
  fetch('/api/einstellungen',{method:'POST',body:JSON.stringify(D.kanaele)})
   .then(function(r){return r.json()}).then(function(){melde('Gespeichert')});
}
function setz(kid,feld,wert){D.kanaele[kid][feld]=wert;zeichne();sichern();}

function esc(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}

function zeichne(){
  var n='<span class="marke">Studio</span>';
  n+='<button class="'+(seite=='dash'?'an':'')+'" onclick="geh(\'dash\')">Dashboard</button>';
  ['a','b'].forEach(function(k){
    n+='<button class="'+(seite==k?'an':'')+'" onclick="geh(\''+k+'\')">'+esc(D.kanaele[k].name)+'</button>';
  });
  n+='<button class="'+(seite=='sys'?'an':'')+'" onclick="geh(\'sys\')">System</button>';
  if(WTOKEN){n+='<button class="'+(seite=='wartung'?'an':'')+'" onclick="geh(\'wartung\')">Wartung</button>';}
  document.getElementById('nav').innerHTML=n;
  var h='';
  if(seite=='dash')h=viewDash();
  else if(seite=='sys')h=viewSys();
  else if(seite=='wartung')h=viewWartung();
  else h=viewKanal(seite);
  document.getElementById('inhalt').innerHTML=h;
}
function geh(s){seite=s;tab='Einstellungen';loeschFrage=null;zeichne();window.scrollTo(0,0);}
function setTab(t){tab=t;loeschFrage=null;zeichne();}
</script>
<script>
window.onerror=function(m,q,z){document.getElementById('inhalt').innerHTML=
'<div style="padding:14px;background:#fff1f3;color:#cc2244;font-size:13px;border-radius:10px">'
+'<b>JS-Fehler:</b><br>'+m+'<br>Zeile '+z+'</div>';};
</script>
<script src="/js/teil2.js"></script>
</body></html>"""
JS = r"""
function minuten(k){
  return (k.laenge_einheit==='Sek') ? (k.laenge/60) : k.laenge;
}
function anzahlBilder(k){
  return Math.max(3, Math.round(minuten(k)*(k.bilder_pro_minute||6)));
}
function kostenText(k, kid){
  var m = minuten(k), b = anzahlBilder(k);
  var pr = (D.preise && D.preise[kid]) ? D.preise[kid] : {bild:0.04, stimme:0.18, text:0.05, musik:0.05, bildname:'?'};
  var musikNoetig = (k.musik_an !== false) &&
                    !((D.musikdateien && D.musikdateien[kid] || []).some(function(x){return x.aktiv}));
  var euro = b * pr.bild + m * pr.stimme + pr.text + (musikNoetig ? pr.musik : 0);
  var zeit = (k.laenge_einheit === 'Sek') ? (k.laenge + ' Sek') : (k.laenge + ' Min');
  return zeit + ', ' + b + ' Bilder (' + pr.bildname + '), ca. ' + euro.toFixed(2) + ' EUR';
}
function warnung(k){
  return minuten(k) > 10;
}

function alsMinuten(sek){
  if(sek < 60) return sek+' Sek';
  var m = Math.floor(sek/60), r = sek%60;
  return m+':'+(r<10?'0':'')+r+' Min';
}

function laengeFeld(kid,k){
  var min = (k.laenge_einheit==='Sek') ? 5 : 1;
  var max = (k.laenge_einheit==='Sek') ? 3600 : 60;
  return '<div style="display:flex;gap:8px;align-items:center">'
    +'<input type="number" min="'+min+'" max="'+max+'" step="1" value="'+k.laenge+'" '
    +'style="width:110px;text-align:center;font-size:17px;font-weight:800" '
    +'onchange="laengeSetz(\''+kid+'\',this.value,'+min+','+max+')">'
    +'<span style="font-size:14px;font-weight:700;color:#5a6480">'+k.laenge_einheit+'</span></div>'
    +'<div class="mini" style="font-size:13px;color:#0f1623;font-weight:700;margin-top:6px">'
    +'Das sind: '+alsMinuten(k.laenge_einheit==='Sek'?k.laenge:k.laenge*60)+'</div>'
    +'<div class="mini">Erlaubt: '+min+' bis '+max+' '+k.laenge_einheit
    +(k.laenge_einheit==='Sek' ? ' - ab 60 Sek gibt es Geld auf TikTok und YouTube' : '')+'</div>';
}
function laengeSetz(kid,wert,min,max){
  var v = parseInt(wert,10);
  if(isNaN(v)) { zeichne(); return; }
  if(v<min) v=min;
  if(v>max) v=max;
  setz(kid,'laenge',v);
}


function viewDash(){
  var h='<div class="info">Videos landen im Ordner fertige_videos und kommen per Telegram aufs Handy (wenn Token eingetragen).</div>';
  h+='<div class="lbl" style="margin-bottom:10px">Kanaele</div><div class="grid2" style="margin-bottom:16px">';
  ['a','b'].forEach(function(kid){
    var k=D.kanaele[kid];
    h+='<div class="kk"><div class="kopf" onclick="geh(\''+kid+'\')">'
      +'<div class="ico" style="background:'+k.farbe+'22">'+k.emoji+'</div>'
      +'<div style="flex:1;min-width:0"><div class="nm" style="color:'+k.farbe+'">'+esc(k.name)+'</div>'
      +'<div class="pl">'+esc(k.plattformen)+'</div></div></div>'
      +'<div style="display:flex;align-items:center;justify-content:space-between">'
      +'<span style="font-size:11px;font-weight:700;color:'+(k.auto_an?k.farbe:'#8b95b0')+'">'
      +(k.auto_an?'Auto AN '+k.uhrzeit:'Manuell')+'</span>'
      +'<div class="sw '+(k.auto_an?'an':'')+'" onclick="setz(\''+kid+'\',\'auto_an\','+(!k.auto_an)+')"><i></i></div>'
      +'</div></div>';
  });
  h+='</div>';
  h+='<div class="lbl" style="margin-bottom:10px">Schnell erstellen</div>';
  ['a','b'].forEach(function(kid){
    var k=D.kanaele[kid];
    var laeuft=D.laufend[kid];
    h+='<button class="btn '+(kid=='b'?'o':'')+'" '+(laeuft?'disabled':'')+' onclick="start(\''+kid+'\')">'
      +(laeuft?'laeuft...':k.emoji+' '+esc(k.name)+' generieren')+'</button>';
    h+='<div class="mini" style="text-align:center;margin-bottom:10px;color:'
      +(warnung(k)?'#cc2244':'#8b95b0')+'">'+(warnung(k)?'ACHTUNG: ':'')+kostenText(k, kid)+'</div>';
    if(laeuft){
      h+='<button class="btn r" onclick="stopp(\''+kid+'\')">Abbrechen</button>';
    }
  });
  h+='<div class="lbl" style="margin:18px 0 10px">Fertige Videos ('+D.videos.length+')</div>';
  if(D.videos.length===0)h+='<div class="mini">Noch keine Videos</div>';
  D.videos.forEach(function(v){
    h+='<div class="zeile"><span style="font-size:22px">'+v.emoji+'</span>'
      +'<div class="txt"><div class="t1" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+esc(v.titel)+'</div>'
      +'<div class="t2">'+esc(v.kanal)+' &middot; '+esc(v.ordner)+'</div></div>'
      +'<span style="font-size:10px;font-weight:800;padding:3px 9px;border-radius:20px;background:'
      +(v.fertig?'#e8faf4;color:#008f56':'#fff9e6;color:#cc8800')+'">'+(v.fertig?v.groesse:'laeuft')+'</span>';
    if(v.fertig){
      h+='<button class="chip" style="margin:0" onclick="zeigVideo(\''+v.ordner+'\')">&#9654;</button>';
    }
    if(vidFrage===v.ordner){
      h+='<button class="chip" style="margin:0;border-color:#ff4060;color:#ff4060" onclick="vidWeg(\''+v.ordner+'\')">Wirklich</button>'
       +'<button class="chip" style="margin:0" onclick="vidFrage=null;zeichne()">Nein</button>';
    }else{
      h+='<button class="chip" style="margin:0" onclick="vidFrage=\''+v.ordner+'\';zeichne()">&times;</button>';
    }
    h+='</div>';
  });
  return h;
}

function viewKanal(kid){
  var k=D.kanaele[kid];
  var h='<div class="karte"><div class="inh">'
    +'<div style="display:flex;gap:11px;align-items:center">'
    +'<div class="ico" style="width:46px;height:46px;border-radius:11px;background:'+k.farbe+'22;display:flex;align-items:center;justify-content:center;font-size:22px">'+k.emoji+'</div>'
    +'<div style="flex:1;min-width:0"><div style="font-size:16px;font-weight:800;color:'+k.farbe+'">'+esc(k.name)+'</div>'
    +'<div class="pl" style="font-size:11px;color:#8b95b0">'+esc(k.plattformen)+'</div></div>'
    +'<div style="text-align:center"><div style="font-size:10px;font-weight:700;color:#8b95b0;margin-bottom:3px">Auto</div>'
    +'<div class="sw '+(k.auto_an?'an':'')+'" onclick="setz(\''+kid+'\',\'auto_an\','+(!k.auto_an)+')"><i></i></div></div>'
    +'</div></div></div>';

  var tabs=['Einstellungen','Bilder','APIs','Texte & CTA','Prompt','Manuell'];
  h+='<div class="tabs">';
  tabs.forEach(function(t){h+='<button class="'+(tab==t?'an':'')+'" onclick="setTab(\''+t+'\')">'+t+'</button>';});
  h+='</div>';

  if(tab=='Einstellungen')h+=tabEinst(kid,k);
  else if(tab=='Bilder')h+=tabBilder(kid,k);
  else if(tab=='APIs')h+=tabApis(kid,k);
  else if(tab=='Texte & CTA')h+=tabTexte(kid,k);
  else if(tab=='Prompt')h+=tabPrompt(kid,k);
  else h+=tabManuell(kid,k);
  return h;
}

function tabEinst(kid,k){
  var bilder=Math.max(3,Math.round((k.laenge_einheit=='Sek'?k.laenge/60:k.laenge)*k.bilder_pro_minute));
  var sek=Math.round(60/Math.max(1,k.bilder_pro_minute*k.schnitte_pro_bild));
  var h='<div class="karte"><h2>Name und Plattformen</h2><div class="inh">'
    +'<div class="grid2"><div class="feld"><div class="lbl">Emoji</div>'
    +'<input type="text" maxlength="2" value="'+esc(k.emoji)+'" style="text-align:center;font-size:18px" onchange="setz(\''+kid+'\',\'emoji\',this.value)"></div>'
    +'<div class="feld"><div class="lbl">Kanalname</div>'
    +'<input type="text" value="'+esc(k.name)+'" onchange="setz(\''+kid+'\',\'name\',this.value)"></div></div>'
    +'<div class="feld"><div class="lbl">Plattformen</div>'
    +'<input type="text" value="'+esc(k.plattformen)+'" onchange="setz(\''+kid+'\',\'plattformen\',this.value)"></div>'
    +'<div class="mini">Beim Klonen einfach hier umbenennen - der Name gilt dann ueberall.</div>'
    +'</div></div>';

  h+='<div class="karte"><h2>Zeitplan und Laenge</h2><div class="inh">'
    +'<div class="info">Max: YouTube 12 Std | TikTok 60 Min | Instagram 20 Min</div>'
    +'<div class="feld"><div class="lbl">Videolaenge</div>'+laengeFeld(kid,k)
    +'<div class="mini"><b id="lz">'+k.laenge+'</b> '+k.laenge_einheit+'</div></div>'
    +'<div class="grid2"><div class="feld"><div class="lbl">Uhrzeit</div>'
    +'<input type="time" value="'+esc(k.uhrzeit)+'" onchange="setz(\''+kid+'\',\'uhrzeit\',this.value)"></div>'
    +'<div class="feld"><div class="lbl">Videos pro Tag</div><div>';
  for(var i=1;i<=5;i++){
    h+='<button class="chip '+(k.videos_pro_tag==i?'an':'')+'" onclick="setz(\''+kid+'\',\'videos_pro_tag\','+i+')">'+i+'</button>';
  }
  h+='</div></div></div></div></div>';

  h+='<div class="karte"><h2>Sprachen</h2><div class="inh">';
  D.sprachen.forEach(function(s){
    var an=k.sprachen.indexOf(s)>=0;
    h+='<button class="chip '+(an?'an':'')+'" onclick="sprache(\''+kid+'\',\''+s+'\')">'+s+(an?' &#10003;':'')+'</button>';
  });
  k.sprachen.forEach(function(s){
    if(D.sprachen.indexOf(s)<0){
      h+='<button class="chip an" onclick="sprache(\''+kid+'\',\''+esc(s)+'\')">'+esc(s)+' &#10003;</button>';
    }
  });
  h+='<div class="rowsp" style="margin-top:10px"><input type="text" id="neuspr'+kid+'" placeholder="Eigene Sprache...">'
    +'<button onclick="spracheNeu(\''+kid+'\')">+ Add</button></div>'
    +'<div class="mini">Aktiv: '+esc(k.sprachen.join(', ')||'keine')+(k.sprachen.length>1?' - Video wird in JEDER Sprache erstellt (mehr Kosten)':'')+'</div>'
    +'<div class="mini">Tipp: YouTube dubbt gratis in 27 Sprachen. Das hier ist fuer TikTok/Instagram.</div>'
    +'</div></div>';

  h+='<div class="karte"><h2>Bilder und Effekte</h2><div class="inh">'
    +'<div class="feld"><div class="lbl">Bilder pro Minute</div>'
    +'<input type="number" min="3" max="30" value="'+k.bilder_pro_minute+'" style="width:100px;text-align:center;font-weight:700" onchange="setz(\''+kid+'\',\'bilder_pro_minute\',parseInt(this.value))">'
    +'<div class="mini"><b id="bz">'+k.bilder_pro_minute+'</b> pro Minute = ca. <b>'+bilder+'</b> Bilder fuer dieses Video. Passt sich der Laenge automatisch an.</div></div>'
    +'<div class="feld"><div class="lbl">Schnitte pro Bild</div>'
    +'<input type="number" min="1" max="4" value="'+k.schnitte_pro_bild+'" style="width:100px;text-align:center;font-weight:700" onchange="setz(\''+kid+'\',\'schnitte_pro_bild\',parseInt(this.value))">'
    +'<div class="mini"><b id="sz">'+k.schnitte_pro_bild+'</b>x = neuer Reiz alle ca. '+sek+' Sek. Profi-Wert: alle 3-5 Sek.</div></div>'
    +'<div class="zeile '+(k.zoom_effekte?'an':'')+'" onclick="setz(\''+kid+'\',\'zoom_effekte\','+(!k.zoom_effekte)+')">'
    +'<div class="sw '+(k.zoom_effekte?'an':'')+'"><i></i></div>'
    +'<div class="txt"><div class="t1">Zoom- und Schwenk-Effekte</div>'
    +'<div class="t2">Der Code bewegt Bilder automatisch - wirkt lebendig, spart Bilder</div></div></div>'
    +'<div class="mini">Effekte macht FFmpeg selbst (kostenlos): Zoom, Schwenk, Ueberblendungen - automatisch abwechselnd.</div>'
    +'</div></div>';


  h+='<div class="karte"><h2>Bildstil</h2><div class="inh">'
    +'<div class="mini" style="margin-bottom:8px">Wird an JEDE Bildbeschreibung angehaengt. Bestimmt den Look.</div>'
    +'<textarea style="min-height:90px" onchange="setz(\''+kid+'\',\'bildstil\',this.value);AUTOSTOP=false">'+esc(k.bildstil||'')+'</textarea>'
    +'<div class="mini">Bunt: bright colorful flat illustration, finance symbols, happy people. Duester: cinematic dark photography, moody, film grain.</div>'
    +'</div></div>';
  h+='<div class="karte"><h2>Untertitel</h2><div class="inh">'
    +'<div class="mini" style="margin-bottom:8px">Das gesprochene Wort wird farbig hervorgehoben und laeuft mit.</div>';
  ['modern','gross','dezent'].forEach(function(st){
    var an=(k.untertitel_stil||'modern')===st;
    var txt={modern:'Modern (gelb, mittel)',gross:'Gross (gruen, TikTok)',dezent:'Dezent (weiss, klein)'}[st];
    h+='<button class="chip '+(an?'an':'')+'" onclick="setz(\''+kid+'\',\'untertitel_stil\',\''+st+'\')">'+txt+'</button>';
  });
  h+='</div></div>';


  h+='<div class="karte"><h2>Musik</h2><div class="inh">'
    +'<div class="zeile '+(k.musik_an!==false?'an':'')+'" onclick="setz(\''+kid+'\',\'musik_an\','+(k.musik_an===false)+')">'
    +'<div class="sw '+(k.musik_an!==false?'an':'')+'"><i></i></div>'
    +'<div class="txt"><div class="t1">Hintergrundmusik</div>'
    +'<div class="t2">Senkt sich automatisch wenn gesprochen wird</div></div></div>';
  if(k.musik_an!==false){
    h+='<div class="feld" style="margin-top:12px"><div class="lbl">Lautstaerke</div>'
     +'<input type="number" min="0" max="60" value="'+Math.round((k.musik_pegel||0.22)*100)+'" style="width:100px;text-align:center;font-weight:700" onchange="setz(\''+kid+'\',\'musik_pegel\',parseInt(this.value)/100)">'
     +'<div class="mini">'+Math.round((k.musik_pegel||0.22)*100)+' Prozent - Profi-Wert liegt bei 15 bis 25</div></div>'
     +'<div class="feld"><div class="lbl">Musik-Beschreibung (fuer die KI)</div>'
     +'<textarea style="min-height:70px" onchange="setz(\''+kid+'\',\'musik_prompt\',this.value);AUTOSTOP=false">'+esc(k.musik_prompt||'')+'</textarea></div>'
     +'</div>';
    var md=(D.musikdateien&&D.musikdateien[kid])?D.musikdateien[kid]:[];
    var aktivZahl=md.filter(function(x){return x.aktiv}).length;
    h+='<div class="feld"><div class="lbl">Eigene Musikdateien ('+aktivZahl+' von '+md.length+' aktiv)</div>';
    if(md.length===0){
      h+='<div class="mini">Noch keine Dateien - es wird KI-Musik erzeugt. Tipp: Instrumental-Stuecke bei Suno erstellen und hier hochladen.</div>';
    }
    md.forEach(function(f){
      h+='<div class="zeile '+(f.aktiv?'an':'')+'" style="opacity:'+(f.aktiv?1:0.55)+'">'
        +'<div class="txt"><div class="t1" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+esc(f.name)+'</div>'
        +'<div class="t2">'+f.groesse+'</div></div>'
        +'<button class="chip '+(f.aktiv?'an':'')+'" style="margin:0" onclick="musikAktiv(\''+kid+'\',\''+esc(f.name)+'\','+(!f.aktiv)+')">'
        +(f.aktiv?'Aktiv':'Aus')+'</button>';
      if(musikFrage===kid+f.name){
        h+='<button class="chip" style="margin:0;border-color:#ff4060;color:#ff4060" onclick="musikWeg(\''+kid+'\',\''+esc(f.name)+'\')">Weg</button>'
         +'<button class="chip" style="margin:0" onclick="musikFrage=null;zeichne()">Nein</button>';
      }else{
        h+='<button class="chip" style="margin:0" onclick="musikFrage=\''+kid+esc(f.name)+'\';zeichne()">Loeschen</button>';
      }
      h+='</div>';
    });
    h+='<label class="btn d" style="display:block;text-align:center;cursor:pointer;margin-top:8px">Musik hochladen'
      +'<input type="file" accept="audio/*" multiple style="display:none" onchange="musikHoch(\''+kid+'\',this)"></label>'
      +'<div class="mini">Nur AKTIVE Dateien werden verwendet - zufaellig gewaehlt. Ohne aktive Datei erzeugt die KI Musik.</div></div>';
  }
  h+='</div></div>';

  h+='<div class="karte"><h2>Untertitel Aussehen</h2><div class="inh">'
    +'<div class="feld"><div class="lbl">Schriftgroesse</div>'
    +'<input type="number" min="20" max="90" value="'+(k.untertitel_groesse||46)+'" style="width:100px;text-align:center;font-weight:700" onchange="setz(\''+kid+'\',\'untertitel_groesse\',parseInt(this.value))">'
    +'<div class="mini">20 klein bis 90 sehr gross</div></div>'
    +'<div class="feld"><div class="lbl">Abstand von unten</div>'
    +'<input type="number" min="20" max="300" value="'+(k.untertitel_position||60)+'" style="width:100px;text-align:center;font-weight:700" onchange="setz(\''+kid+'\',\'untertitel_position\',parseInt(this.value))">'
    +'</div><div class="feld"><div class="lbl">Schriftart</div><div>';
  (D.schriften||['DejaVu Sans']).forEach(function(f){
    var an=(k.untertitel_schrift||'DejaVu Sans')===f;
    h+='<button class="chip '+(an?'an':'')+'" onclick="setz(\''+kid+'\',\'untertitel_schrift\',\''+f+'\')">'+f+'</button>';
  });
  h+='</div></div></div></div>';

  h+='<div class="karte"><h2>Einblendungen</h2><div class="inh">'
    +'<div class="mini" style="margin-bottom:10px">Text passt sich der Kanalsprache an. Eigene Texte haben Vorrang.</div>'
    +'<div class="feld"><div class="lbl">Abonnieren erscheint</div><div>';
  [['anfang','Am Anfang'],['mitte','In der Mitte'],['ende','Am Ende']].forEach(function(o){
    var an=(k.abo_position||'ende')===o[0];
    h+='<button class="chip '+(an?'an':'')+'" onclick="setz(\''+kid+'\',\'abo_position\',\''+o[0]+'\')">'+o[1]+'</button>';
  });
  h+='</div><div class="mini">Rat: am Ende, wenn der Zuschauer ueberzeugt ist.</div></div>'
    +'<div class="feld"><div class="lbl">Eigener Text Folgen</div>'
    +'<input type="text" value="'+esc(k.cta_text_folgen||'')+'" placeholder="leer = automatisch" onchange="setz(\''+kid+'\',\'cta_text_folgen\',this.value)"></div>'
    +'<div class="feld"><div class="lbl">Eigener Text Like</div>'
    +'<input type="text" value="'+esc(k.cta_text_like||'')+'" placeholder="leer = automatisch" onchange="setz(\''+kid+'\',\'cta_text_like\',this.value)"></div>'
    +'<div class="feld"><div class="lbl">Eigener Text Abonnieren</div>'
    +'<input type="text" value="'+esc(k.cta_text_abo||'')+'" placeholder="leer = automatisch" onchange="setz(\''+kid+'\',\'cta_text_abo\',this.value)"></div>'
    +'</div></div>';

  h+='<div class="karte"><h2>Geraeusche</h2><div class="inh">'
    +'<div class="zeile '+(k.geraeusche_an?'an':'')+'" onclick="setz(\''+kid+'\',\'geraeusche_an\','+(!k.geraeusche_an)+')">'
    +'<div class="sw '+(k.geraeusche_an?'an':'')+'"><i></i></div>'
    +'<div class="txt"><div class="t1">Atmosphaere im Hintergrund</div>'
    +'<div class="t2">Regen, Wind, Strassenlaerm - leise unter Musik und Stimme</div></div></div>';
  if(k.geraeusche_an){
    h+='<div class="feld" style="margin-top:12px"><div class="lbl">Lautstaerke</div>'
     +'<input type="number" min="0" max="40" value="'+Math.round((k.geraeusche_pegel||0.12)*100)+'" style="width:100px;text-align:center;font-weight:700" onchange="setz(\''+kid+'\',\'geraeusche_pegel\',parseInt(this.value)/100)">'
     +'<div class="mini">Prozent - 10 bis 15 ist meist richtig</div></div>'
     +'<div class="mini">Dateien in den Ordner geraeusche/'+kid+'/ legen (Regen, Wind, Ambience).</div>';
  }
  h+='</div></div>';

  h+='<div class="karte"><h2>Stimme</h2><div class="inh">'
    +'<div class="feld"><div class="lbl">Stimm-ID (ElevenLabs)</div>'
    +'<input type="text" value="'+esc(k.stimme_id||'')+'" placeholder="leer = Standardstimme" onchange="setz(\''+kid+'\',\'stimme_id\',this.value)"></div>'
    +'<div class="feld"><div class="lbl">Energie und Ausdruck</div>'
    +'<input type="number" min="0" max="100" value="'+Math.round((k.stimme_energie||0.6)*100)+'" style="width:100px;text-align:center;font-weight:700" onchange="setz(\''+kid+'\',\'stimme_energie\',parseInt(this.value)/100)">'
    +'<div class="mini">'+Math.round((k.stimme_energie||0.6)*100)+' Prozent - hoch ist lebendig und schwungvoll, niedrig ist ruhig.</div></div>'
    +'<div class="mini">Stimmen anhoeren: elevenlabs.io Voice Library</div>'
    +'</div></div>';
  h+='<div class="karte"><h2>Telegram</h2><div class="inh">'
    +'<div class="info w">Fertige Videos + alle Texte kommen in DIESEN Chat. Eigener Bot pro Kanal.</div>'
    +'<div class="feld"><div class="lbl">Bot Token (von @BotFather)</div>'
    +'<input type="password" value="'+esc(k.telegram_token)+'" placeholder="123456:ABC-DEF..." onchange="setz(\''+kid+'\',\'telegram_token\',this.value)"></div>'
    +'<div class="feld"><div class="lbl">Chat ID (von @userinfobot)</div>'
    +'<input type="text" value="'+esc(k.telegram_chat)+'" placeholder="12345678" onchange="setz(\''+kid+'\',\'telegram_chat\',this.value)"></div>'
    +'<div class="mini">In Telegram @BotFather suchen, /newbot, Name geben, Token kopieren. Videos ueber 50 MB kommen als Link.</div>'
    +'</div></div>';

  h+='<div class="karte"><h2>Regeln fuer jedes Video</h2><div class="inh">'
    +'<textarea onchange="setz(\''+kid+'\',\'regeln\',this.value);AUTOSTOP=false">'+esc(k.regeln)+'</textarea>'
    +'<div class="mini">Hier bestimmst du was der Code bei JEDEM Video beachtet.</div>'
    +'</div></div>';

  h+='<button class="btn '+(kid=='b'?'o':'')+'" '+(D.laufend[kid]?'disabled':'')+' onclick="start(\''+kid+'\')">'
    +(D.laufend[kid]?'laeuft...':'Jetzt sofort generieren')+'</button>'
    +'<div class="mini" style="text-align:center;margin-top:8px;color:'
    +(warnung(k)?'#cc2244':'#8b95b0')+'">'+(warnung(k)?'ACHTUNG - sehr lang! ':'')+kostenText(k, kid)+'</div>'
    +(D.laufend[kid]?'<button class="btn r" onclick="stopp(\''+kid+'\')">Abbrechen</button>':'');
  return h;
}

function tabBilder(kid,k){
  var b=D.bilder[kid]||[];
  var aktiv=b.filter(function(x){return x.aktiv}).length;
  var h='<div class="karte"><h2>Bild-Rotation</h2><div class="inh">'
    +'<div class="info">Mehrere Bilder hochladen. Nur die AKTIVEN rotieren - der Code wechselt bei jedem Video. Verhindert dass alles gleich aussieht.</div>'
    +'<div class="gal">';
  b.forEach(function(x,i){
    h+='<div class="bild"><div class="rahmen '+(x.aktiv?'an':'')+'" style="opacity:'+(x.aktiv?1:0.5)+'">'
      +'<img src="/bild/'+kid+'/'+encodeURIComponent(x.name)+'">';
    if(loeschFrage===kid+'|'+x.name){
      h+='<div class="frage"><span>Loeschen?</span><div>'
        +'<button style="background:#ff4060;color:#fff" onclick="bildWeg(\''+kid+'\',\''+esc(x.name)+'\')">Ja</button> '
        +'<button style="background:transparent;color:#fff;border:1px solid #fff" onclick="loeschFrage=null;zeichne()">Nein</button>'
        +'</div></div>';
    }else{
      h+='<button class="x" onclick="loeschFrage=\''+kid+'|'+esc(x.name)+'\';zeichne()">&times;</button>';
    }
    h+='</div><button class="u '+(x.aktiv?'an':'')+'" onclick="bildAktiv(\''+kid+'\',\''+esc(x.name)+'\','+(!x.aktiv)+')">'
      +(x.aktiv?'Aktiv &#10003;':'Inaktiv')+'</button></div>';
  });
  h+='<label class="plus">&#128247;<span style="font-size:20px">+</span>'
    +'<input type="file" accept="image/*" multiple style="display:none" onchange="bildHoch(\''+kid+'\',this)"></label>';
  h+='</div>';
  var txt = b.length===0 ? 'Noch keine Bilder - mehrere gleichzeitig hochladbar'
    : (aktiv===0 ? 'ACHTUNG: Kein aktives Bild - mindestens 1 aktivieren!'
    : (aktiv===1 ? '1 aktiv - immer dasselbe Bild (keine Rotation)'
    : aktiv+' aktiv - Code rotiert automatisch zwischen diesen'));
  h+='<div class="info '+(aktiv===0&&b.length>0?'r':'')+'">'+txt+'</div>'
    +'<div class="mini">Gesicht/Charakter von vorne, Mund sichtbar (fuer Lippensync).</div>'
    +'</div></div>';
  return h;
}

function tabTexte(kid,k){
  var h='<div class="karte"><h2>Titel</h2><div class="inh">'
    +'<div class="zeile '+(k.titel_auto?'an':'')+'" onclick="setz(\''+kid+'\',\'titel_auto\',true)">'
    +'<div class="hak '+(k.titel_auto?'an':'')+'">'+(k.titel_auto?'&#10003;':'')+'</div>'
    +'<div class="txt"><div class="t1">Claude entscheidet selbst (empfohlen)</div>'
    +'<div class="t2">Waehlt pro Video den besten Titel - du musst nichts vorgeben</div></div></div>'
    +'<div class="zeile '+(!k.titel_auto?'an':'')+'" onclick="setz(\''+kid+'\',\'titel_auto\',false)">'
    +'<div class="hak '+(!k.titel_auto?'an':'')+'">'+(!k.titel_auto?'&#10003;':'')+'</div>'
    +'<div class="txt"><div class="t1">Fester Stil</div>'
    +'<div class="t2">Alle Titel im selben Stil</div></div></div>';
  if(!k.titel_auto){
    h+='<div style="margin-top:10px">';
    ['Frage','Schockierend','Nummer','Nutzen','Geheimnisvoll'].forEach(function(s){
      h+='<button class="chip '+(k.titel_stil==s?'an':'')+'" onclick="setz(\''+kid+'\',\'titel_stil\',\''+s+'\')">'+s+'</button>';
    });
    h+='</div>';
  }
  h+='</div></div>';

  h+='<div class="karte"><h2>Beschreibungen</h2><div class="inh">'
    +'<div class="feld"><div class="lbl">YouTube</div>'
    +'<textarea onchange="setz(\''+kid+'\',\'besch_youtube\',this.value);AUTOSTOP=false">'+esc(k.besch_youtube)+'</textarea>'
    +'<div class="mini">Profi: erste 1-2 Zeilen = Hook. Max 3-5 Hashtags.</div></div>'
    +'<div class="feld"><div class="lbl">TikTok</div>'
    +'<textarea style="min-height:70px" onchange="setz(\''+kid+'\',\'besch_tiktok\',this.value);AUTOSTOP=false">'+esc(k.besch_tiktok)+'</textarea></div>'
    +'<div class="feld"><div class="lbl">Instagram</div>'
    +'<textarea style="min-height:70px" onchange="setz(\''+kid+'\',\'besch_instagram\',this.value);AUTOSTOP=false">'+esc(k.besch_instagram)+'</textarea></div>'
    +'<div class="feld"><div class="lbl">Standard-Hashtags</div>'
    +'<input type="text" value="'+esc(k.hashtags)+'" onchange="setz(\''+kid+'\',\'hashtags\',this.value)"></div>'
    +'</div></div>';

  h+='<div class="karte"><h2>Call-to-Actions (gesprochen)</h2><div class="inh">'
    +'<div class="mini" style="margin-bottom:10px">Profi-Tipp: nicht uebertreiben! 1x Mitte + 1x Ende ist optimal.</div>';
  var ctas=[['cta_mitte','Mitte: Folge fuer mehr'],['cta_like','Ende: Like wenn es gefallen hat'],
            ['cta_kommentar','Ende: Kommentier deine Meinung'],['cta_speichern','Ende: Speichere das Video'],
            ['cta_teilen','Ende: Teile mit einem Freund']];
  ctas.forEach(function(c){
    h+='<div class="zeile '+(k[c[0]]?'an':'')+'" onclick="setz(\''+kid+'\',\''+c[0]+'\','+(!k[c[0]])+')">'
      +'<div class="hak '+(k[c[0]]?'an':'')+'">'+(k[c[0]]?'&#10003;':'')+'</div>'
      +'<div class="txt"><div class="t1">'+c[1]+'</div></div></div>';
  });
  h+='</div></div>';

  h+='<div class="karte"><h2>Eingeblendete Animationen</h2><div class="inh">';
  [['anim_follow','Follow-Button (Mitte)'],['anim_like','Like-Animation (Ende)'],['anim_abo','Abonnieren-Pfeil (Ende)']].forEach(function(c){
    h+='<div class="zeile '+(k[c[0]]?'an':'')+'" onclick="setz(\''+kid+'\',\''+c[0]+'\','+(!k[c[0]])+')">'
      +'<div class="hak '+(k[c[0]]?'an':'')+'">'+(k[c[0]]?'&#10003;':'')+'</div>'
      +'<div class="txt"><div class="t1">'+c[1]+'</div></div></div>';
  });
  h+='</div></div>';

  h+='<div class="karte"><h2>Pinned Comment und Links</h2><div class="inh">'
    +'<div class="feld"><div class="lbl">Erster Kommentar (wird gepinnt)</div>'
    +'<textarea style="min-height:60px" onchange="setz(\''+kid+'\',\'pinned\',this.value);AUTOSTOP=false">'+esc(k.pinned)+'</textarea>'
    +'<div class="mini">Profi-Trick: Frage stellen = mehr Kommentare = mehr Reichweite.</div></div>'
    +'<div class="feld"><div class="lbl">Feste Links</div>'
    +'<textarea style="min-height:60px" placeholder="Bio-Link:&#10;Naechstes Video:&#10;Affiliate:" onchange="setz(\''+kid+'\',\'links\',this.value);AUTOSTOP=false">'+esc(k.links)+'</textarea></div>'
    +'</div></div>';

  h+='<div class="info">Ergebnis pro Video: Video + Titel + Beschreibung (3 Plattformen) + Hashtags + KI-Kennzeichnung + CTAs + Pinned Comment - alles in texte.txt im Video-Ordner.</div>';
  return h;
}

function tabPrompt(kid,k){
  return '<div class="karte"><h2>Master-Prompt</h2><div class="inh">'
    +'<div class="info">Hier steht wie Claude schreibt: Hooks, Aufbau, Themen, Titel-Stil. Der wichtigste Hebel fuer gute Videos.</div>'
    +'<textarea class="hoch" onchange="setz(\''+kid+'\',\'prompt\',this.value);AUTOSTOP=false">'+esc(k.prompt)+'</textarea>'
    +'<button class="btn r" onclick="zuruecksetzen(\''+kid+'\')">Auf Standard zuruecksetzen</button>'
    +'<div class="mini" style="text-align:center;margin-top:6px">Vorherige Version wird automatisch gesichert.</div>'
    +'</div></div>';
}

function tabManuell(kid,k){
  return '<div class="karte"><h2>Manuell generieren</h2><div class="inh">'
    +'<div class="info">Automatik laeuft weiter - das hier ist nur fuer zusaetzliche Videos mit eigenem Thema.</div>'
    +'<div class="feld"><div class="lbl">Eigenes Thema (optional)</div>'
    +'<textarea id="thema'+kid+'" style="min-height:90px" placeholder="Leer = Claude waehlt selbst&#10;&#10;Oder z.B. ein konkretes Thema eingeben"></textarea></div>'
    +'<button class="btn '+(kid=='b'?'o':'')+'" '+(D.laufend[kid]?'disabled':'')+' onclick="startThema(\''+kid+'\')">'
    +(D.laufend[kid]?'laeuft...':'Jetzt manuell generieren')+'</button>'
    +'</div></div>';
}

function tabApis(kid,k){
  var h='<div class="info">Pro Funktion mehrere Anbieter - nur der GRUENE ist aktiv. Waehlst du "Kling (fal.ai)" traegst du deinen fal.ai Key ein. Waehlst du "Kling direkt" den Kling-Key.</div>';
  h+='<div class="info w">fal.ai = EIN Key fuer Kling, Veo, Flux, ElevenLabs. Nur die URL unterscheidet sich.</div>';
  D.apislots.forEach(function(sl){
    var slot=sl[0], titel=sl[1], hin=sl[2];
    if(slot=='avatar' && !k.mit_avatar) return;
    var liste=(k.apis&&k.apis[slot])?k.apis[slot]:[];
    var akt='';
    liste.forEach(function(e){ if(e.aktiv) akt=e.name; });
    h+='<div class="karte"><h2>'+titel+'</h2><div class="inh">';
    h+='<div class="mini" style="margin-bottom:10px">'+hin+' &middot; <b style="color:'+(akt?'#00997a':'#cc2244')+'">'+(akt?'Aktiv: '+esc(akt):'keine aktiv!')+'</b></div>';
    liste.forEach(function(e,i){
      var an=!!e.aktiv;
      h+='<div style="border:1.5px solid '+(an?'#00c97a':'#e4e8f2')+';background:'+(an?'#e8faf4':'#fafbfe')+';border-radius:9px;padding:9px;margin-bottom:8px">';
      h+='<div style="display:flex;gap:7px;align-items:center;margin-bottom:7px">';
      h+='<button class="chip '+(an?'an':'')+'" style="margin:0" onclick="apiAktiv(\''+kid+'\',\''+slot+'\','+i+')">'+(an?'Aktiv &#10003;':'Aktivieren')+'</button>';
      h+='<div style="flex:1"></div>';
      if(apiFrage===kid+slot+i){
        h+='<button class="chip" style="margin:0;border-color:#ff4060;color:#ff4060" onclick="apiWeg(\''+kid+'\',\''+slot+'\','+i+')">Wirklich</button>';
        h+='<button class="chip" style="margin:0" onclick="apiFrage=null;zeichne()">Nein</button>';
      }else{
        h+='<button class="chip" style="margin:0" onclick="apiFrage=\''+kid+slot+i+'\';zeichne()">Loeschen</button>';
      }
      h+='</div>';
      h+='<input type="text" style="margin-bottom:6px" placeholder="Name" value="'+esc(e.name)+'" onchange="apiSetz(\''+kid+'\',\''+slot+'\','+i+',\'name\',this.value);AUTOSTOP=false">';
      h+='<input type="password" style="margin-bottom:6px;background:#f2f4f9" placeholder="API Key" value="'+esc(e.key)+'" onchange="apiSetz(\''+kid+'\',\''+slot+'\','+i+',\'key\',this.value);AUTOSTOP=false">';
      h+='<input type="text" style="font-size:11px;color:#8b95b0" placeholder="URL" value="'+esc(e.url)+'" onchange="apiSetz(\''+kid+'\',\''+slot+'\','+i+',\'url\',this.value);AUTOSTOP=false">';
      h+='</div>';
    });
    h+='<button class="chip" style="width:100%;border-style:dashed;padding:9px" onclick="apiNeu(\''+kid+'\',\''+slot+'\')">+ Weitere Option</button>';
    h+='</div></div>';
  });
  return h;
}
function apiSetz(kid,slot,i,f,w){ D.kanaele[kid].apis[slot][i][f]=w; sichern(); }
function apiAktiv(kid,slot,i){ D.kanaele[kid].apis[slot].forEach(function(e,j){e.aktiv=(j===i)}); zeichne(); sichern(); }
function apiNeu(kid,slot){ if(!D.kanaele[kid].apis[slot])D.kanaele[kid].apis[slot]=[];
  D.kanaele[kid].apis[slot].push({name:'',key:'',url:'',aktiv:false}); zeichne(); sichern(); }
function apiWeg(kid,slot,i){ apiFrage=null; D.kanaele[kid].apis[slot].splice(i,1); zeichne(); sichern(); }

var WTOKEN=(location.search.match(/[?&]t=([^&]+)/)||[])[1]||'';

function viewWartung(){
  return '<div class="karte"><h2>Patch einspielen</h2><div class="inh">'
    +'<div class="info">Den Code-Block hier einfuegen und auf Einspielen druecken. Danach startet das Dashboard automatisch neu.</div>'
    +'<textarea id="pfeld" class="hoch" placeholder="Code hier einfuegen..." style="font-size:11px"></textarea>'
    +'<button class="btn d" onclick="patchLos()">Einspielen</button>'
    +'<div id="pergebnis" style="margin-top:12px;font-family:monospace;font-size:11px;white-space:pre-wrap;line-height:1.6"></div>'
    +'</div></div>';
}
function patchLos(){
  var e=document.getElementById('pergebnis');
  e.innerHTML='<span style="color:#cc8800">Wird eingespielt...</span>';
  fetch('/api/patch?t='+WTOKEN,{method:'POST',body:document.getElementById('pfeld').value})
   .then(function(r){return r.json()}).then(function(d){
     e.innerHTML='<span style="color:'+(d.ok?'#008f56':'#cc2244')+'">'
       +(d.ok?'ERFOLG':'FEHLER')+'</span>\n'+esc(d.text);
     if(d.ok){setTimeout(function(){location.reload()},4000);}
   }).catch(function(f){e.textContent='Fehler: '+f;});
}

function viewSys(){
  var h='<div class="karte"><h2>API Keys</h2><div class="inh">'
    +'<div class="info '+(D.testmodus?'w':'')+'">'
    +(D.testmodus?'TESTMODUS ist AN - es werden Platzhalter statt echter APIs genutzt (kostet nichts). Fuer echte Videos: TESTMODUS=false setzen.':'ECHTBETRIEB - es werden echte APIs genutzt (kostet Geld).')
    +'</div>'
    +'<div class="mini" style="margin-bottom:8px">Anthropic = Texte | fal.ai = Bilder, Stimme, Video (EIN Key fuer Kling, Flux, ElevenLabs) | Hedra = Avatar</div>'
    +'<textarea class="hoch" id="envfeld">'+esc(D.env)+'</textarea>'
    +'<button class="btn d" onclick="envSpeichern()">Keys speichern</button>'
    +'<div class="mini" style="text-align:center;margin-top:6px">Nach dem Speichern: Automatik neu starten damit es greift.</div>'
    +'</div></div>';
  h+='<div class="karte"><h2>Server</h2><div class="inh">'
    +'<div class="zeile"><div class="txt"><div class="t1">Modus</div>'
    +'<div class="t2">'+(D.testmodus?'Testmodus (gratis)':'Echtbetrieb')+'</div></div></div>'
    +'<div class="zeile"><div class="txt"><div class="t1">Videos gesamt</div>'
    +'<div class="t2">'+D.videos.length+' im Ordner fertige_videos</div></div></div>'
    +'<div class="zeile"><div class="txt"><div class="t1">Speicherort</div>'
    +'<div class="t2">'+esc(D.basis)+'</div></div></div>'
    +'</div></div>';
  return h;
}

function sprache(kid,s){
  var l=D.kanaele[kid].sprachen.slice();
  var i=l.indexOf(s);
  if(i>=0)l.splice(i,1); else l.push(s);
  setz(kid,'sprachen',l);
}
function spracheNeu(kid){
  var e=document.getElementById('neuspr'+kid);
  var v=(e.value||'').trim();
  if(!v)return;
  var l=D.kanaele[kid].sprachen.slice();
  if(l.indexOf(v)<0)l.push(v);
  e.value='';
  setz(kid,'sprachen',l);
}
function musikHoch(kid,el){
  var dateien=Array.prototype.slice.call(el.files);
  var offen=dateien.length;
  if(!offen)return;
  melde(offen+' Datei(en) werden hochgeladen...');
  dateien.forEach(function(f){
    var leser=new FileReader();
    leser.onload=function(){
      fetch('/api/musik_hoch',{method:'POST',body:JSON.stringify({kanal:kid,name:f.name,daten:leser.result})})
        .then(function(){offen--;if(offen===0){melde('Hochgeladen');laden();}});
    };
    leser.readAsDataURL(f);
  });
}
function musikAktiv(kid,name,an){
  fetch('/api/musik_aktiv',{method:'POST',body:JSON.stringify({kanal:kid,name:name,aktiv:an})})
    .then(function(){laden();});
}
function musikWeg(kid,name){
  musikFrage=null;
  fetch('/api/musik_weg',{method:'POST',body:JSON.stringify({kanal:kid,name:name})})
    .then(function(){melde('Geloescht');laden();});
}
function bildHoch(kid,el){
  var dateien=Array.prototype.slice.call(el.files);
  var offen=dateien.length;
  if(!offen)return;
  melde(offen+' Bild(er) werden hochgeladen...');
  dateien.forEach(function(f){
    var leser=new FileReader();
    leser.onload=function(){
      fetch('/api/bild',{method:'POST',body:JSON.stringify({kanal:kid,name:f.name,daten:leser.result})})
        .then(function(){offen--;if(offen===0){melde('Hochgeladen');laden();}});
    };
    leser.readAsDataURL(f);
  });
}
function bildAktiv(kid,name,an){
  fetch('/api/bild_aktiv',{method:'POST',body:JSON.stringify({kanal:kid,name:name,aktiv:an})})
    .then(function(){laden()});
}
function bildWeg(kid,name){
  loeschFrage=null;
  fetch('/api/bild_loeschen',{method:'POST',body:JSON.stringify({kanal:kid,name:name})})
    .then(function(){melde('Geloescht');laden()});
}
function zeigVideo(o){
  var alt=document.getElementById('vidbox');
  if(alt)alt.remove();
  var box=document.createElement('div');
  box.id='vidbox';
  box.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.92);z-index:200;display:flex;flex-direction:column;padding:12px;overflow:auto';
  box.innerHTML='<div style="display:flex;gap:8px;margin-bottom:10px">'
    +'<button class="chip" style="margin:0;background:#fff" onclick="document.getElementById(\'vidbox\').remove()">Schliessen</button>'
    +'<a class="chip" style="margin:0;background:#fff;text-decoration:none;display:inline-block" href="/video/'+o+'" download>Herunterladen</a>'
    +'<button class="chip" style="margin:0;background:#fff" onclick="zeigTexte(\''+o+'\')">Texte</button>'
    +'</div>'
    +'<video controls autoplay playsinline style="width:100%;max-height:60vh;background:#000;border-radius:10px" src="/video/'+o+'"></video>'
    +'<div id="txtbox" style="color:#fff;font-size:12px;white-space:pre-wrap;margin-top:12px;line-height:1.6"></div>';
  document.body.appendChild(box);
}
function zeigTexte(o){
  fetch('/texte/'+o).then(function(r){return r.text()}).then(function(t){
    document.getElementById('txtbox').textContent=t;
  });
}
function vidWeg(o){
  vidFrage=null;
  fetch('/api/video_loeschen',{method:'POST',body:JSON.stringify({ordner:o})})
    .then(function(){melde('Video geloescht');laden();});
}
function stopp(kid){
  fetch('/api/stop?kanal='+kid).then(function(r){return r.json()})
   .then(function(d){melde(d.text);laden();});
}
function start(kid){
  var k=D.kanaele[kid];
  if(!confirm('Wirklich generieren?\n\n'+k.name+'\n'+kostenText(k, kid)
      +(warnung(k)?'\n\nACHTUNG: sehr langes Video!':''))) return;
  fetch('/api/start?kanal='+kid).then(function(r){return r.json()}).then(function(d){
    melde(d.text);laden();
  });
}
function startThema(kid){
  var t=document.getElementById('thema'+kid).value||'';
  fetch('/api/start?kanal='+kid+'&thema='+encodeURIComponent(t))
    .then(function(r){return r.json()}).then(function(d){melde(d.text);laden();});
}
function envSpeichern(){
  fetch('/api/env',{method:'POST',body:document.getElementById('envfeld').value})
    .then(function(r){return r.json()}).then(function(d){melde(d.text);laden();});
}
function zuruecksetzen(kid){
  fetch('/api/zuruecksetzen?kanal='+kid).then(function(){melde('Zurueckgesetzt');laden();});
}

laden();
var AUTOSTOP=false;
setInterval(function(){ if(seite=='dash' && !AUTOSTOP) laden(); }, 15000);
"""

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _sende(self, inhalt, typ="application/json", binaer=False):
        self.send_response(200)
        if binaer:
            self.send_header("Content-Type", typ)
            self.end_headers()
            self.wfile.write(inhalt)
        else:
            self.send_header("Content-Type", typ + "; charset=utf-8")
            self.end_headers()
            self.wfile.write(inhalt.encode("utf-8"))

    def _body(self):
        laenge = int(self.headers.get("Content-Length", 0))
        return self.rfile.read(laenge).decode("utf-8")

    def do_GET(self):
        pfad = self.path.split("?")[0]

        if pfad == "/":
            self._sende(SEITE, "text/html")

        elif pfad == "/js/teil2.js":
            self._sende(JS, "application/javascript")

        elif pfad.startswith("/video/"):
            from urllib.parse import unquote
            name = unquote(pfad.split("/video/", 1)[1])
            ziel = ORDNER_VIDEOS / name / "video.mp4"
            if not ziel.exists():
                self.send_response(404); self.end_headers(); return
            groesse = ziel.stat().st_size
            bereich = self.headers.get("Range")
            with open(ziel, "rb") as f:
                if bereich and bereich.startswith("bytes="):
                    teile = bereich.replace("bytes=", "").split("-")
                    von = int(teile[0]) if teile[0] else 0
                    bis = int(teile[1]) if len(teile) > 1 and teile[1] else groesse - 1
                    bis = min(bis, groesse - 1)
                    f.seek(von)
                    daten = f.read(bis - von + 1)
                    self.send_response(206)
                    self.send_header("Content-Range", f"bytes {von}-{bis}/{groesse}")
                    self.send_header("Accept-Ranges", "bytes")
                    self.send_header("Content-Type", "video/mp4")
                    self.send_header("Content-Length", str(len(daten)))
                    self.end_headers()
                    self.wfile.write(daten)
                else:
                    self.send_response(200)
                    self.send_header("Content-Type", "video/mp4")
                    self.send_header("Content-Length", str(groesse))
                    self.send_header("Accept-Ranges", "bytes")
                    self.end_headers()
                    while True:
                        stueck = f.read(65536)
                        if not stueck:
                            break
                        self.wfile.write(stueck)

        elif pfad.startswith("/texte/"):
            from urllib.parse import unquote
            name = unquote(pfad.split("/texte/", 1)[1])
            ziel = ORDNER_VIDEOS / name / "texte.txt"
            if ziel.exists():
                self._sende(ziel.read_text(encoding="utf-8"), "text/plain")
            else:
                self.send_response(404); self.end_headers()

        elif pfad.startswith("/bild/"):
            teile = pfad.split("/")
            if len(teile) >= 4:
                from urllib.parse import unquote
                ziel = ORDNER_BILDER / teile[2] / unquote(teile[3])
                if ziel.exists() and ziel.is_file():
                    typ = "image/png" if ziel.suffix.lower() == ".png" else "image/jpeg"
                    self._sende(ziel.read_bytes(), typ, binaer=True)
                    return
            self.send_response(404)
            self.end_headers()

        elif pfad == "/api/wartung":
            from urllib.parse import urlparse, parse_qs
            q = parse_qs(urlparse(self.path).query)
            gegeben = q.get("t", [""])[0]
            echt = (BASIS / "regeln" / "wartung.txt").read_text().strip()
            self._sende(json.dumps({"frei": gegeben == echt}))

        elif pfad == "/api/daten":
            alle = einstellungen.laden()
            bilder = {kid: bilder_liste(kid) for kid in alle}
            for kid, k in alle.items():
                k["laufend"] = bool(LAUFEND.get(kid))
            self._sende(json.dumps({
                "kanaele": alle,
                "bilder": bilder,
                "videos": videos_liste(),
                "env": env_lesen(),
                "testmodus": "TESTMODUS=true" in env_lesen().replace(" ", ""),
                "sprachen": einstellungen.SPRACHEN_LISTE,
                "schriften": getattr(einstellungen, "SCHRIFTEN", ["DejaVu Sans"]),
                "preise": {kid: {
                    "bild": einstellungen.preis_fuer(k, "bilder"),
                    "stimme": einstellungen.preis_fuer(k, "stimme"),
                    "text": einstellungen.preis_fuer(k, "text"),
                    "musik": einstellungen.preis_fuer(k, "musik"),
                    "bildname": (einstellungen.aktive_api(k, "bilder") or {}).get("name", "?"),
                } for kid, k in alle.items()},
                "musikdateien": {kid: musik_liste(kid) for kid in alle},
                "musikdateien": {kid: musik_liste(kid) for kid in alle},
                "apislots": einstellungen.API_SLOTS,
                "laufend": {kid: bool(LAUFEND.get(kid)) for kid in alle},
                "basis": str(BASIS),
            }, ensure_ascii=False))

        elif pfad == "/api/start":
            from urllib.parse import urlparse, parse_qs, unquote
            q = parse_qs(urlparse(self.path).query)
            kanal = q.get("kanal", ["a"])[0]
            thema = q.get("thema", [""])[0].strip() or None
            alle = einstellungen.laden()
            name = alle.get(kanal, {}).get("name", kanal)
            ok, grund = video_starten(kanal, thema)
            text = f"{name} wird erstellt - dauert etwas." if ok else f"{name}: {grund}"
            self._sende(json.dumps({"ok": ok, "text": text}, ensure_ascii=False))

        elif pfad == "/api/stop":
            from urllib.parse import urlparse, parse_qs
            q = parse_qs(urlparse(self.path).query)
            kanal = q.get("kanal", ["a"])[0]
            ok = video_stoppen(kanal)
            self._sende(json.dumps({"ok": ok,
                "text": "Abgebrochen" if ok else "Laeuft gerade nichts"}))

        elif pfad == "/api/zuruecksetzen":
            from urllib.parse import urlparse, parse_qs
            q = parse_qs(urlparse(self.path).query)
            kanal = q.get("kanal", ["a"])[0]
            einstellungen.zuruecksetzen(kanal)
            self._sende(json.dumps({"ok": True}))

        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        if self.path.startswith("/api/patch"):
            from urllib.parse import urlparse, parse_qs
            import base64, zlib, subprocess, traceback
            q = parse_qs(urlparse(self.path).query)
            echt = (BASIS / "regeln" / "wartung.txt").read_text().strip()
            if q.get("t", [""])[0] != echt:
                self._sende(json.dumps({"ok": False, "text": "Kein Zugang"}))
                return
            roh = self._body().strip()
            try:
                sauber = "".join(roh.split())
                daten = base64.b64decode(sauber)
                try:
                    daten = zlib.decompress(daten, 47)
                except Exception:
                    pass
                ziel = BASIS / "patch_neu.py"
                ziel.write_bytes(daten)
                lauf = subprocess.run(["python3", str(ziel)], cwd=str(BASIS),
                                      capture_output=True, text=True, timeout=180)
                ausgabe = (lauf.stdout + lauf.stderr)[-2000:]
                self._sende(json.dumps({"ok": lauf.returncode == 0, "text": ausgabe}))
            except Exception as f:
                self._sende(json.dumps({"ok": False,
                                        "text": "Fehler: " + str(f)[:300]}))

        elif self.path == "/api/einstellungen":
            daten = json.loads(self._body())
            einstellungen.speichern(daten)
            self._sende(json.dumps({"ok": True}))

        elif self.path == "/api/env":
            env_schreiben(self._body())
            self._sende(json.dumps({"text": "Keys gespeichert"}))

        elif self.path == "/api/bild":
            d = json.loads(self._body())
            name = bild_speichern(d["kanal"], d["name"], d["daten"])
            self._sende(json.dumps({"ok": True, "name": name}))

        elif self.path == "/api/bild_aktiv":
            d = json.loads(self._body())
            bild_aktiv_setzen(d["kanal"], d["name"], d["aktiv"])
            self._sende(json.dumps({"ok": True}))

        elif self.path == "/api/video_loeschen":
            v = json.loads(self._body())
            ok = video_loeschen(v["ordner"])
            self._sende(json.dumps({"ok": ok}))

        elif self.path == "/api/musik_hoch":
            d = json.loads(self._body())
            name = musik_speichern(d["kanal"], d["name"], d["daten"])
            self._sende(json.dumps({"ok": True, "name": name}))

        elif self.path == "/api/musik_weg":
            d = json.loads(self._body())
            musik_loeschen(d["kanal"], d["name"])
            self._sende(json.dumps({"ok": True}))

        elif self.path == "/api/musik_hoch":
            d = json.loads(self._body())
            name = musik_speichern(d["kanal"], d["name"], d["daten"])
            self._sende(json.dumps({"ok": True, "name": name}))

        elif self.path == "/api/musik_aktiv":
            d = json.loads(self._body())
            musik_aktiv_setzen(d["kanal"], d["name"], d["aktiv"])
            self._sende(json.dumps({"ok": True}))

        elif self.path == "/api/musik_weg":
            d = json.loads(self._body())
            musik_loeschen(d["kanal"], d["name"])
            self._sende(json.dumps({"ok": True}))

        elif self.path == "/api/bild_loeschen":
            d = json.loads(self._body())
            bild_loeschen(d["kanal"], d["name"])
            self._sende(json.dumps({"ok": True}))

        else:
            self.send_response(404)
            self.end_headers()


if __name__ == "__main__":
    ORDNER_LOGS.mkdir(parents=True, exist_ok=True)
    ORDNER_BILDER.mkdir(parents=True, exist_ok=True)
    ORDNER_VIDEOS.mkdir(parents=True, exist_ok=True)
    print("=" * 48)
    print("AIUNIVERSE DASHBOARD laeuft")
    print(f"Browser:  http://<SERVER-IP>:{PORT}")
    print("=" * 48)
    HTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
