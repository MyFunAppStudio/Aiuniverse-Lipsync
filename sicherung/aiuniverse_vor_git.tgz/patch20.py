# ============================================
# Patch 20: Musikverwaltung im Dashboard
# Liste, hochladen, aktiv/inaktiv, loeschen
# ============================================
from pathlib import Path

# ---------- 1. musik.py: nur aktive Dateien nutzen ----------
p = Path('musik.py')
s = p.read_text(encoding='utf-8')
if '_aktiv.json' not in s:
    s = s.replace('''def eigene_musik(kanal):
    """Sucht eine Musikdatei im Ordner musik/<kanal>/ ."""
    ordner = config.BASIS / "musik" / kanal["id"]
    if not ordner.exists():
        return None
    treffer = [f for f in sorted(ordner.iterdir())
               if f.is_file() and f.suffix.lower() in (".mp3", ".wav", ".m4a", ".ogg")]
    return random.choice(treffer) if treffer else None''',
'''def eigene_musik(kanal):
    """Waehlt zufaellig eine AKTIVE Musikdatei aus musik/<kanal>/ ."""
    ordner = config.BASIS / "musik" / kanal["id"]
    if not ordner.exists():
        return None
    zustand = {}
    z = ordner / "_aktiv.json"
    if z.exists():
        try:
            zustand = json.loads(z.read_text())
        except Exception:
            zustand = {}
    treffer = [f for f in sorted(ordner.iterdir())
               if f.is_file() and f.suffix.lower() in (".mp3", ".wav", ".m4a", ".ogg")
               and zustand.get(f.name, True)]
    return random.choice(treffer) if treffer else None''')
    p.write_text(s, encoding='utf-8')
    print("1. musik.py: nutzt nur aktive Dateien")
else:
    print("1. musik.py: schon ok")

# ---------- 2. dashboard.py ----------
p = Path('dashboard.py')
s = p.read_text(encoding='utf-8')
Path('dashboard_vor20.py').write_text(s, encoding='utf-8')

# 2a) Backend
if 'musik_aktiv' not in s:
    s = s.replace('''def videos_liste():''',
'''def musik_liste(kanal_id):
    ordner = BASIS / "musik" / kanal_id
    ordner.mkdir(parents=True, exist_ok=True)
    zustand = {}
    z = ordner / "_aktiv.json"
    if z.exists():
        try:
            zustand = json.loads(z.read_text())
        except Exception:
            zustand = {}
    treffer = []
    for f in sorted(ordner.iterdir()):
        if f.name.startswith("_") or not f.is_file():
            continue
        if f.suffix.lower() in (".mp3", ".wav", ".m4a", ".ogg"):
            treffer.append({"name": f.name,
                            "groesse": f"{f.stat().st_size/(1024*1024):.1f} MB",
                            "aktiv": zustand.get(f.name, True)})
    return treffer


def musik_aktiv_setzen(kanal_id, name, aktiv):
    ordner = BASIS / "musik" / kanal_id
    ordner.mkdir(parents=True, exist_ok=True)
    datei = ordner / "_aktiv.json"
    zustand = {}
    if datei.exists():
        try:
            zustand = json.loads(datei.read_text())
        except Exception:
            zustand = {}
    zustand[name] = aktiv
    datei.write_text(json.dumps(zustand, indent=2))


def musik_speichern(kanal_id, dateiname, base64_daten):
    import base64 as b64
    ordner = BASIS / "musik" / kanal_id
    ordner.mkdir(parents=True, exist_ok=True)
    if "," in base64_daten:
        base64_daten = base64_daten.split(",", 1)[1]
    sicher = "".join(c for c in dateiname if c.isalnum() or c in "._- ")
    if not sicher:
        sicher = "musik.mp3"
    (ordner / sicher).write_bytes(b64.b64decode(base64_daten))
    musik_aktiv_setzen(kanal_id, sicher, True)
    return sicher


def musik_loeschen(kanal_id, name):
    ziel = BASIS / "musik" / kanal_id / name
    if ziel.exists() and ziel.is_file():
        ziel.unlink()
        return True
    return False


def videos_liste():''')

    s = s.replace('''                "sprachen": einstellungen.SPRACHEN_LISTE,''',
'''                "sprachen": einstellungen.SPRACHEN_LISTE,
                "musikdateien": {kid: musik_liste(kid) for kid in alle},''')

    s = s.replace('''        elif self.path == "/api/bild_loeschen":''',
'''        elif self.path == "/api/musik_hoch":
            d = json.loads(self._body())
            name = musik_speichern(d["kanal"], d["name"], d["daten"])
            self._sende(json.dumps({"ok": True, "name": name}))

        elif self.path == "/api/musik_aktiv":
            d = json.loads(self._body())
            musik_aktiv_setzen(d["kanal"], d["name"], d["aktiv"])
            self._sende(json.dumps({"ok": True}))

        elif self.path == "/api/musik_weg":
            d = json.loads(self._body())
            musik_loeschen(d["kanal"], d["name"])
            self._sende(json.dumps({"ok": True}))

        elif self.path == "/api/bild_loeschen":''')
    print("2a. Backend: Liste, Upload, Aktiv-Schalter, Loeschen")

# 2b) Frontend: erst aufraeumen, dann sauber einbauen
import re as _re

# vorhandene Musik-Listen-Bloecke (auch halbe) entfernen
vorher = s.count("var md=")
s = _re.sub(r"\s*\+'</div>';\n\s*var md=.*?</div></div>';", "", s, flags=_re.S)
if vorher:
    print(f"   {vorher} alten Musik-Block entfernt")

alte_zeile = None
for z in s.split('\n'):
    if 'Eigene Musik' in z and 'mini' in z:
        alte_zeile = z
        break
if alte_zeile is None:
    # Fallback: hinter der Musik-Beschreibung einhaengen
    for z in s.split('\n'):
        if "musik_prompt" in z and "textarea" in z:
            alte_zeile = z
            break

if alte_zeile and 'Eigene Musikdateien' not in s:
    neu = """     +'</div>';
    var md=(D.musikdateien&&D.musikdateien[kid])?D.musikdateien[kid]:[];
    var aktivZahl=md.filter(function(x){return x.aktiv}).length;
    h+='<div class="feld"><div class="lbl">Eigene Musikdateien ('+aktivZahl+' von '+md.length+' aktiv)</div>';
    if(md.length===0){
      h+='<div class="mini">Noch keine Dateien - es wird KI-Musik erzeugt. Tipp: Instrumental-Stuecke bei Suno erstellen und hier hochladen.</div>';
    }
    md.forEach(function(f){
      h+='<div class="zeile '+(f.aktiv?'an':'')+'" style="opacity:'+(f.aktiv?1:0.55)+'">'
        +'<div class="txt"><div class="t1" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+esc(f.name)+'</div>'
        +'<div class="t2">'+f.groesse+'</div></div>'
        +'<button class="chip '+(f.aktiv?'an':'')+'" style="margin:0" onclick="musikAktiv(\\''+kid+'\\',\\''+esc(f.name)+'\\','+(!f.aktiv)+')">'
        +(f.aktiv?'Aktiv':'Aus')+'</button>';
      if(musikFrage===kid+f.name){
        h+='<button class="chip" style="margin:0;border-color:#ff4060;color:#ff4060" onclick="musikWeg(\\''+kid+'\\',\\''+esc(f.name)+'\\')">Weg</button>'
         +'<button class="chip" style="margin:0" onclick="musikFrage=null;zeichne()">Nein</button>';
      }else{
        h+='<button class="chip" style="margin:0" onclick="musikFrage=\\''+kid+esc(f.name)+'\\';zeichne()">Loeschen</button>';
      }
      h+='</div>';
    });
    h+='<label class="btn d" style="display:block;text-align:center;cursor:pointer;margin-top:8px">Musik hochladen'
      +'<input type="file" accept="audio/*" multiple style="display:none" onchange="musikHoch(\\''+kid+'\\',this)"></label>'
      +'<div class="mini">Nur AKTIVE Dateien werden verwendet - zufaellig gewaehlt. Ohne aktive Datei erzeugt die KI Musik.</div></div>';"""
    if "musik_prompt" in alte_zeile and "textarea" in alte_zeile:
        s = s.replace(alte_zeile, alte_zeile + "\n" + neu, 1)
    else:
        s = s.replace(alte_zeile, neu, 1)

    s = s.replace("var D={}, seite='dash',", "var musikFrage=null;\nvar D={}, seite='dash',", 1)

    if 'function musikHoch' not in s:
        s = s.replace("function bildHoch(kid,el){",
"""function musikHoch(kid,el){
  var dateien=Array.prototype.slice.call(el.files);
  var offen=dateien.length;
  if(!offen)return;
  melde(offen+' Datei(en) werden hochgeladen...');
  dateien.forEach(function(f){
    var leser=new FileReader();
    leser.onload=function(){
      fetch('/api/musik_hoch',{method:'POST',body:JSON.stringify({kanal:kid,name:f.name,daten:leser.result})})
        .then(function(){offen--;if(offen===0){melde('Hochgeladen');laden();}});
    };
    leser.readAsDataURL(f);
  });
}
function musikAktiv(kid,name,an){
  fetch('/api/musik_aktiv',{method:'POST',body:JSON.stringify({kanal:kid,name:name,aktiv:an})})
    .then(function(){laden();});
}
function musikWeg(kid,name){
  musikFrage=null;
  fetch('/api/musik_weg',{method:'POST',body:JSON.stringify({kanal:kid,name:name})})
    .then(function(){melde('Geloescht');laden();});
}
function bildHoch(kid,el){""", 1)
    if 'function musikAktiv' not in s:
        s = s.replace("function musikWeg(kid,name){",
"""function musikAktiv(kid,name,an){
  fetch('/api/musik_aktiv',{method:'POST',body:JSON.stringify({kanal:kid,name:name,aktiv:an})})
    .then(function(){laden();});
}
function musikWeg(kid,name){""", 1)
    print("2b. Frontend: Musikliste mit Aktiv-Schalter und Upload")
elif 'Eigene Musikdateien' in s:
    print("2b. Frontend: schon vorhanden")
else:
    print("2b. WARNUNG: Einbaustelle nicht gefunden")

p.write_text(s, encoding='utf-8')
print("FERTIG - Seite neu laden")
