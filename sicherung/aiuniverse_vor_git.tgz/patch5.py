# Patch 5: Zoom-Ruecksprung beheben + abwechslungsreiche Bilder
from pathlib import Path

# --- 1. video_bauen.py: Zoom fluessig ueber die volle Dauer ---
p = Path('video_bauen.py'); s = p.read_text(encoding='utf-8')
if 'scale=2560' not in s:
    s = s.replace(
        '''            filt = f"[{i}:v]scale=1600:900:force_original_aspect_ratio=increase,crop=1600:900,{_zoom_filter(i, pro_bild)},setsar=1[v{i}]"''',
        '''            filt = (f"[{i}:v]scale=2560:1440:force_original_aspect_ratio=increase,"
                    f"crop=2560:1440,{_zoom_filter(i, pro_bild)},"
                    f"scale=1280:720,setsar=1,fps=30[v{i}]")''')
    s = s.replace(
        '''            filt = f"[{i}:v]scale=1280:720:force_original_aspect_ratio=increase,crop=1280:720,setsar=1[v{i}]"''',
        '''            filt = (f"[{i}:v]scale=1280:720:force_original_aspect_ratio=increase,"
                    f"crop=1280:720,setsar=1,fps=30[v{i}]")''')
    p.write_text(s, encoding='utf-8')
    print("video_bauen.py: Zoom laeuft jetzt durch")
else:
    print("video_bauen.py: schon ok")

# --- 2. text_generator.py: Bilder muessen verschieden sein ---
p = Path('text_generator.py'); s = p.read_text(encoding='utf-8')
if 'JEDES Bild deutlich anders' not in s:
    regel = ('BILDER - SEHR WICHTIG: JEDES Bild deutlich anders! '
             'Wechsle bei jedem Bild Motiv, Ort, Perspektive (nah/weit/von oben), '
             'Tageszeit und Farbstimmung. Keine zwei aehnlichen Bilder. '
             'Bildbeschreibungen auf Englisch, konkret und bildhaft. '
             'Schlecht: "money", "coins", "cash". '
             'Gut: "close-up hands counting euro bills on wooden table", '
             '"wide shot modern bank building at sunset", '
             '"overhead view piggy bank on desk with laptop".\\n\\n')
    marken = ['Antworte NUR mit JSON', 'WICHTIG: Fasse dich KURZ',
              'AUFGABE:', 'REGELN:']
    fertig = False
    for marke in marken:
        if marke in s:
            s = s.replace(marke, regel + marke, 1)
            p.write_text(s, encoding='utf-8')
            print(f"text_generator.py: Bild-Regel eingebaut (vor '{marke}')")
            fertig = True
            break
    if not fertig:
        print("WARNUNG: keine Einbaustelle gefunden - bitte melden")
else:
    print("text_generator.py: schon ok")
print("FERTIG")
