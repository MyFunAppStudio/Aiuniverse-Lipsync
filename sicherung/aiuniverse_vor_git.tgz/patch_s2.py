import os, shutil
B = "/root/aiuniverse"
p = os.path.join(B, "dashboard2.html")
t = open(p, encoding="utf-8").read()
if "function tSzenen" in t:
    print("INFO  Oberflaeche: Szenen waren schon drin")
    raise SystemExit(0)

CSS = '''.szn{background:#15151A;border:1px solid #24242C;border-radius:12px;padding:10px;margin-bottom:9px}
.szn .kopf{display:flex;align-items:center;gap:8px;margin-bottom:8px}
.szn .nr{font-size:10px;color:#74747F;letter-spacing:.08em;flex:1}
.szn .bildchen{width:100%;height:132px;object-fit:cover;border-radius:9px;background:#0B0B0D;display:block}
.szn textarea{width:100%;min-height:58px;margin-top:8px}
.szz{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-top:8px}
.szh{font-size:10.5px;color:#7E7E89}
.hak{display:flex;align-items:center;gap:6px;font-size:12px;color:#A7A7B2;cursor:pointer}
.hak input{width:17px;height:17px;accent-color:#FF6A1A}
.hak.aus{opacity:.45}
.szn select,.szn input[type=text]{font-size:12px}
'''

JS = r'''
/* ---------- Eigene Szenen ---------- */
function ladeSzenen(){return api("/api/szenen?k="+S.kanal).then(function(d){S.szenen=d;zeichne()})}

function szeneSetz(id,feld,wert){
  api("/api/szenen?k="+S.kanal,{aktion:feld,id:id,wert:wert}).then(function(r){
    if(!r.ok)return melde(r.fehler||"ging nicht");ladeSzenen()})
}
function szeneSchieb(id,wohin){
  api("/api/szenen?k="+S.kanal,{aktion:wohin,id:id}).then(function(){ladeSzenen()})
}
function szeneWeg(id,name){
  frage("Szene löschen?","<b>"+h(name)+"</b><br><br>Die Szene und ihre Datei werden gelöscht.","Löschen",
    function(){api("/api/szenen?k="+S.kanal,{aktion:"weg",id:id}).then(function(){ladeSzenen()})},true)
}
function musikWeg(){
  frage("Lied entfernen?","Das hochgeladene Lied wird gelöscht.","Entfernen",
    function(){api("/api/szenen?k="+S.kanal,{aktion:"musik_weg"}).then(function(){ladeSzenen()})},true)
}

function hochladen(zweck){
  var i=document.createElement("input");
  i.type="file";
  i.accept=(zweck==="musik")?"audio/*":"image/*,video/*";
  i.onchange=function(){
    var f=i.files&&i.files[0];if(!f)return;
    if(f.size>90*1024*1024){melde("Datei zu groß — höchstens 90 MB.");return}
    el("dialog").innerHTML='<div class="dim"><div class="dlg"><h2>Lädt hoch</h2><p id="hpro">'+h(f.name)+' · 0 %</p></div></div>';
    var x=new XMLHttpRequest();
    x.open("POST","/api/hochladen?k="+encodeURIComponent(S.kanal)+"&zweck="+zweck+"&name="+encodeURIComponent(f.name));
    x.upload.onprogress=function(e){if(e.lengthComputable&&el("hpro"))el("hpro").textContent=f.name+" · "+Math.round(e.loaded/e.total*100)+" %"};
    x.onload=function(){zu();var r={};try{r=JSON.parse(x.responseText)}catch(err){}
      if(!r.ok)return melde(r.fehler||"Hochladen ging nicht");ladeSzenen()};
    x.onerror=function(){zu();melde("Hochladen fehlgeschlagen — Verbindung weg?")};
    x.send(f);
  };
  i.click();
}

function szenenDauer(){
  var ges=0;
  ((S.szenen||{}).szenen||[]).forEach(function(s){
    ges+= s.gesprochen ? s.vorschlag : (Number(s.sekunden)||s.vorschlag);
  });
  return ges;
}

function tSzenen(){
  var d=S.szenen;
  if(!d){ladeSzenen();return '<div class="karte p"><div class="leer">lade…</div></div>'}
  var li=d.szenen||[];
  var o='<div class="karte p"><h2 class="kt">Eigenes Lied</h2><div class="liste">';
  if(!d.musik)o+='<div class="leer">keins — dann nimmt er die Automatik-Musik</div>';
  else o+='<div class="e"><div class="tx"><div class="ti">'+h(d.musik)+'</div><div class="me">läuft unter dem ganzen Video</div></div>'
        +'<button class="ik rot" onclick="musikWeg()">✕</button></div>';
  o+='</div><button class="knopf" style="width:100%;margin-top:9px" onclick="hochladen(\'musik\')">+ Lied hochladen</button></div>';

  o+='<div class="karte p"><h2 class="kt">Szenen · '+li.length+' · etwa '+Math.round(szenenDauer())+' Sek.</h2>';
  if(!li.length)o+='<div class="leer">noch nichts — lade dein erstes Bild hoch</div>';
  li.forEach(function(s,i){
    var vor=(s.typ==="clip")
      ? '<video class="bildchen" controls preload="metadata" playsinline src="/eigen/'+encodeURIComponent(s.datei)+'?k='+S.kanal+'"></video>'
      : '<img class="bildchen" src="/eigen/'+encodeURIComponent(s.datei)+'?k='+S.kanal+'" alt="">';
    o+='<div class="szn"><div class="kopf"><div class="nr">'+(i+1)+' · '+(s.typ==="clip"?"CLIP":"BILD")+' · '+h(s.datei)+'</div>'
     +'<button class="ik" onclick="szeneSchieb(\''+s.id+'\',\'hoch\')"'+(i===0?" disabled":"")+'>↑</button>'
     +'<button class="ik" onclick="szeneSchieb(\''+s.id+'\',\'runter\')"'+(i===li.length-1?" disabled":"")+'>↓</button>'
     +'<button class="ik rot" onclick="szeneWeg(\''+s.id+'\',\''+h(s.datei).replace(/'/g,"")+'\')">✕</button></div>'
     +vor
     +'<textarea placeholder="Was in dieser Szene gesagt oder gezeigt wird" onchange="szeneSetz(\''+s.id+'\',\'text\',this.value)">'+h(s.text||"")+'</textarea>'
     +'<div class="szz">'
     +'<label class="hak"><input type="checkbox"'+(s.gesprochen?" checked":"")+' onchange="szeneSetz(\''+s.id+'\',\'gesprochen\',this.checked)">Gesprochen</label>'
     +'<label class="hak"><input type="checkbox"'+(s.untertitel?" checked":"")+' onchange="szeneSetz(\''+s.id+'\',\'untertitel\',this.checked)">Untertitel</label>'
     +'</div>';
    if(!s.gesprochen){
      o+='<div class="szz"><span class="szh">Sekunden</span><input type="text" style="width:62px" value="'
        +h(String(s.sekunden||s.vorschlag))+'" onchange="szeneSetz(\''+s.id+'\',\'sekunden\',this.value)"></div>';
    }else{
      o+='<div class="szz"><span class="szh">Dauert so lang wie der Satz, etwa '+s.vorschlag+' Sek.</span></div>';
    }
    if(s.typ!=="clip"){
      o+='<div class="szz"><span class="szh">Bewegung</span><select onchange="szeneSetz(\''+s.id+'\',\'bewegung\',this.value)">'
       +(d.bewegungen||[]).map(function(b){return '<option value="'+b[0]+'"'+(s.bewegung===b[0]?" selected":"")+'>'+h(b[1])+'</option>'}).join("")
       +'</select></div>';
    }
    o+='<div class="szz"><span class="szh">Figur</span><input type="text" style="width:104px" placeholder="Kanalstimme" value="'
      +h(s.figur||"")+'" onchange="szeneSetz(\''+s.id+'\',\'figur\',this.value)"></div>';
    if(s.typ!=="clip")o+='<div class="szz"><label class="hak aus"><input type="checkbox" disabled>KI-Animation (Kling, noch nicht angeschlossen)</label></div>';
    if(!s.da)o+='<div class="szz"><span class="szh" style="color:#FF6A1A">Datei fehlt auf dem Server</span></div>';
    o+='</div>';
  });
  o+='<button class="knopf or" style="width:100%;margin-top:4px" onclick="hochladen(\'szene\')">+ Bild oder Clip</button></div>';
  o+='<div class="karte p"><div class="hinw" style="padding:0">Die Szenen laufen in dieser Reihenfolge. '
   +'Ist „Gesprochen“ an, dauert die Szene genau so lang wie ihr Satz. Ist es aus, gilt die Sekundenzahl.</div></div>';
  return o;
}
'''

alt_prompt = "function tPrompt(){\n  var o='<div class=\"karte p\"><h2 class=\"kt\">Masterprompt</h2>'"
neu_prompt = '''function tPrompt(){
  var modus=(S.einst.modus==="szenen")?"szenen":"auto";
  var kopf='<div class="karte">'+reihe("Wie das Video entsteht",
    wahl("modus",modus,[["auto","Claude schreibt es"],["szenen","Ich baue es selbst"]]),
    modus==="szenen"?"Deine Bilder, Clips und Texte":"Thema rein, fertiges Video raus")+'</div>';
  if(modus==="szenen")return kopf+tSzenen();
  var o=kopf+'<div class="karte p"><h2 class="kt">Masterprompt</h2>\''''

paare = [
    ("</style>", CSS + "</style>", 1),
    ("/* ---------- Start ---------- */", JS + "\n/* ---------- Start ---------- */", 1),
    (alt_prompt, neu_prompt, 1),
    ('videos:[],preis:{},modelle:null,vorlagen:{}', 'videos:[],preis:{},modelle:null,szenen:null,vorlagen:{}', 1),
    ('function waehle(k){S.kanal=k;S.tab="start";S.modelle=null;laden()}',
     'function waehle(k){S.kanal=k;S.tab="start";S.modelle=null;S.szenen=null;laden()}', 1),
]
for a, b, n in paare:
    if a not in t:
        print("ACHT  Stelle nicht gefunden, nichts geaendert:", a[:48])
        raise SystemExit(1)
shutil.copy2(p, p + ".bak_s1")
for a, b, n in paare:
    t = t.replace(a, b, n)
open(p, "w", encoding="utf-8").write(t)
print("OK    Oberflaeche: Szenen-Editor eingebaut")
