import os, shutil
B = "/root/aiuniverse"
p = os.path.join(B, "dashboard2.html")
t = open(p, encoding="utf-8").read()
if "musik_leise" in t:
    print("INFO  Oberflaeche: Musikregler waren schon drin")
    raise SystemExit(0)

KARTE = r'''  o+='<div class="karte p"><h2 class="kt">Musik</h2><div class="liste">';
  if(!d.musik)o+='<div class="leer">kein eigenes Lied — dann nimmt er die Automatik-Musik</div>';
  else o+='<div class="e"><div class="tx"><div class="ti">'+h(d.musik)+'</div><div class="me">läuft unter dem ganzen Video</div></div>'
        +'<button class="ik rot" onclick="musikWeg()">✕</button></div>';
  o+='</div><button class="knopf" style="width:100%;margin:9px 0 4px" onclick="hochladen(\'musik\')">+ Lied hochladen</button>'
   +reihe("Leise unter der Stimme",zahl("musik_leise",(S.einst.musik_leise==null?12:S.einst.musik_leise)),"in Prozent")
   +reihe("Laut ohne Stimme",zahl("musik_laut",(S.einst.musik_laut==null?75:S.einst.musik_laut)),"in Prozent")
   +'<div class="r"><div><div class="lb">Ohne Stimme lauter</div><div class="hint">'
   +(S.einst.musik_anheben===false?"aus — bleibt durchgehend leise":"ab etwa 2,5 Sekunden Stille")+'</div></div>'
   +schalter("musik_anheben",S.einst.musik_anheben!==false)+'</div>'
   +reihe("Einblenden",zahl("musik_ein",(S.einst.musik_ein==null?1:S.einst.musik_ein)),"Sekunden am Anfang")
   +reihe("Ausblenden",zahl("musik_aus",(S.einst.musik_aus==null?1.5:S.einst.musik_aus)),"Sekunden am Ende")
   +'</div>';
'''

ALT_LIED = '''  var o='<div class="karte p"><h2 class="kt">Eigenes Lied</h2><div class="liste">';
  if(!d.musik)o+='<div class="leer">keins — dann nimmt er die Automatik-Musik</div>';
  else o+='<div class="e"><div class="tx"><div class="ti">'+h(d.musik)+'</div><div class="me">läuft unter dem ganzen Video</div></div>'
        +'<button class="ik rot" onclick="musikWeg()">✕</button></div>';
  o+='</div><button class="knopf" style="width:100%;margin-top:9px" onclick="hochladen(\\'musik\\')">+ Lied hochladen</button></div>';
'''

MUSIKFELD = '''    o+='<div class="szz"><span class="szh">Musik</span><input type="text" style="width:78px" placeholder="automatisch" value="'
      +h(s.musik==="auto"?"":String(s.musik))+'" onchange="szeneSetz(\\''+s.id+'\\',\\'musik\\',this.value)"><span class="szh">% · leer = automatisch</span></div>';
'''

paare = [
    (ALT_LIED, "  var o='';\n" + KARTE, 1),
    ('''    if(s.typ!=="clip")o+='<div class="szz"><label class="hak aus">''',
     MUSIKFELD + '''    if(s.typ!=="clip")o+='<div class="szz"><label class="hak aus">''', 1),
]
for a, b, n in paare:
    if a not in t:
        print("ACHT  Stelle nicht gefunden, nichts geaendert:", a[:50].replace("\n", " "))
        raise SystemExit(1)
shutil.copy2(p, p + ".bak_s4")
for a, b, n in paare:
    t = t.replace(a, b, n)
open(p, "w", encoding="utf-8").write(t)
print("OK    Oberflaeche: Musikregler und Musik je Szene eingebaut")
