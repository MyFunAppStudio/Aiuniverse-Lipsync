import os, re, shutil, subprocess, sys
BASIS = "/root/aiuniverse"
p = os.path.join(BASIS, "video_bauen.py")
t = open(p, encoding="utf-8").read()
if not os.path.exists(p + ".bak_f9"):
    shutil.copy2(p, p + ".bak_f9")
BP = """
# ===== Bildpruefung (BP) =====
def _bp_hell(pfad):
    try:
        r = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", str(pfad),
                            "-vf", "signalstats,metadata=print:key=lavfi.signalstats.YAVG",
                            "-f", "null", "-"], capture_output=True, text=True, timeout=60)
        m = re.search(r"YAVG=([0-9.]+)", r.stderr or "")
        return float(m.group(1)) if m else 128.0
    except Exception:
        return 128.0


def _bp_ok(pfad):
    try:
        if not os.path.exists(pfad) or os.path.getsize(pfad) < 20000:
            return False
    except Exception:
        return False
    return _bp_hell(pfad) >= 22.0


def _bilder_pruefen(bilder):
    b = [str(x) for x in (bilder or [])]
    if not b:
        return bilder
    gut = [_bp_ok(x) for x in b]
    if all(gut):
        return bilder
    schlecht = [i for i, g in enumerate(gut) if not g]
    print("[Video] %d unbrauchbare Bilder: %s" % (len(schlecht),
          ", ".join(os.path.basename(b[i]) for i in schlecht)))
    if not any(gut):
        print("[Video] ALLE Bilder unbrauchbar")
        return bilder
    raus = list(b)
    for i in schlecht:
        j = next((k for k in range(i - 1, -1, -1) if gut[k]), None)
        if j is None:
            j = next((k for k in range(i + 1, len(b)) if gut[k]), None)
        raus[i] = b[j]
        print("[Video] %s ersetzt durch %s" % (os.path.basename(b[i]),
              os.path.basename(b[j])))
    return raus
"""
if "_bilder_pruefen" in t:
    print("INFO  Bildpruefung war schon drin")
elif "_tt_ton_setzen(ton_pfad)" not in t:
    print("ACHT  Einhaengepunkt fehlt - patch_f5 nicht eingespielt?")
else:
    t = t.rstrip() + "\n" + BP
    t = t.replace("    _tt_ton_setzen(ton_pfad)\n",
                  "    _tt_ton_setzen(ton_pfad)\n    bilder = _bilder_pruefen(bilder)\n", 1)
    open(p, "w", encoding="utf-8").write(t)
    r = subprocess.run([sys.executable, "-m", "py_compile", p],
                       capture_output=True, text=True)
    if r.returncode:
        shutil.copy2(p + ".bak_f9", p)
        print("ACHT  Syntaxfehler, zurueckgesetzt:", r.stderr[-200:])
        raise SystemExit(1)
    print("OK    Bildpruefung eingebaut")
print("FERTIG")
