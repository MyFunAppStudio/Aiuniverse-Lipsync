import os, shutil, subprocess, sys
B = "/root/aiuniverse"

p = os.path.join(B, "dashboard2.py")
t = open(p, encoding="utf-8").read()

alt = '''def slots():
    try:
        return list(einstellungen.API_SLOTS)
    except Exception:
        return ["text", "bilder", "stimme", "video", "musik", "sound", "avatar"]'''

neu = '''def slots():
    standard = ["text", "bilder", "stimme", "video", "musik", "sound", "avatar"]
    try:
        roh = list(einstellungen.API_SLOTS)
    except Exception:
        return standard
    raus = []
    for x in roh:
        if isinstance(x, dict):
            x = x.get("slot") or x.get("key") or x.get("name") or ""
        elif isinstance(x, (list, tuple)):
            x = x[0] if x else ""
        if isinstance(x, str) and x and x not in raus:
            raus.append(x)
    return raus or standard'''

if 'standard = ["text", "bilder"' in t:
    print("INFO  Slot-Fix war schon drin")
elif alt not in t:
    print("ACHT  slots() nicht gefunden - nichts geaendert")
    raise SystemExit(1)
else:
    shutil.copy2(p, p + ".bak_m3")
    t = t.replace(alt, neu, 1)
    open(p, "w", encoding="utf-8").write(t)
    r = subprocess.run([sys.executable, "-m", "py_compile", p], capture_output=True, text=True)
    if r.returncode:
        shutil.copy2(p + ".bak_m3", p)
        print("ACHT  zurueckgesetzt:", r.stderr[-200:])
        raise SystemExit(1)
    print("OK    Slots werden jetzt sauber zu Namen gemacht")

try:
    sys.path.insert(0, B)
    import einstellungen
    print("INFO  API_SLOTS im Original:", repr(getattr(einstellungen, "API_SLOTS", "nicht da"))[:300])
except Exception as e:
    print("INFO  API_SLOTS nicht lesbar:", e)
print("TEIL 3 FERTIG")
