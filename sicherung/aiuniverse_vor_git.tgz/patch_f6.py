#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""patch_f6.py  -  Saetze an den laengsten Sprechpausen verankern."""
import os, shutil, subprocess, sys
BASIS = "/root/aiuniverse"
TT3 = '\n# ===== Untertitel-Zuordnung ueber die laengsten Pausen (TT_V3) =====\ndef _tt_teil_segmente(seg, a0, a1):\n    """Sprechabschnitte innerhalb eines Zeitbereichs."""\n    raus = []\n    for s, e in seg:\n        s2, e2 = max(s, a0), min(e, a1)\n        if e2 - s2 > 0.05:\n            raus.append((s2, e2))\n    return raus or [(a0, a1)]\n\n\ndef baue_untertitel_ass(*a, **k):\n    """Haeppchen-Untertitel, Saetze an den laengsten Sprechpausen verankert."""\n    text = k.get("text") if "text" in k else (a[0] if len(a) > 0 else "")\n    gesamt = k.get("gesamt_sek") if "gesamt_sek" in k else (a[1] if len(a) > 1 else 0)\n    ziel = k.get("ziel") if "ziel" in k else (a[2] if len(a) > 2 else None)\n    kanal = k.get("kanal") if "kanal" in k else (a[4] if len(a) > 4 else None)\n    gesamt = float(gesamt or 0)\n    if not ziel:\n        return None\n\n    # kanal darf Buchstabe oder Einstellungs-Paket sein\n    e = {}\n    if isinstance(kanal, dict):\n        e = kanal\n    elif kanal:\n        try:\n            _setze_format(kanal)\n        except Exception:\n            pass\n        try:\n            e = einstellungen.laden().get(kanal) or {}\n        except Exception:\n            e = {}\n\n    try:\n        fak = float(e.get("untertitel_groesse", 48) or 48) / 48.0\n    except Exception:\n        fak = 1.0\n    fak = max(0.5, min(2.0, fak))\n    caps = e.get("untertitel_caps", True)\n    try:\n        pro = int(e.get("untertitel_woerter", 3) or 3)\n    except Exception:\n        pro = 3\n    pro = max(1, min(5, pro))\n\n    hoch = HOEHE >= BREITE\n    fs = max(20, int(BREITE * (0.088 if hoch else 0.052) * fak))\n    rand = max(2, int(fs * 0.12))\n    schatten = max(1, int(fs * 0.035))\n    ml = int(BREITE * 0.08)\n    mv = int(HOEHE * (0.30 if hoch else 0.09))\n    kopf = _tt_ass_kopf(fs, rand, schatten, ml, mv, _tt_schrift())\n\n    stuecke = _tt_stuecke(text, max_w=pro, max_z=15)\n    if not stuecke:\n        with open(ziel, "w", encoding="utf-8") as f:\n            f.write(kopf)\n        return ziel\n\n    ton = _TT_TON if (_TT_TON and os.path.exists(_TT_TON)) else None\n    if ton:\n        d = _tt_dauer(ton)\n        if d > 0.5:\n            gesamt = d\n    if gesamt <= 0:\n        gesamt = max(1.0, len(stuecke) * 0.8)\n    seg = _tt_sprachsegmente(ton, gesamt) if ton else [(0.0, gesamt)]\n\n    saetze, akt = [], []\n    for st in stuecke:\n        akt.append(st)\n        if st and st[-1][-1:] in ".!?":\n            saetze.append(akt)\n            akt = []\n    if akt:\n        saetze.append(akt)\n\n    def gewicht(st):\n        g = sum(_tt_silben(w) for w in st) + 0.35 * len(st)\n        if st and st[-1][-1:] in ".!?":\n            g += 0.45\n        elif st and st[-1][-1:] in ",;:":\n            g += 0.25\n        return max(0.6, g)\n\n    if len(seg) >= len(saetze):\n        # die (n-1) laengsten Pausen sind die Satzgrenzen\n        luecken = sorted(((seg[i + 1][0] - seg[i][1], i) for i in range(len(seg) - 1)),\n                         reverse=True)\n        schnitt = sorted(i for _, i in luecken[:max(0, len(saetze) - 1)])\n        bereiche, start = [], 0\n        for idx in schnitt + [len(seg) - 1]:\n            bereiche.append((seg[start][0], seg[idx][1]))\n            start = idx + 1\n    else:\n        # weniger Pausen als Saetze: anteilig aufteilen\n        wand, sprechzeit = _tt_wand(seg)\n        sg = [sum(gewicht(x) for x in s_) for s_ in saetze]\n        ges = float(sum(sg)) or 1.0\n        kanten, lauf = [seg[0][0]], 0.0\n        for g in sg[:-1]:\n            lauf += g\n            kanten.append(wand(sprechzeit * lauf / ges))\n        kanten.append(seg[-1][1])\n        bereiche = [(kanten[i], max(kanten[i] + 0.3, kanten[i + 1]))\n                    for i in range(len(kanten) - 1)]\n    while len(bereiche) < len(saetze):\n        bereiche.append((seg[-1][1] - 0.3, seg[-1][1]))\n\n    zeilen = []\n    for si, satz in enumerate(saetze):\n        a0, a1 = bereiche[si]\n        teil = _tt_teil_segmente(seg, a0, a1)\n        twand, tzeit = _tt_wand(teil)\n        sg = [gewicht(x) for x in satz]\n        su = float(sum(sg)) or 1.0\n        lauf = 0.0\n        for j, st in enumerate(satz):\n            t0 = twand(lauf)\n            lauf += tzeit * sg[j] / su\n            t1 = a1 if j == len(satz) - 1 else twand(lauf)\n            if t1 - t0 < 0.28:\n                t1 = min(a1, t0 + 0.28)\n            if t1 <= t0:\n                t1 = t0 + 0.28\n            sil = float(sum(_tt_silben(x) for x in st) or 1)\n            zent = [max(10, int(round((t1 - t0) * 100 * _tt_silben(w) / sil))) for w in st]\n            diff = int(round((t1 - t0) * 100)) - sum(zent)\n            if zent:\n                zent[-1] = max(10, zent[-1] + diff)\n            inhalt = "".join("{\\\\k%d}%s " % (zent[q], (w.upper() if caps else w))\n                             for q, w in enumerate(st)).strip()\n            vor = "{\\\\fad(60,60)\\\\fscx86\\\\fscy86\\\\t(0,120,\\\\fscx100\\\\fscy100)}"\n            zeilen.append("Dialogue: 0,%s,%s,TT,,0,0,0,,%s%s"\n                          % (_tt_zeit(t0), _tt_zeit(t1), vor, inhalt))\n    with open(ziel, "w", encoding="utf-8") as f:\n        f.write(kopf + "\\n".join(zeilen) + "\\n")\n    return ziel\n'


def main():
    p = os.path.join(BASIS, "video_bauen.py")
    if not os.path.exists(p):
        print("FEHLER: video_bauen.py fehlt")
        return 1
    with open(p, encoding="utf-8") as f:
        t = f.read()
    if "_tt_sprachsegmente" not in t:
        print("FEHLER: patch_f5 fehlt noch")
        return 1
    if "_tt_teil_segmente" in t:
        print("INFO  war schon drin")
    else:
        if not os.path.exists(p + ".bak_f6"):
            shutil.copy2(p, p + ".bak_f6")
        with open(p, "w", encoding="utf-8") as f:
            f.write(t.rstrip() + "\n" + TT3)
        r = subprocess.run([sys.executable, "-m", "py_compile", p],
                           capture_output=True, text=True)
        if r.returncode != 0:
            shutil.copy2(p + ".bak_f6", p)
            print("ACHT  Syntaxfehler, zurueckgesetzt: " + (r.stderr or "")[-300:])
            return 1
        print("OK    Satzverankerung eingebaut")

    # Probe am letzten echten Lauf
    try:
        sys.path.insert(0, BASIS)
        import video_bauen as V
        fv = os.path.join(BASIS, "fertige_videos")
        ton = None
        for o in sorted(os.listdir(fv), reverse=True):
            for n in ("ton_fertig.m4a", "stimme.mp3"):
                kk = os.path.join(fv, o, n)
                if os.path.exists(kk):
                    ton = kk
                    break
            if ton:
                break
        if ton:
            V._setze_format("b")
            V._tt_ton_setzen(ton)
            d = V._tt_dauer(ton)
            sg = V._tt_sprachsegmente(ton, d)
            V.baue_untertitel_ass("Erster Satz zum Pruefen. Zweiter Satz hier. "
                                  "Und der dritte Satz!", d, "/tmp/probe.ass", "modern", "b")
            print("Ton %.1fs, %d Sprechabschnitte" % (d, len(sg)))
            for z in open("/tmp/probe.ass", encoding="utf-8").read().splitlines():
                if z.startswith("Dialogue"):
                    q = z.split(",")
                    print("  %s - %s" % (q[1], q[2]))
    except Exception as ex:
        print("Probe uebersprungen: %s" % ex)
    print("FERTIG  (Dashboard wurde NICHT neu gestartet)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
