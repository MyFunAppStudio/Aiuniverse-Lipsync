import sys, json, time, os
sys.path.insert(0, '/root/aiuniverse')
import einstellungen, bilder, schluessel

KANAL = sys.argv[1] if len(sys.argv) > 1 else 'a'
d = einstellungen.laden().get(KANAL) or {}
e = bilder._slot(d, braucht_vorlage=True) or bilder._slot(d)
if not e:
    print('Kein Bildmodell eingetragen'); raise SystemExit(1)
print('Kanal   :', KANAL, '-', d.get('name'))
print('Modell  :', e.get('name'), '|', e.get('url'))
key = schluessel.fuer(d, e)
print('Schlssl :', 'vorhanden' if key else 'FEHLT')

figur = (d.get('geschichte_figur') or '').strip()
ref = bilder.figur_referenz(d, figur) if figur else None
print('Figur   :', figur or '(keine)')
if ref:
    print('Vorlage :', os.path.basename(ref), '%.2f MB' % (os.path.getsize(ref) / 1048576.0))
else:
    print('Vorlage : keine gefunden')

feld = ''
uri = None
if ref:
    for merkmal, f in bilder.REFERENZ_FELD:
        if merkmal in (e.get('url') or '').lower():
            feld = f
            break
    uri = bilder._daten_uri(ref)

basis = bilder._basis_url(e.get('url'))
print('Adresse :', basis)
print('Feld    :', feld or '(keins)')
print()

start = None
t0 = time.time()
for nr, koerper in enumerate(bilder._koerper_varianten(
        'ein Fuchs sitzt am Fluss, Kinderbuch-Illustration', '9:16', feld, uri), 1):
    felder = sorted(koerper.keys())
    gross = len(json.dumps(koerper)) / 1048576.0
    try:
        start = bilder._ruf(basis, key, koerper, zeit=120)
        print('Variante %d %s  %.2f MB  -> angenommen nach %.0f s' % (nr, felder, gross, time.time() - t0))
        break
    except Exception as f:
        print('Variante %d %s  %.2f MB  -> %s' % (nr, felder, gross, repr(f)[:120]))
        start = None
if not start:
    print(); print('Keine Variante angenommen.'); raise SystemExit(1)
print()
print(json.dumps({k: v for k, v in start.items() if 'image' not in k})[:500])
print()

su = start.get('status_url')
if not su:
    print('Keine status_url - Antwort oben ist alles was kommt'); raise SystemExit(0)
for i in range(8):
    time.sleep(12)
    try:
        st = bilder._ruf(su, key, zeit=40)
    except Exception as f:
        print('%2d. %4.0f s  FEHLER %s' % (i + 1, time.time() - t0, repr(f)[:160])); continue
    print('%2d. %4.0f s  %s' % (i + 1, time.time() - t0, json.dumps(st)[:240]))
    if (st.get('status') or '').upper() in ('COMPLETED', 'FAILED', 'ERROR'):
        break
