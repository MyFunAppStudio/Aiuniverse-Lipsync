#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""patch_f3.py  -  Ken-Burns verzerrt nicht mehr + Videolaenge stimmt."""
import os, re, shutil, subprocess, sys

BASIS = "/root/aiuniverse"
BERICHT = []


def ok(m):
    BERICHT.append("OK    " + m)


def info(m):
    BERICHT.append("INFO  " + m)


def warn(m):
    BERICHT.append("ACHT  " + m)


def P(n):
    return os.path.join(BASIS, n)


def lese(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def schreibe(p, t):
    if not os.path.exists(p + ".bak_f3"):
        shutil.copy2(p, p + ".bak_f3")
    with open(p, "w", encoding="utf-8") as f:
        f.write(t)


def pruefe(p):
    r = subprocess.run([sys.executable, "-m", "py_compile", p],
                       capture_output=True, text=True)
    return r.returncode == 0, (r.stderr or "")[-400:]


def zurueck(p):
    if os.path.exists(p + ".bak_f3"):
        shutil.copy2(p + ".bak_f3", p)


# ---------- 1) video_bauen.py ----------

def patch_vb():
    p = P("video_bauen.py")
    if not os.path.exists(p):
        warn("video_bauen.py nicht gefunden")
        return
    t = lese(p)
    alt = t
    zl = t.splitlines()

    # a) feste Grossskalierung durch Kanalformat ersetzen
    getan = 0
    for i, z in enumerate(zl):
        m = re.match(r"^(\s*)gross\s*=\s*f?\"scale=\d+:\d+:force_original_aspect_ratio="
                     r"increase,crop=\d+:\d+\"\s*$", z)
        if not m:
            continue
        ein = m.group(1)
        zl[i] = (ein + "_gb = int(BREITE * 1.875) // 2 * 2\n"
                 + ein + "_gh = int(HOEHE * 1.875) // 2 * 2\n"
                 + ein + "gross = f\"scale={_gb}:{_gh}:force_original_aspect_ratio="
                         "increase,crop={_gb}:{_gh}\"")
        getan += 1
    if getan:
        ok("video_bauen.py: Grossskalierung folgt jetzt dem Kanalformat")
    elif "_gb = int(BREITE" in t:
        info("video_bauen.py: Grossskalierung war schon umgestellt")
    else:
        warn("video_bauen.py: gross-Zeile nicht gefunden")

    # b) jedem zoompan Zielgroesse und Bildrate mitgeben
    zs, fs = 0, 0
    muster = r'^(.*zoompan=.*)(")(\s*[,)\]]*\s*)$'
    for i, z in enumerate(zl):
        if "zoompan=" not in z or z.strip().startswith("#"):
            continue
        hinten = z.split("zoompan=", 1)[1]
        neu = z
        if ":s=" not in hinten:
            v = re.sub(muster, r"\1:s={BREITE}x{HOEHE}\2\3", neu)
            if v != neu:
                neu = v
                zs += 1
        if "fps=" not in hinten:
            v = re.sub(muster, r"\1:fps={FPS}\2\3", neu)
            if v != neu:
                neu = v
                fs += 1
        if neu != z:
            zl[i] = neu
    if zs:
        ok("video_bauen.py: %d zoompan auf Zielgroesse gesetzt" % zs)
    if fs:
        ok("video_bauen.py: %d zoompan auf %s Bilder/s gesetzt" % (fs, "FPS"))
    if not zs and not fs:
        info("video_bauen.py: zoompan war schon vollstaendig")

    t = "\n".join(zl)
    if t != alt:
        schreibe(p, t)
        g, f = pruefe(p)
        if not g:
            zurueck(p)
            warn("video_bauen.py: Syntaxfehler, zurueckgesetzt: " + f)
            return
    for z in lese(p).splitlines():
        if "zoompan=" in z and not z.strip().startswith("#"):
            BERICHT.append("      " + z.strip()[:100])


# ---------- 2) text_generator.py ----------

def patch_tg():
    p = P("text_generator.py")
    if not os.path.exists(p):
        warn("text_generator.py nicht gefunden")
        return
    t = lese(p)
    if "ZPS_KORRIGIERT" in t:
        info("text_generator.py: Zeichenrate war schon korrigiert")
        return
    m = re.search(r"^(\s*)ZEICHEN_PRO_SEKUNDE\s*=\s*([0-9]+(?:\.[0-9]+)?)", t, re.M)
    if not m:
        warn("text_generator.py: ZEICHEN_PRO_SEKUNDE nicht gefunden")
        return
    alt_w = float(m.group(2))
    neu_w = round(alt_w * 15.0 / 26.0, 1)
    neu_w = max(9.0, min(18.0, neu_w))
    t = (t[:m.start()] + m.group(1) + "ZEICHEN_PRO_SEKUNDE = %s  # ZPS_KORRIGIERT (vorher %s)"
         % (neu_w, alt_w) + t[m.end():])
    schreibe(p, t)
    g, f = pruefe(p)
    if not g:
        zurueck(p)
        warn("text_generator.py: Syntaxfehler, zurueckgesetzt: " + f)
        return
    ok("text_generator.py: Zeichen pro Sekunde %s -> %s" % (alt_w, neu_w))


def main():
    if not os.path.isdir(BASIS):
        print("FEHLER: %s fehlt" % BASIS)
        return 1
    patch_vb()
    patch_tg()
    os.system("systemctl restart dashboard >/dev/null 2>&1")
    print("=" * 46)
    for z in BERICHT:
        print(z)
    print("=" * 46)
    try:
        sys.path.insert(0, BASIS)
        import video_bauen as V
        V._setze_format("b")
        print("Kanal b: %dx%d, gross %dx%d"
              % (V.BREITE, V.HOEHE, int(V.BREITE * 1.875) // 2 * 2,
                 int(V.HOEHE * 1.875) // 2 * 2))
    except Exception as e:
        print("Pruefung uebersprungen: %s" % e)
    print("FERTIG")
    return 0


if __name__ == "__main__":
    sys.exit(main())
