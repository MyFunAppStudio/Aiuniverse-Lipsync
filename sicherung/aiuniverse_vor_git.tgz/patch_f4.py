#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""patch_f4.py  -  Profi-Untertitel im TikTok-Stil."""
import os, re, shutil, subprocess, sys

BASIS = "/root/aiuniverse"
BERICHT = []


def ok(m):
    BERICHT.append("OK    " + m)


def info(m):
    BERICHT.append("INFO  " + m)


def warn(m):
    BERICHT.append("ACHT  " + m)


TT_BLOCK = '\n# ===== Profi-Untertitel (Patch TT) =====\n_TT_SCHRIFT = None\n\n\ndef _tt_schrift():\n    """Beste vorhandene fette Schrift finden."""\n    global _TT_SCHRIFT\n    if _TT_SCHRIFT:\n        return _TT_SCHRIFT\n    kandidaten = ["Montserrat ExtraBold", "Montserrat", "Inter Display Black",\n                  "Inter Black", "Inter", "Open Sans", "DejaVu Sans"]\n    gefunden = "DejaVu Sans"\n    for name in kandidaten:\n        try:\n            r = subprocess.run(["fc-match", "-f", "%{family}", name],\n                               capture_output=True, text=True, timeout=10)\n            fam = (r.stdout or "").strip()\n            if fam and name.split()[0].lower() in fam.lower():\n                gefunden = name\n                break\n        except Exception:\n            pass\n    _TT_SCHRIFT = gefunden\n    return gefunden\n\n\ndef _tt_zeit(s):\n    if s < 0:\n        s = 0\n    h = int(s // 3600)\n    m = int((s % 3600) // 60)\n    r = s - h * 3600 - m * 60\n    return "%d:%02d:%05.2f" % (h, m, r)\n\n\ndef _tt_stuecke(text, max_w=3, max_z=15):\n    """Text in kurze Haeppchen von 2-3 Woertern schneiden."""\n    worte = [w for w in re.split(r"\\s+", (text or "").strip()) if w]\n    raus, akt = [], []\n    for w in worte:\n        probe = akt + [w]\n        if akt and (len(probe) > max_w or len(" ".join(probe)) > max_z):\n            raus.append(akt)\n            akt = [w]\n        else:\n            akt = probe\n        if akt and w[-1:] in ".!?:;":\n            raus.append(akt)\n            akt = []\n    if akt:\n        raus.append(akt)\n    return raus\n\n\ndef _tt_ass_kopf(fs, rand, schatten, ml, mv, schrift):\n    return (\n        "[Script Info]\\n"\n        "ScriptType: v4.00+\\n"\n        "WrapStyle: 0\\n"\n        "ScaledBorderAndShadow: yes\\n"\n        "YCbCr Matrix: TV.709\\n"\n        "PlayResX: %d\\n"\n        "PlayResY: %d\\n\\n"\n        "[V4+ Styles]\\n"\n        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, "\n        "OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, "\n        "ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, "\n        "Alignment, MarginL, MarginR, MarginV, Encoding\\n"\n        "Style: TT,%s,%d,&H0000D4FF,&H00FFFFFF,&H00000000,&H96000000,"\n        "-1,0,0,0,100,100,0,0,1,%d,%d,2,%d,%d,%d,1\\n\\n"\n        "[Events]\\n"\n        "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, "\n        "Effect, Text\\n" % (BREITE, HOEHE, schrift, fs, rand, schatten, ml, ml, mv)\n    )\n\n\ndef baue_untertitel_ass(*a, **k):\n    """Grosse, fette Haeppchen-Untertitel mit Wort-Highlight."""\n    text = k.get("text") if "text" in k else (a[0] if len(a) > 0 else "")\n    gesamt = k.get("gesamt_sek") if "gesamt_sek" in k else (a[1] if len(a) > 1 else 0)\n    ziel = k.get("ziel") if "ziel" in k else (a[2] if len(a) > 2 else None)\n    kanal = k.get("kanal") if "kanal" in k else (a[4] if len(a) > 4 else None)\n    gesamt = float(gesamt or 0)\n    if not ziel:\n        return None\n    if kanal:\n        try:\n            _setze_format(kanal)\n        except Exception:\n            pass\n\n    e = {}\n    try:\n        e = (einstellungen.laden().get(kanal) or {}) if kanal else {}\n    except Exception:\n        e = {}\n    try:\n        fak = float(e.get("untertitel_groesse", 48) or 48) / 48.0\n    except Exception:\n        fak = 1.0\n    fak = max(0.5, min(2.0, fak))\n    caps = e.get("untertitel_caps", True)\n\n    hoch = HOEHE >= BREITE\n    fs = max(20, int(BREITE * (0.088 if hoch else 0.052) * fak))\n    rand = max(2, int(fs * 0.12))\n    schatten = max(1, int(fs * 0.035))\n    ml = int(BREITE * 0.08)\n    mv = int(HOEHE * (0.30 if hoch else 0.09))\n\n    stuecke = _tt_stuecke(text)\n    if not stuecke or gesamt <= 0:\n        with open(ziel, "w", encoding="utf-8") as f:\n            f.write(_tt_ass_kopf(fs, rand, schatten, ml, mv, _tt_schrift()))\n        return ziel\n\n    gewicht = [max(4, sum(len(w) for w in s) + len(s)) for s in stuecke]\n    summe = float(sum(gewicht))\n    zeilen = []\n    t0 = 0.0\n    for i, st in enumerate(stuecke):\n        dauer = gesamt * gewicht[i] / summe\n        dauer = max(0.38, dauer)\n        t1 = min(gesamt, t0 + dauer)\n        if t1 <= t0:\n            break\n        wz = [max(8, int(round((t1 - t0) * 100 * (len(w) + 1) /\n                               float(sum(len(x) + 1 for x in st))))) for w in st]\n        rest = int(round((t1 - t0) * 100)) - sum(wz)\n        if wz:\n            wz[-1] = max(8, wz[-1] + rest)\n        inhalt = "".join("{\\\\k%d}%s " % (wz[j], (w.upper() if caps else w))\n                         for j, w in enumerate(st)).strip()\n        vor = ("{\\\\fad(70,70)\\\\fscx84\\\\fscy84"\n               "\\\\t(0,130,\\\\fscx100\\\\fscy100)}")\n        zeilen.append("Dialogue: 0,%s,%s,TT,,0,0,0,,%s%s"\n                      % (_tt_zeit(t0), _tt_zeit(t1), vor, inhalt))\n        t0 = t1\n    with open(ziel, "w", encoding="utf-8") as f:\n        f.write(_tt_ass_kopf(fs, rand, schatten, ml, mv, _tt_schrift()) + "\\n".join(zeilen) + "\\n")\n    return ziel\n'


def main():
    p = os.path.join(BASIS, "video_bauen.py")
    if not os.path.exists(p):
        print("FEHLER: video_bauen.py fehlt")
        return 1

    # 1) Schriften nachinstallieren (wenn moeglich)
    for paket in ("fonts-montserrat", "fonts-inter"):
        r = os.system("DEBIAN_FRONTEND=noninteractive apt-get install -y -qq %s "
                      ">/dev/null 2>&1" % paket)
        info("%s: %s" % (paket, "installiert" if r == 0 else "nicht verfuegbar"))

    with open(p, encoding="utf-8") as f:
        t = f.read()
    if "_tt_stuecke" in t:
        info("video_bauen.py: Profi-Untertitel waren schon drin")
    else:
        if not os.path.exists(p + ".bak_f4"):
            shutil.copy2(p, p + ".bak_f4")
        neu, n = re.subn(r"\bdef baue_untertitel_ass\s*\(", "def _ass_wrap_alt(", t, count=1)
        if not n:
            warn("baue_untertitel_ass nicht gefunden")
            return 1
        neu = neu.rstrip() + "\n" + TT_BLOCK
        with open(p, "w", encoding="utf-8") as f:
            f.write(neu)
        r = subprocess.run([sys.executable, "-m", "py_compile", p],
                           capture_output=True, text=True)
        if r.returncode != 0:
            shutil.copy2(p + ".bak_f4", p)
            warn("Syntaxfehler, zurueckgesetzt: " + (r.stderr or "")[-300:])
            return 1
        ok("video_bauen.py: Untertitel komplett neu")

    os.system("systemctl restart dashboard >/dev/null 2>&1")
    print("=" * 46)
    for z in BERICHT:
        print(z)
    print("=" * 46)
    try:
        sys.path.insert(0, BASIS)
        import video_bauen as V
        V._setze_format("b")
        print("Schrift: %s" % V._tt_schrift())
        V.baue_untertitel_ass("Drei Regeln machen dich reicher als jeder Aktientipp. "
                              "Folge mir fuer mehr!", 8.0, "/tmp/probe.ass", "modern", "b")
        zl = open("/tmp/probe.ass", encoding="utf-8").read().splitlines()
        for z in zl:
            if z.startswith("Style:") or z.startswith("Dialogue:"):
                print(z[:110])
    except Exception as e:
        print("Pruefung uebersprungen: %s" % e)
    print("FERTIG")
    return 0


if __name__ == "__main__":
    sys.exit(main())
