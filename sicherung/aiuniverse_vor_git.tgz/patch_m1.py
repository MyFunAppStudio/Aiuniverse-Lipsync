import os, shutil, subprocess, sys
B = "/root/aiuniverse"

# ---------- 1. Server: Modell-Schnittstellen ----------
p = os.path.join(B, "dashboard2.py")
t = open(p, encoding="utf-8").read()
if "def modelle_lesen" in t:
    print("INFO  Server: Modelle waren schon drin")
else:
    shutil.copy2(p, p + ".bak_m1")
    hilfen = '''
def slots():
    try:
        return list(einstellungen.API_SLOTS)
    except Exception:
        return ["text", "bilder", "stimme", "video", "musik", "sound", "avatar"]


def modelle_lesen(key):
    d = einstellungen.laden().get(key) or {}
    apis = d.get("apis") or {}
    raus = {}
    for s in slots():
        liste = []
        for e in (apis.get(s) or []):
            if not isinstance(e, dict):
                continue
            liste.append({
                "name": e.get("name") or "",
                "url": e.get("url") or "",
                "preis": e.get("preis", ""),
                "aktiv": bool(e.get("aktiv")),
                "key": maske(e.get("key") or ""),
            })
        raus[s] = liste
    return {"slots": slots(), "apis": raus}


def modelle_schreiben(key, b):
    alles = einstellungen.laden()
    d = alles.get(key)
    if not isinstance(d, dict):
        return {"ok": False, "fehler": "Kanal unbekannt"}
    d.setdefault("apis", {})
    s = b.get("slot") or ""
    if s not in slots():
        return {"ok": False, "fehler": "Slot unbekannt"}
    d["apis"].setdefault(s, [])
    liste = d["apis"][s]
    a = b.get("aktion")
    i = b.get("i")
    try:
        i = int(i)
    except Exception:
        i = -1
    if a == "neu":
        liste.append({"name": (b.get("name") or "Neu").strip(),
                      "url": (b.get("url") or "").strip(),
                      "key": (b.get("key") or "").strip(),
                      "preis": b.get("preis", ""),
                      "aktiv": False})
    elif 0 <= i < len(liste):
        e = liste[i]
        if a == "weg":
            liste.pop(i)
        elif a == "aktiv":
            for x in liste:
                x["aktiv"] = False
            e["aktiv"] = True
        elif a == "speichern":
            if b.get("name") is not None:
                e["name"] = (b.get("name") or "").strip()
            if b.get("url") is not None:
                e["url"] = (b.get("url") or "").strip()
            if b.get("preis") is not None:
                e["preis"] = b.get("preis")
            if (b.get("key") or "").strip():
                e["key"] = b["key"].strip()
    else:
        return {"ok": False, "fehler": "Eintrag unbekannt"}
    einstellungen.speichern(alles)
    return {"ok": True}


def modell_preis(key, slot, standard):
    for e in ((einstellungen.laden().get(key) or {}).get("apis") or {}).get(slot) or []:
        if isinstance(e, dict) and e.get("aktiv"):
            try:
                return float(str(e.get("preis")).replace(",", "."))
            except Exception:
                return standard
    return standard


'''
    def pflicht(stueck, was):
        if t.count(stueck) < 1:
            print("ACHT  " + was + " nicht gefunden - nichts geaendert")
            raise SystemExit(1)

    pflicht("def api_stand():", "Einhaengepunkt api_stand")
    pflicht('        if w.startswith("/video/"):', "Einhaengepunkt GET")
    pflicht('        if w == "/api/start":', "Einhaengepunkt POST")
    t = t.replace("def api_stand():", hilfen + "def api_stand():", 1)
    alt_preis = '''    except Exception:
        pass
    text = 0.02
    stimme = 0.0 if not d.get("stimme_an", True) else round(sek * 0.008, 3)'''
    neu_preis = '''    except Exception:
        pass
    p_bild = modell_preis(key, "bilder", p_bild)
    text = modell_preis(key, "text", 0.02)
    stimme = 0.0 if not d.get("stimme_an", True) else round(sek * modell_preis(key, "stimme", 0.008), 3)'''
    if t.count(alt_preis) != 1:
        print("ACHT  Preisteil nicht gefunden - nichts geaendert")
        raise SystemExit(1)
    t = t.replace(alt_preis, neu_preis, 1)
    t = t.replace('''        if w.startswith("/video/"):''',
'''        if w == "/api/modelle":
            return self.sende(modelle_lesen(k))

        if w.startswith("/video/"):''', 1)
    t = t.replace('''        if w == "/api/start":''',
'''        if w == "/api/modelle":
            return self.sende(modelle_schreiben(k, b))

        if w == "/api/start":''', 1)
    open(p, "w", encoding="utf-8").write(t)
    r = subprocess.run([sys.executable, "-m", "py_compile", p], capture_output=True, text=True)
    if r.returncode:
        shutil.copy2(p + ".bak_m1", p)
        print("ACHT  Server zurueckgesetzt:", r.stderr[-200:])
        raise SystemExit(1)
    print("OK    Server: Modelle lesen, anlegen, aendern, aktiv schalten")
print("TEIL 1 FERTIG")
