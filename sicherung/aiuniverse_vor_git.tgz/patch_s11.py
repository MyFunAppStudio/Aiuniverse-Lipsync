# -*- coding: utf-8 -*-
import os, shutil, subprocess, sys
B = "/root/aiuniverse"
fehler = []


def tausche(datei, paare, merkmal, pruefen=True):
    p = os.path.join(B, datei)
    t = open(p, encoding="utf-8").read()
    if merkmal in t:
        print("INFO  %s war schon angepasst" % datei)
        return
    for alt, neu in paare:
        if alt not in t:
            print("ACHT  %s: Stelle nicht gefunden -> %r" % (datei, alt[:46]))
            fehler.append(datei)
            return
    shutil.copy2(p, p + ".bak_s11")
    for alt, neu in paare:
        t = t.replace(alt, neu, 1)
    open(p, "w", encoding="utf-8").write(t)
    if pruefen:
        r = subprocess.run([sys.executable, "-m", "py_compile", p], capture_output=True, text=True)
        if r.returncode:
            shutil.copy2(p + ".bak_s11", p)
            print("ACHT  %s zurueckgesetzt: %s" % (datei, r.stderr[-150:]))
            fehler.append(datei)
            return
    print("OK    %s" % datei)


# ---------- 1. figuren.py: Pruefen beim Hochladen ----------
ANHANG = '''

# ---------- Pruefung beim Hochladen (Patch S11) ----------
def hat_alpha(pfad):
    """Hat das Bild einen Transparenzkanal?"""
    r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0",
                        "-show_entries", "stream=pix_fmt", "-of", "default=nw=1:nk=1",
                        str(pfad)], capture_output=True, text=True)
    art = (r.stdout or "").strip().lower()
    return "a" in art.replace("yuv", "").replace("gray", "")


def _wirklich_frei(pfad):
    """Sind an den Raendern wirklich durchsichtige Stellen?"""
    if not hat_alpha(pfad):
        return False
    r = subprocess.run(["ffmpeg", "-v", "error", "-i", str(pfad),
                        "-vf", "alphaextract,scale=1:1", "-frames:v", "1",
                        "-f", "rawvideo", "-pix_fmt", "gray", "-"], capture_output=True)
    d = r.stdout or b""
    return bool(d) and d[0] < 250


def annehmen(kanal, datei, posenname=""):
    """Nimmt eine Pose nur an, wenn sie freigestellt ist oder freigestellt werden kann."""
    pfad = datei_pfad(kanal, datei)
    if not os.path.exists(pfad):
        return {"ok": False, "fehler": "Datei nicht da"}
    if _wirklich_frei(pfad):
        zuschneiden(pfad)
        return {"ok": True, "datei": datei, "wie": "war schon freigestellt"}
    e = freistellen(kanal, datei)
    if e.get("ok"):
        try:
            os.remove(pfad)
        except Exception:
            pass
        return {"ok": True, "datei": e["datei"], "wie": "Hintergrund entfernt"}
    try:
        os.remove(pfad)
    except Exception:
        pass
    return {"ok": False, "fehler": e.get("fehler") or "Freistellen nicht moeglich"}
'''

p_fig = os.path.join(B, "figuren.py")
t_fig = open(p_fig, encoding="utf-8").read()
if "def annehmen(" in t_fig:
    print("INFO  figuren.py war schon angepasst")
else:
    shutil.copy2(p_fig, p_fig + ".bak_s11")
    t_fig = t_fig.replace(
        '''            posen.append({"name": p["name"], "datei": p["datei"],
                          "da": os.path.exists(pfad)})''',
        '''            posen.append({"name": p["name"], "datei": p["datei"],
                          "da": os.path.exists(pfad),
                          "frei": os.path.exists(pfad) and _wirklich_frei(pfad)})''', 1)
    open(p_fig, "w", encoding="utf-8").write(t_fig + ANHANG)
    r = subprocess.run([sys.executable, "-m", "py_compile", p_fig], capture_output=True, text=True)
    if r.returncode:
        shutil.copy2(p_fig + ".bak_s11", p_fig)
        print("ACHT  figuren.py zurueckgesetzt:", r.stderr[-150:])
        fehler.append("figuren.py")
    else:
        print("OK    figuren.py: prueft Posen beim Hochladen")

# ---------- 2. dashboard2.py: Pose erst nach der Pruefung eintragen ----------
tausche("dashboard2.py", [
    ("            figuren.pose_dazu(k, fig, zname, (q.get(\"pose\") or [\"\"])[0])\n"
     "            return self.sende({\"ok\": True, \"datei\": zname})",
     "            e = figuren.annehmen(k, zname, (q.get(\"pose\") or [\"\"])[0])\n"
     "            if not e.get(\"ok\"):\n"
     "                return self.sende(e, code=400)\n"
     "            figuren.pose_dazu(k, fig, e[\"datei\"], (q.get(\"pose\") or [\"\"])[0])\n"
     "            return self.sende(e)"),
], "figuren.annehmen")

# ---------- 3. Oberflaeche: Hinweis an jeder Pose ----------
tausche("dashboard2.html", [
    ("""       +'<div class="tx"><div class="ti">'+h(p.name)+'</div><div class="me">'+h(p.datei)+'</div></div>'""",
     """       +'<div class="tx"><div class="ti">'+h(p.name)+'</div><div class="me'+(p.frei?"":" warn")+'">'
       +(p.frei?"freigestellt":"mit Hintergrund — wirkt im Video aufgeklebt")+'</div></div>'"""),
    ("</style>", ".me.warn{color:#FF6A1A}\n</style>"),
], ".me.warn", pruefen=False)

print()
print("NICHT FERTIG:", ", ".join(sorted(set(fehler))) if fehler else "alles durch")
print("TEIL 11 FERTIG")
