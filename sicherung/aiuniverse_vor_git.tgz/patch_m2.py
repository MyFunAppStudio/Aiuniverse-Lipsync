import os, shutil, sys
B = "/root/aiuniverse"
p = os.path.join(B, "dashboard2.html")
t = open(p, encoding="utf-8").read()
if "function ladeModelle" in t:
    print("INFO  Oberflaeche: Modellteil war schon drin")
    raise SystemExit(0)
shutil.copy2(p, p + ".bak_m1")

NEU = r"""
/* ---------- Modelle (Patch M1) ---------- */
var SLOTNAME={text:"Text",bilder:"Bild",stimme:"Stimme",video:"Animation",musik:"Musik",sound:"Geraeusche",avatar:"Avatar"};
var EINHEIT={text:"je Video",bilder:"je Bild",stimme:"je Sekunde",video:"je Sekunde",musik:"je Stueck",sound:"je Stueck",avatar:"je Sekunde"};
var BEISPIEL={text:"0.02",bilder:"0.04",stimme:"0.008",video:"0.09",musik:"0.01",sound:"0.01",avatar:"0.10"};

function ladeModelle(){return api("/api/modelle?k="+S.kanal).then(function(m){S.modelle=m;zeichne()})}

function tTechnik(){
  var m=S.modelle;
  if(!m){ladeModelle();return '<div class="karte p"><div class="leer">lade…</div></div>'}
  var p=S.preis||{};
  var o='<div class="karte p"><h2 class="kt">Was ein Video kostet</h2>'
   +'<div class="r" style="padding-top:0"><div class="lb">Text</div><div class="zahl">'+(p.text||0).toFixed(2)+' €</div></div>'
   +'<div class="r"><div class="lb">'+(p.bilder||0)+' Bilder</div><div class="zahl">'+(((p.bilder||0)*(p.je_bild||0))||0).toFixed(2)+' €</div></div>'
   +'<div class="r"><div class="lb">Stimme</div><div class="zahl">'+(p.stimme||0).toFixed(2)+' €</div></div>'
   +'<div class="r"><div class="lb"><b>Zusammen</b></div><div class="zahl"><b>'+(p.gesamt||0).toFixed(2)+' €</b></div></div></div>';

  o+='<div class="karte p"><h2 class="kt">Guthaben</h2>'
   +'<div class="r" style="padding-top:0"><div><div class="lb">fal.ai</div><div class="hint">Bilder und Stimme</div></div>'
   +'<div style="display:flex;align-items:center;gap:8px"><span class="zahl" style="font-size:15px;font-weight:700">'
   +(S.guthaben?(S.guthaben.ok?Number(S.guthaben.betrag).toFixed(2)+" "+S.guthaben.waehrung:h(S.guthaben.text)):"—")
   +'</span><button class="knopf" onclick="holGuthaben()">abrufen</button></div></div></div>';

  (m.slots||[]).forEach(function(s){
    var liste=(m.apis||{})[s]||[];
    o+='<div class="karte p"><h2 class="kt">'+h(SLOTNAME[s]||s)+'</h2><div class="liste">';
    if(!liste.length)o+='<div class="leer">nichts eingetragen</div>';
    liste.forEach(function(e,i){
      o+='<div class="e"><button class="ik" style="'+(e.aktiv?"background:#FF6A1A;border-color:#FF6A1A;color:#140B04":"")+'" '
        +'onclick="modellAktiv(\''+s+'\','+i+')" title="aktiv schalten">'+(e.aktiv?"●":"○")+'</button>'
        +'<div class="tx" onclick="modellBearbeiten(\''+s+'\','+i+')"><div class="ti">'+h(e.name||"ohne Namen")+'</div>'
        +'<div class="me">'+h(e.url||"keine Adresse")+(e.preis!==""&&e.preis!=null?" · "+h(e.preis)+" € "+(EINHEIT[s]||""):"")
        +(e.key?" · Schlüssel ✓":" · kein Schlüssel")+'</div></div>'
        +'<button class="ik rot" onclick="modellWeg(\''+s+'\','+i+',\''+h(e.name).replace(/'/g,"")+'\')">✕</button></div>';
    });
    o+='</div><button class="knopf" style="width:100%;margin-top:9px" onclick="modellNeu(\''+s+'\')">+ Eigenes Modell</button></div>';
  });
  o+='<div class="karte p"><div class="hinw" style="padding:0">Der orange Punkt links ist das Modell, das benutzt wird. '
   +'Auf den Namen tippen zum Ändern. Schlüssel werden gespeichert, aber nie wieder angezeigt.</div></div>';
  return o;
}

function modellFormular(titel,s,i,e){
  e=e||{};
  el("dialog").innerHTML='<div class="dim"><div class="dlg"><h2>'+h(titel)+'</h2>'
   +'<p>Slot: '+h(SLOTNAME[s]||s)+'</p>'
   +'<input type="text" id="mname" class="breit" placeholder="Name, z.B. Flux Pro" value="'+h(e.name||"")+'" style="margin-bottom:8px">'
   +'<input type="text" id="murl" class="breit" placeholder="Adresse, z.B. fal-ai/flux-pro/v1.1" value="'+h(e.url||"")+'" style="margin-bottom:8px">'
   +'<input type="text" id="mpreis" class="breit" placeholder="Preis '+(EINHEIT[s]||"je Einheit")+' in Euro, z.B. '+(BEISPIEL[s]||"0.04")+'" value="'+h(e.preis==null?"":e.preis)+'" style="margin-bottom:8px">'
   +'<input type="text" id="mkey" class="breit" placeholder="'+(e.key?"Schlüssel ersetzen (leer = behalten)":"Schlüssel")+'" style="margin-bottom:14px">'
   +'<div class="zw"><button class="knopf" onclick="zu()">Abbrechen</button>'
   +'<button class="knopf or" onclick="modellSpeichern(\''+s+'\','+i+')">Speichern</button></div></div></div>';
}
function modellNeu(s){modellFormular("Eigenes Modell",s,-1,{})}
function modellBearbeiten(s,i){modellFormular("Modell ändern",s,i,((S.modelle.apis||{})[s]||[])[i])}
function modellSpeichern(s,i){
  var d={slot:s,aktion:(i<0?"neu":"speichern"),i:i,
    name:el("mname").value,url:el("murl").value,preis:el("mpreis").value,key:el("mkey").value};
  api("/api/modelle?k="+S.kanal,d).then(function(r){zu();
    if(!r.ok)return melde(r.fehler||"ging nicht");
    ladeModelle().then(function(){api("/api/preis?k="+S.kanal).then(function(x){S.preis=x;zeichne()})});
  });
}
function modellAktiv(s,i){
  api("/api/modelle?k="+S.kanal,{slot:s,aktion:"aktiv",i:i}).then(function(){
    ladeModelle().then(function(){api("/api/preis?k="+S.kanal).then(function(x){S.preis=x;zeichne()})})});
}
function modellWeg(s,i,n){
  frage("Modell löschen?","<b>"+h(n)+"</b><br><br>Der Eintrag und sein Schlüssel werden gelöscht.","Löschen",
    function(){api("/api/modelle?k="+S.kanal,{slot:s,aktion:"weg",i:i}).then(function(){ladeModelle()})},true);
}

"""
for stueck, was in [("/* ---------- Start ---------- */", "Einhaengepunkt Start"),
                    ("videos:[],preis:{},vorlagen:{}", "Zustand S"),
                    ('function waehle(k){S.kanal=k;S.tab="start";laden()}', "Kanalwechsel")]:
    if stueck not in t:
        print("ACHT  " + was + " nicht gefunden - nichts geaendert")
        raise SystemExit(1)
t = t.replace("/* ---------- Start ---------- */", NEU + "/* ---------- Start ---------- */", 1)
t = t.replace('videos:[],preis:{},vorlagen:{}', 'videos:[],preis:{},modelle:null,vorlagen:{}', 1)
t = t.replace('function waehle(k){S.kanal=k;S.tab="start";laden()}',
              'function waehle(k){S.kanal=k;S.tab="start";S.modelle=null;laden()}', 1)
open(p, "w", encoding="utf-8").write(t)
print("OK    Oberflaeche: Modellverwaltung eingebaut")
print("TEIL 2 FERTIG")
