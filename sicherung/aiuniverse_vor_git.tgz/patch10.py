# ============================================
# Patch 10: Bildstil + Stimm-Regler im Dashboard
# (sauber, mit JS-Pruefung)
# ============================================
from pathlib import Path

ZEILEN = [
    """  h+='<div class="karte"><h2>Bildstil</h2><div class="inh">'""",
    """    +'<div class="mini" style="margin-bottom:8px">Wird an JEDE Bildbeschreibung angehaengt. Bestimmt den Look.</div>'""",
    """    +'<textarea style="min-height:90px" onchange="setz(\\''+kid+'\\',\\'bildstil\\',this.value)">'+esc(k.bildstil||'')+'</textarea>'""",
    """    +'<div class="mini">Bunt: bright colorful flat illustration, finance symbols, happy people. Duester: cinematic dark photography, moody, film grain.</div>'""",
    """    +'</div></div>';""",
    """  h+='<div class="karte"><h2>Stimme</h2><div class="inh">'""",
    """    +'<div class="feld"><div class="lbl">Stimm-ID (ElevenLabs)</div>'""",
    """    +'<input type="text" value="'+esc(k.stimme_id||'')+'" placeholder="leer = Standardstimme" onchange="setz(\\''+kid+'\\',\\'stimme_id\\',this.value)"></div>'""",
    """    +'<div class="feld"><div class="lbl">Energie und Ausdruck</div>'""",
    """    +'<input type="range" min="0" max="100" value="'+Math.round((k.stimme_energie||0.6)*100)+'" onchange="setz(\\''+kid+'\\',\\'stimme_energie\\',parseInt(this.value)/100)">'""",
    """    +'<div class="mini">'+Math.round((k.stimme_energie||0.6)*100)+' Prozent - hoch ist lebendig und schwungvoll, niedrig ist ruhig.</div></div>'""",
    """    +'<div class="mini">Stimmen anhoeren: elevenlabs.io Voice Library</div>'""",
    """    +'</div></div>';""",
    """""",
]

MARKE = """  h+='<div class="karte"><h2>Telegram</h2><div class="inh">'"""


def einstellungen_ergaenzen():
    """Stellt sicher dass bildstil/stimme in den Standardwerten stehen."""
    p = Path("einstellungen.py")
    s = p.read_text(encoding="utf-8")
    if '"bildstil"' in s:
        print("einstellungen.py: Felder schon vorhanden")
        return
    stil_a = ("cinematic dark photography, moody atmosphere, deep shadows, "
              "film grain, muted colors, dramatic lighting")
    stil_b = ("bright colorful modern flat illustration, bold shapes, "
              "vibrant orange and teal palette, clean vector style, "
              "finance symbols (coins, rising charts, wallet, piggy bank), "
              "happy relatable people, optimistic energetic mood")
    s = s.replace('        "mit_avatar": True,\n        "prompt": _prompt_a(),',
                  '        "mit_avatar": True,\n'
                  f'        "bildstil": "{stil_a}",\n'
                  '        "stimme_id": "",\n'
                  '        "stimme_energie": 0.55,\n'
                  '        "prompt": _prompt_a(),')
    s = s.replace('        "mit_avatar": False,\n        "prompt": _prompt_b(),',
                  '        "mit_avatar": False,\n'
                  f'        "bildstil": "{stil_b}",\n'
                  '        "stimme_id": "",\n'
                  '        "stimme_energie": 0.85,\n'
                  '        "prompt": _prompt_b(),')
    p.write_text(s, encoding="utf-8")
    print("einstellungen.py: Bildstil + Stimme ergaenzt")


def main():
    einstellungen_ergaenzen()
    p = Path("dashboard.py")
    s = p.read_text(encoding="utf-8")

    if "h2>Bildstil</h2>" in s:
        print("Schon eingebaut - nichts zu tun")
        return

    if MARKE not in s:
        print("FEHLER: Telegram-Block nicht gefunden, Abbruch")
        return

    neu = "\n".join(ZEILEN) + MARKE
    s = s.replace(MARKE, neu, 1)

    # Sicherung anlegen
    Path("dashboard_vorher.py").write_text(p.read_text(encoding="utf-8"), encoding="utf-8")
    p.write_text(s, encoding="utf-8")
    print("dashboard.py: Bildstil + Stimme eingebaut (Sicherung: dashboard_vorher.py)")


if __name__ == "__main__":
    main()
