import sys, json, time, os, glob
sys.path.insert(0, '/root/aiuniverse')
import einstellungen, animation, schluessel

KANAL = sys.argv[1] if len(sys.argv) > 1 else 'a'
d = einstellungen.laden().get(KANAL) or {}
e = animation._slot(d)
if not e:
    print('Kein Animationsmodell eingetragen'); raise SystemExit(1)
print('Kanal   :', KANAL, '-', d.get('name'))
print('Modell  :', e.get('name'))
print('Adresse :', e.get('url'))
key = schluessel.fuer(d, e)
print('Schlssl :', 'vorhanden' if key else 'FEHLT')
basis = animation._basis_url(e.get('url'))
print('Ruft an :', basis)

import szenen
ordner = szenen.ordner(d)
kand = sorted(glob.glob(os.path.join(ordner, '*.png')) + glob.glob(os.path.join(ordner, '*.jpg')))
if not kand:
    print('Kein Szenenbild gefunden in', ordner); raise SystemExit(1)
bild = kand[0]
print('Bild    :', os.path.basename(bild), '%.2f MB' % (os.path.getsize(bild)/1048576.0))
print()

koerper = {'image_url': animation._daten_uri(bild),
           'prompt': 'sanfte, ruhige Kamerabewegung',
           'duration': '5',
           'aspect_ratio': d.get('format') or '9:16'}
t0 = time.time()
try:
    start = animation._hole(basis, key, koerper, zeit=120)
except Exception as f:
    print('POST FEHLER:', repr(f)[:300]); raise SystemExit(1)
print('POST nach %.0f s. Antwort:' % (time.time()-t0))
print(json.dumps({k: v for k, v in start.items() if 'image' not in k}, indent=1)[:900])
print()

su = start.get('status_url')
if not su:
    print('Keine status_url'); raise SystemExit(0)
st = {}
for i in range(10):
    time.sleep(10)
    try:
        st = animation._hole(su, key, zeit=40)
    except Exception as f:
        print('%2d. %4.0f s STATUS-FEHLER %s' % (i+1, time.time()-t0, repr(f)[:120])); continue
    print('%2d. %4.0f s  %s' % (i+1, time.time()-t0, json.dumps(st)[:200]))
    if (st.get('status') or '').upper() in ('COMPLETED','FAILED','ERROR'):
        break
print()
print('=== Ergebnis-Adressen einzeln ===')
rid = start.get('request_id') or st.get('request_id') or ''
liste = []
for u, woher in [(st.get('response_url'), 'Status->response_url'),
                 (start.get('response_url'), 'Start->response_url'),
                 (su[:-7] if su.endswith('/status') else None, 'Status ohne /status'),
                 (basis.rstrip('/') + '/requests/' + rid, 'Basis+requests')]:
    if not u or u in [x[0] for x in liste]:
        continue
    liste.append((u, woher))
for u, woher in liste:
    print()
    print('%s:' % woher)
    print('  %s' % u)
    try:
        a = animation._hole(u, key, zeit=60)
        print('  -> OK:', json.dumps(a)[:220])
    except Exception as f:
        print('  ->', repr(f)[:140])
