# Paket 1: Untertitel-Einstellungen, Einblendungen, Geraeusche
from pathlib import Path

VIDEO_CODE = r'''# ============================================
# Video bauen: Bilder + Ton -> fertiges Video
# Mit abwechselnden Effekten, schnellen Schnitten
# und eingebrannten Untertiteln
# ============================================
import subprocess
import random
import re
from pathlib import Path
import config

FPS = 30
BREITE, HOEHE = 1280, 720
SCHRIFT = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"


def ton_laenge(ton_pfad):
    """Laenge der Tonspur in Sekunden."""
    ergebnis = subprocess.run([
        "ffprobe", "-v", "error", "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1", str(ton_pfad)
    ], capture_output=True, text=True)
    try:
        return float(ergebnis.stdout.strip())
    except ValueError:
        return 30.0


def _effekt(nummer, dauer):
    """Ken-Burns: 6 verschiedene Bewegungen, wechseln sich ab."""
    f = max(2, int(dauer * FPS))
    gross = f"scale=2400:1350:force_original_aspect_ratio=increase,crop=2400:1350"
    mitte_x = "iw/2-(iw/zoom/2)"
    mitte_y = "ih/2-(ih/zoom/2)"

    varianten = [
        # 0: langsam reinzoomen
        f"{gross},zoompan=z='min(1+0.0010*on,1.16)':d={f}:x='{mitte_x}':y='{mitte_y}'"
        f":s={BREITE}x{HOEHE}:fps={FPS}",
        # 1: rauszoomen
        f"{gross},zoompan=z='max(1.16-0.0010*on,1.0)':d={f}:x='{mitte_x}':y='{mitte_y}'"
        f":s={BREITE}x{HOEHE}:fps={FPS}",
        # 2: Schwenk nach rechts
        f"{gross},zoompan=z='1.12':d={f}:x='(iw-iw/zoom)*on/{f}':y='{mitte_y}'"
        f":s={BREITE}x{HOEHE}:fps={FPS}",
        # 3: Schwenk nach links
        f"{gross},zoompan=z='1.12':d={f}:x='(iw-iw/zoom)*(1-on/{f})':y='{mitte_y}'"
        f":s={BREITE}x{HOEHE}:fps={FPS}",
        # 4: Schwenk nach unten + leichter Zoom
        f"{gross},zoompan=z='min(1.08+0.0006*on,1.18)':d={f}:x='{mitte_x}'"
        f":y='(ih-ih/zoom)*on/{f}':s={BREITE}x{HOEHE}:fps={FPS}",
        # 5: diagonal
        f"{gross},zoompan=z='min(1.08+0.0006*on,1.18)':d={f}"
        f":x='(iw-iw/zoom)*on/{f}':y='(ih-ih/zoom)*on/{f}'"
        f":s={BREITE}x{HOEHE}:fps={FPS}",
    ]
    return varianten[nummer % len(varianten)]


def baue_untertitel_ass(text, gesamt_sek, ziel, stil="modern", kanal=None):
    """ASS-Untertitel im TikTok-Stil: mitlaufende Wort-Hervorhebung."""
    import re
    from pathlib import Path
    text = re.sub(r"\s+", " ", (text or "").strip())
    if not text:
        return None

    woerter = text.split(" ")
    if not woerter:
        return None

    # Zeilen mit 4-6 Woertern
    zeilen, aktuell = [], []
    for w in woerter:
        aktuell.append(w)
        laenge = sum(len(x) + 1 for x in aktuell)
        if len(aktuell) >= 5 or laenge > 32:
            zeilen.append(aktuell)
            aktuell = []
    if aktuell:
        zeilen.append(aktuell)

    zeichen_gesamt = sum(sum(len(w) + 1 for w in z) for z in zeilen) or 1

    stile = {
        "modern": dict(schrift="DejaVu Sans", groesse=46,
                       gesprochen="&H0000E5FF&", offen="&H00FFFFFF&",
                       rand="&H00000000&", dicke=4, position=60),
        "gross":  dict(schrift="DejaVu Sans", groesse=58,
                       gesprochen="&H0000FF00&", offen="&H00FFFFFF&",
                       rand="&H00000000&", dicke=5, position=80),
        "dezent": dict(schrift="DejaVu Sans", groesse=34,
                       gesprochen="&H00FFFFFF&", offen="&H00BBBBBB&",
                       rand="&H00000000&", dicke=2, position=40),
    }
    s = dict(stile.get(stil, stile["modern"]))
    if kanal:
        if kanal.get("untertitel_schrift"):
            s["schrift"] = kanal["untertitel_schrift"]
        if kanal.get("untertitel_groesse"):
            s["groesse"] = int(kanal["untertitel_groesse"])
        if kanal.get("untertitel_position"):
            s["position"] = int(kanal["untertitel_position"])

    kopf = f"""[Script Info]
ScriptType: v4.00+
PlayResX: 1280
PlayResY: 720
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Std,{s['schrift']},{s['groesse']},{s['gesprochen']},{s['offen']},{s['rand']},&H64000000&,-1,0,0,0,100,100,0,0,1,{s['dicke']},2,2,60,60,{s['position']},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""

    def zeit(sek):
        sek = max(0, sek)
        st = int(sek // 3600)
        mi = int((sek % 3600) // 60)
        se = sek % 60
        return f"{st}:{mi:02d}:{se:05.2f}"

    zeilen_aus, uhr = [], 0.0
    for zl in zeilen:
        z_zeichen = sum(len(w) + 1 for w in zl)
        dauer = gesamt_sek * z_zeichen / zeichen_gesamt
        dauer = max(0.7, dauer)
        ende = min(uhr + dauer, gesamt_sek)
        # Karaoke: jedes Wort bekommt seine Dauer in Hundertstel
        teile = []
        for w in zl:
            w_anteil = (len(w) + 1) / z_zeichen
            k = max(8, int(round(dauer * w_anteil * 100)))
            teile.append("{\\k%d}%s " % (k, w))
        zeilen_aus.append(
            f"Dialogue: 0,{zeit(uhr)},{zeit(ende)},Std,,0,0,0,,{''.join(teile).strip()}")
        uhr = ende
        if uhr >= gesamt_sek:
            break

    ziel = Path(ziel)
    ziel.write_text(kopf + "\n".join(zeilen_aus) + "\n", encoding="utf-8")
    return ziel


CTA_TEXTE = {
    "Deutsch":      ("FOLGEN fuer mehr", "LIKE wenn es gefaellt", "ABONNIEREN"),
    "Englisch":     ("FOLLOW for more", "LIKE if you enjoyed", "SUBSCRIBE"),
    "Spanisch":     ("SIGUEME para mas", "DALE LIKE", "SUSCRIBETE"),
    "Portugiesisch":("SIGA para mais", "DEIXE seu LIKE", "INSCREVA-SE"),
    "Franzoesisch": ("ABONNE-TOI", "LAISSE un LIKE", "S'ABONNER"),
    "Italienisch":  ("SEGUIMI per altro", "METTI LIKE", "ISCRIVITI"),
    "Hindi":        ("FOLLOW for more", "LIKE if you enjoyed", "SUBSCRIBE"),
    "Niederlaendisch": ("VOLG voor meer", "LIKE als het bevalt", "ABONNEER"),
}


def _cta_filter(kanal, gesamt):
    """Einblendungen fuer Follow, Like und Abonnieren - in der Kanalsprache."""
    sprachen = kanal.get("sprachen") or ["Deutsch"]
    folgen, liken, abo = CTA_TEXTE.get(sprachen[0], CTA_TEXTE["Deutsch"])
    # eigene Texte haben Vorrang
    folgen = (kanal.get("cta_text_folgen") or folgen).strip()
    liken = (kanal.get("cta_text_like") or liken).strip()
    abo = (kanal.get("cta_text_abo") or abo).strip()

    teile = []
    schrift = SCHRIFT.replace(":", r"\\:")

    def kasten(text, von, dauer):
        text = text.replace("'", "").replace(":", "").replace("\\", "")
        bis = von + dauer
        return (f"drawtext=fontfile='{schrift}':text='{text}'"
                f":fontcolor=white:fontsize=40:borderw=4:bordercolor=black@0.9"
                f":box=1:boxcolor=black@0.45:boxborderw=18"
                f":x=(w-text_w)/2:y=80"
                f":enable='between(t,{von:.1f},{bis:.1f})'")

    if kanal.get("anim_follow", True) and gesamt > 12:
        teile.append(kasten(folgen, gesamt * 0.45, 4))
    if kanal.get("anim_like", True):
        teile.append(kasten(liken, max(0, gesamt - 6), 3))

    wann = kanal.get("abo_position", "ende")
    if kanal.get("anim_abo", True):
        if wann == "anfang" and gesamt > 10:
            teile.append(kasten(abo, 4, 3))
        elif wann == "mitte" and gesamt > 14:
            teile.append(kasten(abo, gesamt * 0.6, 3))
        elif gesamt > 12:
            teile.append(kasten(abo, max(0, gesamt - 3), 3))
    return teile


def baue_thumbnail(kanal, bild, titel, ziel):
    """Erzeugt ein Thumbnail: Bild + grosser Titeltext."""
    ziel = Path(ziel)
    if not bild or not Path(bild).exists():
        return None

    text = re.sub(r"\s+", " ", (titel or "").strip())
    text = text.replace("'", "").replace(":", " -").replace("\\", "")
    if len(text) > 60:
        text = text[:57] + "..."

    # in zwei Zeilen brechen
    woerter = text.split(" ")
    z1, z2 = [], []
    for w in woerter:
        if len(" ".join(z1 + [w])) <= 22 or not z1:
            z1.append(w)
        else:
            z2.append(w)
    zeile1, zeile2 = " ".join(z1), " ".join(z2)

    schrift = SCHRIFT.replace(":", r"\\:")
    groesse = int(kanal.get("thumb_groesse", 78))
    farbe = kanal.get("thumb_farbe", "#FFDD00")

    filter_teile = [
        f"scale=1280:720:force_original_aspect_ratio=increase,crop=1280:720",
        "eq=contrast=1.15:saturation=1.25:brightness=0.02",
        "drawbox=x=0:y=h-300:w=iw:h=300:color=black@0.55:t=fill",
    ]
    y1 = "h-250" if zeile2 else "h-190"
    filter_teile.append(
        f"drawtext=fontfile='{schrift}':text='{zeile1}':fontcolor={farbe}"
        f":fontsize={groesse}:borderw=6:bordercolor=black"
        f":x=(w-text_w)/2:y={y1}")
    if zeile2:
        filter_teile.append(
            f"drawtext=fontfile='{schrift}':text='{zeile2}':fontcolor=white"
            f":fontsize={groesse}:borderw=6:bordercolor=black"
            f":x=(w-text_w)/2:y=h-150")

    befehl = ["ffmpeg", "-y", "-loglevel", "error", "-i", str(bild),
              "-vf", ",".join(filter_teile), "-frames:v", "1", str(ziel)]
    e = subprocess.run(befehl, capture_output=True, text=True)
    if e.returncode != 0:
        print("[Thumb] Fehler:", e.stderr[-200:])
        return None
    print(f"[Thumb] erstellt: {ziel.name}")
    return ziel


def baue_video(kanal, bilder, ton_pfad, ziel_pfad, skript=None, szenen=None):
    """Fuegt Bilder + Ton + Effekte + Untertitel zusammen."""
    bilder = [Path(b) for b in bilder]
    ton_pfad = Path(ton_pfad)
    ziel_pfad = Path(ziel_pfad)
    ziel_pfad.parent.mkdir(parents=True, exist_ok=True)

    if not bilder:
        print("[Video] Keine Bilder vorhanden")
        return None

    gesamt = ton_laenge(ton_pfad)
    schnitte = max(1, int(kanal.get("schnitte_pro_bild", 2)))
    zoom_an = kanal.get("zoom_effekte", True)

    # EIN Effekt pro Bild, laeuft ruhig ueber die ganze Standzeit durch.
    # Schnellere Schnitte = mehr Bilder pro Minute einstellen.
    # Standzeit je Bild: mit Szenen nach Textlaenge gewichtet, damit das Bild
    # genau so lange steht wie der zugehoerige Text gesprochen wird.
    if szenen and len(szenen) == len(bilder):
        zeichen = [max(1, len((x.get("text") or ""))) for x in szenen]
        summe = sum(zeichen)
        laengen = [max(1.2, gesamt * z / summe) for z in zeichen]
        print(f"[Video] {len(bilder)} Szenen - Bilddauer passt zum Text")
    else:
        laengen = [max(1.5, gesamt / len(bilder))] * len(bilder)
        print(f"[Video] {len(bilder)} Bilder gleichmaessig verteilt")

    abschnitte = [(bild, i) for i, bild in enumerate(bilder)]

    befehl = ["ffmpeg", "-y", "-loglevel", "error"]
    for nr, (bild, _) in enumerate(abschnitte):
        if zoom_an:
            # nur EIN Frame - zoompan erzeugt daraus die ganze Bewegung
            befehl += ["-i", str(bild)]
        else:
            befehl += ["-loop", "1", "-t", f"{laengen[nr]:.3f}", "-i", str(bild)]
    befehl += ["-i", str(ton_pfad)]

    teile = []
    for n, (_, effekt_nr) in enumerate(abschnitte):
        if zoom_an:
            filt = (f"[{n}:v]{_effekt(effekt_nr, laengen[n])},"
                    f"trim=duration={laengen[n]:.3f},setpts=PTS-STARTPTS,"
                    f"setsar=1,format=yuv420p[v{n}]")
        else:
            filt = (f"[{n}:v]scale={BREITE}:{HOEHE}:force_original_aspect_ratio=increase,"
                    f"crop={BREITE}:{HOEHE},setsar=1,fps={FPS},format=yuv420p[v{n}]")
        teile.append(filt)

    kette = "".join(f"[v{n}]" for n in range(len(abschnitte)))
    teile.append(f"{kette}concat=n={len(abschnitte)}:v=1:a=0[roh]")

    # Einblendungen (Follow / Like / Abo)
    cta = _cta_filter(kanal, gesamt)
    if cta:
        teile.append("[roh]" + ",".join(cta) + "[mitcta]")
        quelle = "mitcta"
        print(f"[Video] {len(cta)} Einblendungen (Follow/Like/Abo)")
    else:
        quelle = "roh"

    # Untertitel einbrennen
    letzte = quelle
    srt = None
    if skript:
        srt = baue_untertitel_ass(skript, gesamt,
                                  ziel_pfad.parent / "untertitel.ass",
                                  kanal.get("untertitel_stil", "modern"), kanal)
    if srt and srt.exists():
        pfad = str(srt).replace(":", r"\:").replace("'", r"\'")
        teile.append(f"[{quelle}]ass='{pfad}'[vout]")
        letzte = "vout"
        print(f"[Video] Untertitel im Stil '{kanal.get('untertitel_stil','modern')}'")
    else:
        teile.append(f"[{quelle}]copy[vout]")
        letzte = "vout"

    befehl += [
        "-filter_complex", ";".join(teile),
        "-map", f"[{letzte}]",
        "-map", f"{len(abschnitte)}:a",
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
        "-c:a", "aac", "-b:a", "128k",
        "-pix_fmt", "yuv420p", "-r", str(FPS),
        "-shortest", str(ziel_pfad)
    ]

    print("[Video] FFmpeg laeuft...")
    ergebnis = subprocess.run(befehl, capture_output=True, text=True)

    if ergebnis.returncode != 0:
        print("[Video] FEHLER:")
        print(ergebnis.stderr[-700:])
        return None

    mb = ziel_pfad.stat().st_size / (1024 * 1024)
    print(f"[Video] Fertig: {ziel_pfad.name} ({mb:.1f} MB)")
    return ziel_pfad


if __name__ == "__main__":
    print("=" * 45)
    print("VIDEO-BAU TEST")
    print("=" * 45)
    ordner = config.ORDNER_VIDEOS / "_test"
    bilder = sorted(ordner.glob("bild_*.jpg"))
    ton = ordner / "ton.mp3"
    if not bilder or not ton.exists():
        print("Erst 'python3 medien.py' laufen lassen!")
    else:
        e = baue_video(config.KANAL_A, bilder, ton, ordner / "test_video.mp4",
                       skript="Das ist ein Test der Untertitel. "
                              "Sie sollten gut lesbar sein und mitlaufen.")
        print("OK:" if e else "Fehlgeschlagen", e or "")
'''

MUSIK_CODE = r'''# ============================================
# Musik + Sounddesign
# Erzeugt oder waehlt Hintergrundmusik und mischt
# sie professionell unter die Stimme (mit Ducking).
# ============================================
import json
import random
import subprocess
import urllib.request
from pathlib import Path
import config

try:
    import einstellungen
except Exception:
    einstellungen = None

FAL_MUSIK = "fal-ai/stable-audio"


def _laenge(pfad):
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                        "-of", "default=noprint_wrappers=1:nokey=1", str(pfad)],
                       capture_output=True, text=True)
    try:
        return float(r.stdout.strip())
    except ValueError:
        return 0.0


def eigene_musik(kanal):
    """Sucht eine Musikdatei im Ordner musik/<kanal>/ ."""
    ordner = config.BASIS / "musik" / kanal["id"]
    if not ordner.exists():
        return None
    treffer = [f for f in sorted(ordner.iterdir())
               if f.is_file() and f.suffix.lower() in (".mp3", ".wav", ".m4a", ".ogg")]
    return random.choice(treffer) if treffer else None


def erzeuge_musik(kanal, sekunden, ziel):
    """Erzeugt Musik per KI (fal.ai). Gibt None zurueck wenn nicht moeglich."""
    if einstellungen is None:
        return None
    api = einstellungen.aktive_api(kanal, "musik") or {}
    schluessel = api.get("key")
    if not schluessel:
        return None

    beschreibung = (kanal.get("musik_prompt") or "").strip()
    if not beschreibung:
        beschreibung = "calm cinematic background music, subtle, no vocals"

    url = api.get("url") or FAL_MUSIK
    voll = url if url.startswith("http") else "https://fal.run/" + url.strip("/")
    daten = json.dumps({
        "prompt": beschreibung,
        "seconds_total": int(min(120, max(10, sekunden + 5))),
    }).encode()
    anfrage = urllib.request.Request(voll, data=daten, headers={
        "Authorization": f"Key {schluessel}",
        "Content-Type": "application/json",
    })
    try:
        print(f"[Musik] erzeuge ({api.get('name','?')}): {beschreibung[:50]}...")
        with urllib.request.urlopen(anfrage, timeout=600) as antwort:
            e = json.loads(antwort.read().decode())
        adresse = (e.get("audio_file") or e.get("audio") or {}).get("url") or e.get("url")
        if not adresse:
            print("[Musik] keine Datei in der Antwort")
            return None
        ziel = Path(ziel)
        urllib.request.urlretrieve(adresse, ziel)
        print(f"[Musik] fertig ({_laenge(ziel):.1f}s)")
        return ziel
    except Exception as f:
        print(f"[Musik] nicht erzeugt: {str(f)[:140]}")
        return None


def hole_musik(kanal, sekunden, ordner):
    """Eigene Datei bevorzugt, sonst KI. None wenn Musik aus."""
    if not kanal.get("musik_an", True):
        return None
    eigen = eigene_musik(kanal)
    if eigen:
        print(f"[Musik] eigene Datei: {eigen.name}")
        return eigen
    return erzeuge_musik(kanal, sekunden, Path(ordner) / "musik.mp3")


def eigene_geraeusche(kanal):
    """Sucht eine Geraeusch-Datei im Ordner geraeusche/<kanal>/ ."""
    ordner = config.BASIS / "geraeusche" / kanal["id"]
    if not ordner.exists():
        return None
    zustand = {}
    z = ordner / "_aktiv.json"
    if z.exists():
        try:
            zustand = json.loads(z.read_text())
        except Exception:
            zustand = {}
    treffer = [f for f in sorted(ordner.iterdir())
               if f.is_file() and f.suffix.lower() in (".mp3", ".wav", ".m4a", ".ogg")
               and zustand.get(f.name, True)]
    return random.choice(treffer) if treffer else None


def hole_ambience(kanal):
    """Atmosphaere-Geraeusch, falls eingeschaltet."""
    if not kanal.get("geraeusche_an", False):
        return None
    g = eigene_geraeusche(kanal)
    if g:
        print(f"[Ton] Atmosphaere: {g.name}")
    return g


def mische(kanal, stimme, musik, ziel, dauer=None, ambience=None):
    """Mischt Stimme + Musik: Ducking, Fades, Normalisierung."""
    stimme, ziel = Path(stimme), Path(ziel)
    dauer = dauer or _laenge(stimme)
    pegel = float(kanal.get("musik_pegel", 0.22))
    ziel_lufs = float(kanal.get("lautheit", -14))

    if not musik or not Path(musik).exists() or pegel <= 0:
        # nur Stimme, aber sauber normalisiert
        befehl = ["ffmpeg", "-y", "-loglevel", "error", "-i", str(stimme),
                  "-af", f"loudnorm=I={ziel_lufs}:TP=-1.5:LRA=11,alimiter=limit=0.97",
                  "-t", f"{dauer:.3f}", "-c:a", "aac", "-b:a", "192k", str(ziel)]
        subprocess.run(befehl, check=True, capture_output=True)
        print("[Ton] nur Stimme, normalisiert")
        return ziel

    ausblenden = max(0.5, min(3.0, dauer * 0.12))
    kette = (
        f"[0:a]asplit=2[st][trig];"
        f"[1:a]aloop=loop=-1:size=2e9,atrim=duration={dauer:.3f},"
        f"volume={pegel},afade=t=in:st=0:d=1.5,"
        f"afade=t=out:st={max(0, dauer - ausblenden):.3f}:d={ausblenden:.3f}[mus];"
        f"[mus][trig]sidechaincompress=threshold=0.03:ratio=10:attack=5:release=350[duck];"
        f"[st][duck]amix=inputs=2:duration=first:normalize=0[roh];"
        f"[roh]loudnorm=I={ziel_lufs}:TP=-1.5:LRA=11,alimiter=limit=0.97[out]"
    )
    eingaben = ["-i", str(stimme), "-i", str(musik)]
    if ambience and Path(ambience).exists():
        amb_pegel = float(kanal.get("geraeusche_pegel", 0.12))
        eingaben += ["-i", str(ambience)]
        kette = kette.replace("[roh];",
            f"[stimmemusik];[2:a]aloop=loop=-1:size=2e9,"
            f"atrim=duration={dauer:.3f},volume={amb_pegel},"
            f"afade=t=in:st=0:d=2,afade=t=out:st={max(0,dauer-2):.3f}:d=2[amb];"
            f"[stimmemusik][amb]amix=inputs=2:duration=first:normalize=0[roh];")
        print(f"[Ton] + Atmosphaere ({int(amb_pegel*100)}%)")

    befehl = ["ffmpeg", "-y", "-loglevel", "error"] + eingaben + [
              "-filter_complex", kette, "-map", "[out]",
              "-t", f"{dauer:.3f}", "-c:a", "aac", "-b:a", "192k", str(ziel)]
    e = subprocess.run(befehl, capture_output=True, text=True)
    if e.returncode != 0:
        print("[Ton] Mischen fehlgeschlagen:", e.stderr[-300:])
        return stimme
    print(f"[Ton] Stimme + Musik gemischt (Musik {int(pegel*100)}%, Ducking an)")
    return ziel


if __name__ == "__main__":
    print("=" * 46)
    print("MUSIK-MODUL")
    print("=" * 46)
    for k in config.KANAELE:
        an = k.get("musik_an", True)
        print(f"{k['emoji']} {k['name']}: Musik {'AN' if an else 'AUS'}, "
              f"Pegel {int(float(k.get('musik_pegel',0.22))*100)}%")
        e = eigene_musik(k)
        wo = e.name if e else "keine in musik/" + k["id"] + "/"
        print(f"   eigene Dateien: {wo}")
    print("=" * 46)
'''


Path('video_bauen.py').write_text(VIDEO_CODE, encoding='utf-8')
Path('musik.py').write_text(MUSIK_CODE, encoding='utf-8')
Path('geraeusche/a').mkdir(parents=True, exist_ok=True)
Path('geraeusche/b').mkdir(parents=True, exist_ok=True)
print("1. video_bauen.py + musik.py erneuert")

# --- Einstellungen ---
p = Path('einstellungen.py'); s = p.read_text(encoding='utf-8')
if '"untertitel_groesse"' not in s:
    s = s.replace('        "untertitel_stil": "modern",',
                  '        "untertitel_stil": "modern",\n'
                  '        "untertitel_groesse": 46,\n'
                  '        "untertitel_schrift": "DejaVu Sans",\n'
                  '        "untertitel_position": 60,\n'
                  '        "geraeusche_an": False,\n'
                  '        "geraeusche_pegel": 0.12,\n'
                  '        "abo_position": "ende",\n'
                  '        "cta_text_folgen": "",\n'
                  '        "cta_text_like": "",\n'
                  '        "cta_text_abo": "",\n'
                  '        "thumb_groesse": 78,\n'
                  '        "thumb_farbe": "#FFDD00",')
    if 'SCHRIFTEN' not in s:
        s = s.replace('SPRACHEN_LISTE = ',
                      'SCHRIFTEN = ["DejaVu Sans", "DejaVu Sans Condensed", "Liberation Sans",\n'
                      '             "FreeSans", "DejaVu Serif", "Liberation Serif"]\n\n'
                      'SPRACHEN_LISTE = ', 1)
    p.write_text(s, encoding='utf-8')
    print("2. einstellungen.py: Untertitel + Geraeusche ergaenzt")
else:
    print("2. einstellungen.py: schon ok")

# --- erstelle_video.py: Ambience weitergeben ---
p = Path('erstelle_video.py'); s = p.read_text(encoding='utf-8')
if 'hole_ambience' not in s:
    s = s.replace('    ton = musik.mische(kanal, ton, stueck, ordner / "ton_fertig.m4a", dauer)',
                  '    amb = musik.hole_ambience(kanal)\n'
                  '    ton = musik.mische(kanal, ton, stueck, ordner / "ton_fertig.m4a", dauer, amb)')
    p.write_text(s, encoding='utf-8')
    print("3. erstelle_video.py: Geraeusche werden gemischt")
else:
    print("3. erstelle_video.py: schon ok")

# --- Dashboard ---
# --- Thumbnail nach dem Video erzeugen ---
p = Path('erstelle_video.py'); s = p.read_text(encoding='utf-8')
if 'baue_thumbnail' not in s:
    ziel = '    print("--- SCHRITT 5: Texte speichern ---")'
    neu = ('    if bilder:\n'
           '        video_bauen.baue_thumbnail(kanal, bilder[0],\n'
           '                                   paket.get("titel", ""),\n'
           '                                   ordner / "thumbnail.jpg")\n'
           '        print()\n\n'
           + ziel)
    if ziel in s:
        s = s.replace(ziel, neu, 1)
        p.write_text(s, encoding='utf-8')
        print("3b. erstelle_video.py: Thumbnail wird erzeugt")
    else:
        print("3b. WARNUNG: Einbaustelle fuer Thumbnail nicht gefunden")
else:
    print("3b. Thumbnail: schon ok")

p = Path('dashboard.py'); s = p.read_text(encoding='utf-8')
if 'untertitel_groesse' not in s:
    s = s.replace('''                "sprachen": einstellungen.SPRACHEN_LISTE,''',
'''                "sprachen": einstellungen.SPRACHEN_LISTE,
                "schriften": getattr(einstellungen, "SCHRIFTEN", ["DejaVu Sans"]),''')

    zeilen = s.split('\n')
    ziel = next((i for i, z in enumerate(zeilen) if 'h2>Stimme</h2>' in z), None)
    if ziel is not None:
        zeilen[ziel:ziel] = [
            """  h+='<div class="karte"><h2>Untertitel Aussehen</h2><div class="inh">'""",
            """    +'<div class="feld"><div class="lbl">Schriftgroesse</div>'""",
            """    +'<input type="number" min="20" max="90" value="'+(k.untertitel_groesse||46)+'" style="width:100px;text-align:center;font-weight:700" onchange="setz(\\''+kid+'\\',\\'untertitel_groesse\\',parseInt(this.value))">'""",
            """    +'<div class="mini">20 klein bis 90 sehr gross</div></div>'""",
            """    +'<div class="feld"><div class="lbl">Abstand von unten</div>'""",
            """    +'<input type="number" min="20" max="300" value="'+(k.untertitel_position||60)+'" style="width:100px;text-align:center;font-weight:700" onchange="setz(\\''+kid+'\\',\\'untertitel_position\\',parseInt(this.value))">'""",
            """    +'</div><div class="feld"><div class="lbl">Schriftart</div><div>';""",
            """  (D.schriften||['DejaVu Sans']).forEach(function(f){""",
            """    var an=(k.untertitel_schrift||'DejaVu Sans')===f;""",
            """    h+='<button class="chip '+(an?'an':'')+'" onclick="setz(\\''+kid+'\\',\\'untertitel_schrift\\',\\''+f+'\\')">'+f+'</button>';""",
            """  });""",
            """  h+='</div></div></div></div>';""",
            """""",
            """  h+='<div class="karte"><h2>Einblendungen</h2><div class="inh">'""",
            """    +'<div class="mini" style="margin-bottom:10px">Text passt sich der Kanalsprache an. Eigene Texte haben Vorrang.</div>'""",
            """    +'<div class="feld"><div class="lbl">Abonnieren erscheint</div><div>';""",
            """  [['anfang','Am Anfang'],['mitte','In der Mitte'],['ende','Am Ende']].forEach(function(o){""",
            """    var an=(k.abo_position||'ende')===o[0];""",
            """    h+='<button class="chip '+(an?'an':'')+'" onclick="setz(\\''+kid+'\\',\\'abo_position\\',\\''+o[0]+'\\')">'+o[1]+'</button>';""",
            """  });""",
            """  h+='</div><div class="mini">Rat: am Ende, wenn der Zuschauer ueberzeugt ist.</div></div>'""",
            """    +'<div class="feld"><div class="lbl">Eigener Text Folgen</div>'""",
            """    +'<input type="text" value="'+esc(k.cta_text_folgen||'')+'" placeholder="leer = automatisch" onchange="setz(\\''+kid+'\\',\\'cta_text_folgen\\',this.value)"></div>'""",
            """    +'<div class="feld"><div class="lbl">Eigener Text Like</div>'""",
            """    +'<input type="text" value="'+esc(k.cta_text_like||'')+'" placeholder="leer = automatisch" onchange="setz(\\''+kid+'\\',\\'cta_text_like\\',this.value)"></div>'""",
            """    +'<div class="feld"><div class="lbl">Eigener Text Abonnieren</div>'""",
            """    +'<input type="text" value="'+esc(k.cta_text_abo||'')+'" placeholder="leer = automatisch" onchange="setz(\\''+kid+'\\',\\'cta_text_abo\\',this.value)"></div>'""",
            """    +'</div></div>';""",
            """""",
            """  h+='<div class="karte"><h2>Geraeusche</h2><div class="inh">'""",
            """    +'<div class="zeile '+(k.geraeusche_an?'an':'')+'" onclick="setz(\\''+kid+'\\',\\'geraeusche_an\\','+(!k.geraeusche_an)+')">'""",
            """    +'<div class="sw '+(k.geraeusche_an?'an':'')+'"><i></i></div>'""",
            """    +'<div class="txt"><div class="t1">Atmosphaere im Hintergrund</div>'""",
            """    +'<div class="t2">Regen, Wind, Strassenlaerm - leise unter Musik und Stimme</div></div></div>';""",
            """  if(k.geraeusche_an){""",
            """    h+='<div class="feld" style="margin-top:12px"><div class="lbl">Lautstaerke</div>'""",
            """     +'<input type="number" min="0" max="40" value="'+Math.round((k.geraeusche_pegel||0.12)*100)+'" style="width:100px;text-align:center;font-weight:700" onchange="setz(\\''+kid+'\\',\\'geraeusche_pegel\\',parseInt(this.value)/100)">'""",
            """     +'<div class="mini">Prozent - 10 bis 15 ist meist richtig</div></div>'""",
            """     +'<div class="mini">Dateien in den Ordner geraeusche/'+kid+'/ legen (Regen, Wind, Ambience).</div>';""",
            """  }""",
            """  h+='</div></div>';""",
            """""",
        ]
        s = '\n'.join(zeilen)
        p.write_text(s, encoding='utf-8')
        print("4. Dashboard: Untertitel-Aussehen + Geraeusche")
    else:
        print("4. WARNUNG: Einbaustelle nicht gefunden")
else:
    print("4. Dashboard: schon ok")
print("FERTIG - Seite neu laden")
