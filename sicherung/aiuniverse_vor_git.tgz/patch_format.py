#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""patch_format.py  -  Hochformat 9:16 fuer AiUniverse. Mehrfach startbar."""
import ast, json, os, re, shutil, subprocess, sys

BASIS = "/root/aiuniverse"
BERICHT = []


def ok(m):
    BERICHT.append("OK    " + m)


def info(m):
    BERICHT.append("INFO  " + m)


def warn(m):
    BERICHT.append("ACHT  " + m)


def P(n):
    return os.path.join(BASIS, n)


def lese(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def schreibe(p, t):
    if not os.path.exists(p + ".bak_format"):
        shutil.copy2(p, p + ".bak_format")
    with open(p, "w", encoding="utf-8") as f:
        f.write(t)


def pruefe(p):
    r = subprocess.run([sys.executable, "-m", "py_compile", p],
                       capture_output=True, text=True)
    return r.returncode == 0, (r.stderr or "")[-400:]


def zurueck(p):
    if os.path.exists(p + ".bak_format"):
        shutil.copy2(p + ".bak_format", p)


def import_rein(t, zeile):
    if re.search(r"^\s*" + re.escape(zeile) + r"\s*$", t, re.M):
        return t
    zl = t.splitlines()
    letzte = None
    for i, z in enumerate(zl[:80]):
        if re.match(r"^(import |from )\S", z):
            letzte = i
    if letzte is None:
        # kein Import vorhanden: hinter Shebang / Kodierzeile / Modul-Doku
        stelle = 0
        try:
            baum = ast.parse(t)
            if (baum.body and isinstance(baum.body[0], ast.Expr)
                    and isinstance(baum.body[0].value, ast.Constant)
                    and isinstance(baum.body[0].value.value, str)):
                stelle = baum.body[0].end_lineno
        except SyntaxError:
            pass
        while stelle < len(zl) and (zl[stelle].startswith("#!") or "coding" in zl[stelle][:30]):
            stelle += 1
        zl.insert(stelle, zeile)
    else:
        zl.insert(letzte + 1, zeile)
    return "\n".join(zl)


def block_ende(t, start):
    """Index hinter der schliessenden Klammer ab t[start] == '{'."""
    tief = 0
    for i in range(start, len(t)):
        if t[i] == "{":
            tief += 1
        elif t[i] == "}":
            tief -= 1
            if tief == 0:
                return i + 1
    return -1


def body_zeile(src, fname):
    """(Zeilennummer, Einrueckung) der ersten echten Anweisung einer Funktion."""
    try:
        baum = ast.parse(src)
    except SyntaxError:
        return None, None
    for node in ast.walk(baum):
        if isinstance(node, ast.FunctionDef) and node.name == fname:
            erst = node.body[0]
            ln = erst.lineno
            if (isinstance(erst, ast.Expr) and isinstance(erst.value, ast.Constant)
                    and isinstance(erst.value.value, str)):
                if len(node.body) > 1:
                    ln = node.body[1].lineno
                else:
                    ln = erst.end_lineno + 1
            return ln, erst.col_offset
    return None, None


def funktion_um(src, pos):
    """FunctionDef-Knoten, in dem Zeichenposition pos liegt."""
    try:
        baum = ast.parse(src)
    except SyntaxError:
        return None
    zeile = src.count("\n", 0, pos) + 1
    treffer = None
    for node in ast.walk(baum):
        if isinstance(node, ast.FunctionDef):
            if node.lineno <= zeile <= (node.end_lineno or node.lineno):
                if treffer is None or node.lineno > treffer.lineno:
                    treffer = node
    return treffer


def hat_arg(node, name):
    if node is None:
        return False
    a = node.args
    namen = [x.arg for x in list(a.args) + list(a.kwonlyargs) + list(a.posonlyargs or [])]
    return name in namen


# ===================== einstellungen.py =====================

ZUSATZ_EINST = r'''

# ===== Bildformat (Patch Hochformat) =====
FORMATE = {
    "9:16": (1080, 1920, "portrait_16_9"),
    "16:9": (1920, 1080, "landscape_16_9"),
    "1:1": (1080, 1080, "square_hd"),
    "4:5": (1080, 1350, "portrait_4_3"),
}


def format_name(kanal):
    f = "9:16"
    try:
        d = laden()
        f = ((d.get(kanal) or {}).get("format") or "9:16")
    except Exception:
        pass
    return f if f in FORMATE else "9:16"


def format_masse(kanal):
    b, h, _ = FORMATE[format_name(kanal)]
    return b, h


def bild_format(kanal):
    return FORMATE[format_name(kanal)][2]
'''


def patch_einstellungen():
    p = P("einstellungen.py")
    if not os.path.exists(p):
        warn("einstellungen.py nicht gefunden")
        return
    t = lese(p)
    neu = t
    if "def format_masse(" not in neu:
        neu = neu.rstrip() + "\n" + ZUSATZ_EINST
        ok("einstellungen.py: FORMATE + format_masse + bild_format ergaenzt")
    else:
        info("einstellungen.py: Formatfunktionen waren schon drin")
    # "format" in STANDARD aufnehmen, damit laden() den Schluessel behaelt
    m = re.search(r"STANDARD\s*=\s*\{", neu)
    if m:
        a = neu.index("{", m.start())
        e = block_ende(neu, a)
        if e > 0:
            teil = neu[a:e]
            if '"format"' not in teil:
                neu_teil, n = re.subn(r'("(?:a|b)"\s*:\s*\{)',
                                      r'\1\n        "format": "9:16",', teil)
                if n:
                    neu = neu[:a] + neu_teil + neu[e:]
                    ok("einstellungen.py: format in STANDARD eingetragen (%dx)" % n)
                else:
                    warn("einstellungen.py: Kanalbloecke in STANDARD nicht erkannt")
            else:
                info("einstellungen.py: format in STANDARD war schon drin")
    if neu != t:
        schreibe(p, neu)
        g, f = pruefe(p)
        if not g:
            zurueck(p)
            warn("einstellungen.py: Syntaxfehler, zurueckgesetzt: " + f)


# ===================== video_bauen.py =====================

ZUSATZ_VB = r'''

# ===== Hochformat-Erweiterung (Patch) =====
def _setze_format(kanal):
    """Setzt BREITE/HOEHE auf das Format des Kanals."""
    global BREITE, HOEHE
    try:
        b, h = einstellungen.format_masse(kanal)
    except Exception:
        b, h = 1080, 1920
    BREITE, HOEHE = int(b), int(h)
    return BREITE, HOEHE


def _ass_fix(ziel, kanal=None):
    """Passt eine fertige .ass-Datei an BREITE/HOEHE an."""
    try:
        with open(ziel, encoding="utf-8") as f:
            t = f.read()
    except Exception:
        return
    m = re.search(r"PlayResX:\s*(\d+)", t)
    alt_b = float(m.group(1)) if (m and int(m.group(1)) > 0) else 1280.0
    hoch = HOEHE >= BREITE
    skal = (BREITE / alt_b) * (1.45 if hoch else 1.0)
    gesehen = {"PlayResX": False, "PlayResY": False,
               "WrapStyle": False, "ScaledBorderAndShadow": False}
    feld = []
    aus = []
    for z in t.splitlines():
        s = z.strip()
        low = s.lower()
        if low.startswith("playresx:"):
            aus.append("PlayResX: %d" % BREITE)
            gesehen["PlayResX"] = True
            continue
        if low.startswith("playresy:"):
            aus.append("PlayResY: %d" % HOEHE)
            gesehen["PlayResY"] = True
            continue
        if low.startswith("wrapstyle:"):
            aus.append("WrapStyle: 0")
            gesehen["WrapStyle"] = True
            continue
        if low.startswith("scaledborderandshadow:"):
            aus.append("ScaledBorderAndShadow: yes")
            gesehen["ScaledBorderAndShadow"] = True
            continue
        if low.startswith("format:") and "fontname" in low:
            feld = [x.strip().lower() for x in s.split(":", 1)[1].split(",")]
            aus.append(z)
            continue
        if low.startswith("style:") and feld:
            w = [x.strip() for x in s.split(":", 1)[1].split(",")]
            while len(w) < len(feld):
                w.append("0")

            def hol(name, stand):
                try:
                    return float(w[feld.index(name)])
                except Exception:
                    return stand

            def setz(name, wert):
                if name in feld:
                    w[feld.index(name)] = str(wert)

            setz("fontsize", max(14, int(round(hol("fontsize", 48.0) * skal))))
            setz("outline", max(1, int(round(hol("outline", 3.0) * skal))))
            setz("shadow", int(round(hol("shadow", 0.0) * skal)))
            if hoch:
                setz("marginl", int(BREITE * 0.07))
                setz("marginr", int(BREITE * 0.07))
                setz("marginv", int(HOEHE * 0.18))
                setz("alignment", 2)
            aus.append("Style: " + ",".join(w))
            continue
        aus.append(z)
    t = "\n".join(aus)
    kopf = []
    for k, v in (("PlayResX", BREITE), ("PlayResY", HOEHE),
                 ("WrapStyle", 0), ("ScaledBorderAndShadow", "yes")):
        if not gesehen[k]:
            kopf.append("%s: %s" % (k, v))
    if kopf:
        if "[Script Info]" in t:
            t = t.replace("[Script Info]", "[Script Info]\n" + "\n".join(kopf), 1)
        else:
            t = "[Script Info]\n" + "\n".join(kopf) + "\n" + t
    if hoch:
        neu = []
        for z in t.splitlines():
            if z.startswith("Dialogue:"):
                z = z.replace("\\N", " ")
            neu.append(z)
        t = "\n".join(neu)
    with open(ziel, "w", encoding="utf-8") as f:
        f.write(t + "\n")


def baue_untertitel_ass(*a, **k):
    erg = _ass_alt(*a, **k)
    ziel = k.get("ziel")
    if ziel is None and len(a) > 2:
        ziel = a[2]
    if ziel:
        _ass_fix(ziel, k.get("kanal"))
    return erg
'''


def patch_video_bauen():
    p = P("video_bauen.py")
    if not os.path.exists(p):
        warn("video_bauen.py nicht gefunden")
        return
    t = lese(p)
    alt = t

    t = import_rein(t, "import re")
    t = import_rein(t, "import einstellungen")

    t2, n = re.subn(r"^BREITE\s*,\s*HOEHE\s*=\s*\d+\s*,\s*\d+.*$",
                    "BREITE, HOEHE = 1080, 1920   # Standard hochkant, pro Kanal umstellbar",
                    t, count=1, flags=re.M)
    if n:
        t = t2
        ok("video_bauen.py: Standardmasse auf 1080x1920")
    else:
        if re.search(r"^BREITE\s*=", t, re.M):
            info("video_bauen.py: BREITE/HOEHE getrennt definiert - nur Umschaltung aktiv")
        else:
            warn("video_bauen.py: BREITE/HOEHE Zeile nicht gefunden")

    if "def _setze_format(" not in t:
        if re.search(r"\bdef baue_untertitel_ass\s*\(", t):
            t = re.sub(r"\bdef baue_untertitel_ass\s*\(", "def _ass_alt(", t, count=1)
            ok("video_bauen.py: Untertitel-Funktion umbenannt + Format-Nachbearbeitung")
        else:
            warn("video_bauen.py: baue_untertitel_ass nicht gefunden")
        t = t.rstrip() + "\n" + ZUSATZ_VB
        ok("video_bauen.py: _setze_format + _ass_fix ergaenzt")
    else:
        info("video_bauen.py: Hochformat-Teil war schon drin")

    for fname in ("baue_video", "baue_thumbnail"):
        knoten = None
        try:
            for nd in ast.walk(ast.parse(t)):
                if isinstance(nd, ast.FunctionDef) and nd.name == fname:
                    knoten = nd
        except SyntaxError:
            knoten = None
        if knoten is None:
            warn("video_bauen.py: %s nicht gefunden" % fname)
            continue
        if not hat_arg(knoten, "kanal"):
            warn("video_bauen.py: %s hat kein kanal - uebersprungen" % fname)
            continue
        quelle = "\n".join(t.splitlines()[knoten.lineno - 1:(knoten.end_lineno or knoten.lineno)])
        if "_setze_format(" in quelle:
            info("video_bauen.py: %s hatte den Aufruf schon" % fname)
            continue
        ln, ein = body_zeile(t, fname)
        if ln is None:
            warn("video_bauen.py: %s Rumpf nicht gefunden" % fname)
            continue
        zl = t.splitlines()
        zl.insert(ln - 1, " " * ein + "_setze_format(kanal)")
        t = "\n".join(zl)
        ok("video_bauen.py: Format-Umschaltung in %s eingebaut" % fname)

    if t != alt:
        schreibe(p, t)
        g, f = pruefe(p)
        if not g:
            zurueck(p)
            warn("video_bauen.py: Syntaxfehler, zurueckgesetzt: " + f)

    rest = lese(p)
    tr = [z.strip() for z in rest.splitlines()
          if re.search(r"\b(1280|720)\b", z) and not z.strip().startswith("#")
          and "PlayRes" not in z and "alt_b" not in z]
    if tr:
        warn("video_bauen.py: noch feste Werte 1280/720 in %d Zeile(n):" % len(tr))
        for z in tr[:6]:
            BERICHT.append("      " + z[:90])


# ===================== medien.py =====================

def patch_medien():
    p = P("medien.py")
    if not os.path.exists(p):
        warn("medien.py nicht gefunden")
        return
    t = lese(p)
    if "einstellungen.bild_format" in t:
        info("medien.py: Bildformat war schon umgestellt")
        return
    alt = t
    t = import_rein(t, "import einstellungen")

    m = re.search(r'"image_size"\s*:\s*"[^"]*"', t)
    if m:
        fn = funktion_um(t, m.start())
        if hat_arg(fn, "kanal"):
            t = re.sub(r'"image_size"\s*:\s*"[^"]*"',
                       '"image_size": einstellungen.bild_format(kanal)', t)
            ok("medien.py: image_size folgt jetzt dem Kanalformat")
        else:
            warn("medien.py: image_size gefunden, aber kein kanal in %s - Bilder bleiben quer"
                 % (fn.name if fn else "?"))
            return
    else:
        ziel = None
        try:
            for nd in ast.walk(ast.parse(t)):
                if isinstance(nd, ast.Dict):
                    for k in nd.keys:
                        if isinstance(k, ast.Constant) and k.value == "prompt":
                            ziel = nd
                            break
                if ziel is not None:
                    break
        except SyntaxError:
            ziel = None
        if ziel is None:
            warn("medien.py: kein image_size und kein prompt-Block gefunden")
            return
        fn = funktion_um(t, 0) if False else None
        zl = t.splitlines()
        pos = sum(len(x) + 1 for x in zl[:ziel.lineno - 1]) + ziel.col_offset
        fn = funktion_um(t, pos)
        if not hat_arg(fn, "kanal"):
            warn("medien.py: prompt-Block ohne kanal - Bilder bleiben quer")
            return
        klammer = t.index("{", pos)
        t = t[:klammer + 1] + '"image_size": einstellungen.bild_format(kanal), ' + t[klammer + 1:]
        ok("medien.py: image_size neu in den fal-Aufruf eingesetzt")

    if t != alt:
        schreibe(p, t)
        g, f = pruefe(p)
        if not g:
            zurueck(p)
            warn("medien.py: Syntaxfehler, zurueckgesetzt: " + f)


# ===================== Einstellungen-Datei =====================

def patch_json():
    p = P("regeln/einstellungen.json")
    if not os.path.exists(p):
        info("regeln/einstellungen.json noch nicht vorhanden")
        return
    try:
        d = json.loads(lese(p))
    except Exception as e:
        warn("einstellungen.json nicht lesbar: %s" % e)
        return
    n = 0
    for k, v in d.items():
        if not isinstance(v, dict) or v.get("format"):
            continue
        if k in ("a", "b") or "name" in v or "laenge" in v:
            v["format"] = "9:16"
            n += 1
    if n:
        shutil.copy2(p, p + ".bak_format")
        with open(p, "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=2)
        ok("einstellungen.json: %d Kanal/Kanaele auf 9:16 gesetzt" % n)
    else:
        info("einstellungen.json: Format war schon gesetzt")


def main():
    if not os.path.isdir(BASIS):
        print("FEHLER: %s fehlt" % BASIS)
        return 1
    patch_einstellungen()
    patch_video_bauen()
    patch_medien()
    patch_json()
    os.system("systemctl restart dashboard >/dev/null 2>&1")
    print("=" * 46)
    for z in BERICHT:
        print(z)
    print("=" * 46)
    try:
        sys.path.insert(0, BASIS)
        import einstellungen as E
        for k in ("a", "b"):
            print("Kanal %s: %s  %sx%s  Bilder: %s"
                  % (k, E.format_name(k), E.format_masse(k)[0],
                     E.format_masse(k)[1], E.bild_format(k)))
    except Exception as e:
        print("Pruefung uebersprungen: %s" % e)
    print("FERTIG")
    return 0


if __name__ == "__main__":
    sys.exit(main())
