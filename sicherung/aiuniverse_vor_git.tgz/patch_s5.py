# -*- coding: utf-8 -*-
import os, shutil, subprocess, sys
B = "/root/aiuniverse"
fehler = []


def tausche(datei, paare, merkmal, pruefen=True):
    p = os.path.join(B, datei)
    t = open(p, encoding="utf-8").read()
    if merkmal in t:
        print("INFO  %s war schon angepasst" % datei)
        return
    for alt, neu in paare:
        if alt not in t:
            print("ACHT  %s: Stelle nicht gefunden -> %r" % (datei, alt[:46]))
            fehler.append(datei)
            return
    shutil.copy2(p, p + ".bak_s5")
    for alt, neu in paare:
        t = t.replace(alt, neu, 1)
    open(p, "w", encoding="utf-8").write(t)
    if pruefen:
        r = subprocess.run([sys.executable, "-m", "py_compile", p], capture_output=True, text=True)
        if r.returncode:
            shutil.copy2(p + ".bak_s5", p)
            print("ACHT  %s zurueckgesetzt: %s" % (datei, r.stderr[-150:]))
            fehler.append(datei)
            return
    print("OK    %s" % datei)


# ---------- 1. szenen.py: Feld "passen" ----------
tausche("szenen.py", [
    ('BEWEGUNGEN = ["auto", "aus", "rein", "raus", "links", "rechts", "hoch", "runter"]',
     'BEWEGUNGEN = ["auto", "aus", "rein", "raus", "links", "rechts", "hoch", "runter"]\n'
     'PASSEN = ["fuellen", "ganz"]\n'
     'PASSEN_NAME = {"fuellen": "Rahmen fuellen, schneidet Raender",\n'
     '               "ganz": "ganz zeigen, weicher Rand"}'),
    ('        s.setdefault("figur", "")',
     '        s.setdefault("figur", "")\n'
     '        if s.get("passen") not in PASSEN:\n'
     '            s["passen"] = "fuellen"'),
    ('"bewegung": "auto", "ki_animation": False, "figur": "",',
     '"bewegung": "auto", "ki_animation": False, "figur": "", "passen": "fuellen",'),
    ('    elif feld == "figur":',
     '    elif feld == "passen":\n'
     '        if str(wert) not in PASSEN:\n'
     '            return {"ok": False, "fehler": "Unbekannt"}\n'
     '        d["szenen"][i]["passen"] = str(wert)\n'
     '    elif feld == "figur":'),
    ('            "figur": s.get("figur", ""),',
     '            "figur": s.get("figur", ""),\n'
     '            "passen": s.get("passen", "fuellen"),'),
    ('            "bewegungen": [[b, BEWEGUNG_NAME[b]] for b in BEWEGUNGEN]}',
     '            "bewegungen": [[b, BEWEGUNG_NAME[b]] for b in BEWEGUNGEN],\n'
     '            "passenarten": [[p, PASSEN_NAME[p]] for p in PASSEN]}'),
], "PASSEN_NAME")

# ---------- 2. szenen_video.py: Bild einpassen + Untertitel aus den Einstellungen ----------
ALT_BILD = '''def _stueck_bild(quelle, ziel, bewegung, nr, dauer, b, h, fps):
    r = _lauf(["ffmpeg", "-y", "-loglevel", "error", "-loop", "1", "-i", str(quelle),
               "-t", "%.3f" % dauer, "-vf", _zoompan(bewegung, nr, dauer, b, h, fps),
               "-r", str(fps), "-pix_fmt", "yuv420p", "-c:v", "libx264",
               "-preset", "veryfast", "-crf", "22", "-an", str(ziel)])
    return r.returncode == 0'''

NEU_BILD = '''def _ganz(bewegung, nr, dauer, b, h, fps):
    """Bild ganz zeigen, Rand mit weichgezeichneter Vergroesserung fuellen."""
    rahmen = max(2, int(round(dauer * fps)))
    gb, gh = int(b * 1.25) // 2 * 2, int(h * 1.25) // 2 * 2
    if bewegung == "auto":
        bewegung = ["rein", "raus"][nr % 2]
    grund = ("scale=%d:%d:force_original_aspect_ratio=increase,crop=%d:%d,"
             "gblur=sigma=26,eq=brightness=-0.12" % (gb, gh, gb, gh))
    if bewegung == "aus":
        hg = grund + ",scale=%d:%d,setsar=1" % (b, h)
    else:
        z = ("max(1.10-0.00035*on,1.0001)" if bewegung == "raus"
             else "min(1.0001+0.00035*on,1.10)")
        hg = grund + (",zoompan=z='%s':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)'"
                      ":d=%d:s=%dx%d:fps=%d,setsar=1" % (z, rahmen, b, h, fps))
    return ("[0:v]split=2[hg][vg];[hg]%s[a];"
            "[vg]scale=%d:%d:force_original_aspect_ratio=decrease,setsar=1[c];"
            "[a][c]overlay=(W-w)/2:(H-h)/2,fps=%d,format=yuv420p[v]" % (hg, b, h, fps))


def _stueck_bild(quelle, ziel, bewegung, nr, dauer, b, h, fps, passen="fuellen"):
    hinten = ["-r", str(fps), "-pix_fmt", "yuv420p", "-c:v", "libx264",
              "-preset", "veryfast", "-crf", "22", "-an", str(ziel)]
    vorn = ["ffmpeg", "-y", "-loglevel", "error", "-loop", "1", "-i", str(quelle),
            "-t", "%.3f" % dauer]
    if passen == "ganz":
        befehl = vorn + ["-filter_complex", _ganz(bewegung, nr, dauer, b, h, fps),
                         "-map", "[v]"] + hinten
    else:
        befehl = vorn + ["-vf", _zoompan(bewegung, nr, dauer, b, h, fps)] + hinten
    return _lauf(befehl).returncode == 0'''

ALT_ASS = '''def _ass(plan, ziel, b, h):
    import video_bauen as vb
    schrift = vb._tt_schrift()
    fs = max(34, int(h * 0.046))
    rand = max(3, int(fs * 0.11))
    schatten = max(2, int(fs * 0.07))
    ml = int(b * 0.085)
    mv = int(h * 0.17)
    zeilen = [vb._tt_ass_kopf(fs, rand, schatten, ml, mv, schrift)]
    for s in plan:
        if not s["untertitel"] or not (s["text"] or "").strip():
            continue
        stuecke = vb._tt_stuecke(s["text"])'''

NEU_ASS = '''def _ass(plan, ziel, b, h, kanal=None):
    import video_bauen as vb
    k = kanal or {}
    gewaehlt = (k.get("untertitel_schrift") or "auto")
    schrift = vb._tt_schrift() if gewaehlt in ("", "auto") else gewaehlt
    try:
        groesse = max(20.0, min(120.0, float(k.get("untertitel_groesse") or 48)))
    except Exception:
        groesse = 48.0
    try:
        woerter = int(k.get("untertitel_woerter") or 3)
    except Exception:
        woerter = 3
    woerter = max(1, min(6, woerter))
    caps = k.get("untertitel_caps") is not False
    fs = max(24, int(h * 0.046 * groesse / 48.0))
    rand = max(3, int(fs * 0.11))
    schatten = max(2, int(fs * 0.07))
    ml = int(b * 0.085)
    mv = int(h * 0.17)
    zeilen = [vb._tt_ass_kopf(fs, rand, schatten, ml, mv, schrift)]
    for s in plan:
        if not s["untertitel"] or not (s["text"] or "").strip():
            continue
        stuecke = vb._tt_stuecke(s["text"], max_w=woerter, max_z=max(10, woerter * 6))'''

tausche("szenen_video.py", [
    (ALT_BILD, NEU_BILD),
    (ALT_ASS, NEU_ASS),
    ('            text = " ".join(st).replace("{", "(").replace("}", ")")',
     '            text = " ".join(st).replace("{", "(").replace("}", ")")\n'
     '            if caps:\n'
     '                text = text.upper()'),
    ('''        ok = (_stueck_clip(s["quelle"], ziel, s["dauer"], b, h, fps) if s["typ"] == "clip"
              else _stueck_bild(s["quelle"], ziel, s["bewegung"], i, s["dauer"], b, h, fps))''',
     '''        ok = (_stueck_clip(s["quelle"], ziel, s["dauer"], b, h, fps) if s["typ"] == "clip"
              else _stueck_bild(s["quelle"], ziel, s["bewegung"], i, s["dauer"], b, h, fps,
                                s.get("passen", "fuellen")))'''),
    ('"bewegung": s.get("bewegung", "auto"), "musik": s.get("musik", "auto"),',
     '"bewegung": s.get("bewegung", "auto"), "musik": s.get("musik", "auto"),\n'
     '                     "passen": s.get("passen", "fuellen"),'),
    ('    ass = _ass(plan, str(arbeit / "ut.ass"), b, h)',
     '    ass = _ass(plan, str(arbeit / "ut.ass"), b, h, kanal)'),
], "def _ganz(")

# ---------- 3. dashboard2.py: Herunterladen ----------
tausche("dashboard2.py", [
    ('        if w.startswith("/video/"):',
     '''        if w.startswith("/laden/"):
            o = unquote(w[7:])
            pf = os.path.join(VIDEOS, o, "video.mp4")
            if not os.path.exists(pf):
                return self.sende({"fehler": "nicht da"}, code=404)
            with open(pf, "rb") as f:
                roh = f.read()
            name = re.sub(r"[^A-Za-z0-9_.-]", "_", o) or "video"
            return self.sende(roh, "video/mp4", kopf={
                "Content-Disposition": 'attachment; filename="%s.mp4"' % name})

        if w.startswith("/video/"):'''),
    ('"bewegung", "figur", "ki_animation", "musik"):',
     '"bewegung", "figur", "ki_animation", "musik", "passen"):'),
], 'w.startswith("/laden/")')

# ---------- 4. Oberflaeche ----------
KNOPF_ALT = "      +'<button class=\"ik\" onclick=\"spiel(\\''+v.ordner+'\\')\">\u25b6</button>'"
KNOPF_NEU = (KNOPF_ALT + "\n"
             "      +'<button class=\"ik\" onclick=\"herunter(\\''+v.ordner+'\\')\">\u2913</button>'")

STAND_NEU = '''function jn(x){return x?"an":"aus"}
function standKarte(){
  var e=S.einst||{}, k=kanalDaten()||{};
  var modus=(e.modus==="szenen")?"Eigene Szenen":"Claude schreibt";
  var vn=(S.vorlagen[e.vorlage]||{}).name||e.vorlage||"—";
  var z=[["Videoart",h(vn)],["Wie",modus],["Format",h(e.format||"9:16")],
         ["Sprache",h((e.sprachen||["de"])[0])],["Länge",(e.laenge||20)+" Sek."],
         ["Bilder pro Minute",String(e.bilder_pro_minute||24)],
         ["Automatik",jn(e.automatik_an)],["Stimme",jn(e.stimme_an!==false)],
         ["Untertitel",jn(e.untertitel_an!==false)],["Musik",jn(e.musik_an!==false)],
         ["Geräusche",jn(e.ambience_an)],["Telegram",jn(e.telegram_token&&e.telegram_chat)]];
  var o='<div class="karte p"><h2 class="kt">Eingestellt</h2><div class="raster">';
  z.forEach(function(x){o+='<div class="zl"><div class="zt">'+x[0]+'</div><div class="zw '
    +(x[1]==="aus"?"grau":"")+'">'+x[1]+'</div></div>'});
  return o+'</div></div>';
}
function kanalUmbenennen(){
  var k=kanalDaten()||{};
  el("dialog").innerHTML='<div class="dim"><div class="dlg"><h2>Kanal umbenennen</h2>'
   +'<input type="text" id="knneu" class="breit" value="'+h(k.name||"")+'" style="margin-bottom:14px">'
   +'<div class="zw"><button class="knopf" onclick="zu()">Abbrechen</button>'
   +'<button class="knopf or" onclick="kanalNameSpeichern()">Speichern</button></div></div></div>';
}
function kanalNameSpeichern(){
  var n=(el("knneu").value||"").trim();
  if(!n)return melde("Name darf nicht leer sein.");
  api("/api/kanal?k="+S.kanal,{name:n}).then(function(){zu();S.einst.name=n;laden()});
}
'''

tausche("dashboard2.html", [
    (KNOPF_ALT, KNOPF_NEU),
    ('function spiel(o){window.open("/video/"+o,"_blank")}',
     'function spiel(o){window.open("/video/"+o,"_blank")}\n'
     'function herunter(o){location.href="/laden/"+encodeURIComponent(o)}\n' + STAND_NEU),
    ('''function tStart(){
  var l=S.daten.lauf||{};
  var o='<div class="karte">'
   +reihe("Thema von Hand",''',
     '''function tStart(){
  var l=S.daten.lauf||{};
  var o=standKarte();
  o+='<div class="karte"><div class="r"><div><div class="lb">Kanalname</div>'
   +'<div class="hint">'+h((kanalDaten()||{}).name||"")+'</div></div>'
   +'<button class="knopf" onclick="kanalUmbenennen()">ändern</button></div></div>';
  o+='<div class="karte">'
   +reihe("Thema von Hand",'''),
    ('''    if(s.typ!=="clip"){
      o+='<div class="szz"><span class="szh">Bewegung</span>''',
     '''    if(s.typ!=="clip"){
      o+='<div class="szz"><span class="szh">Bild</span><select onchange="szeneSetz(\\''+s.id+'\\',\\'passen\\',this.value)">'
       +(d.passenarten||[]).map(function(x){return '<option value="'+x[0]+'"'+(s.passen===x[0]?" selected":"")+'>'+h(x[1])+'</option>'}).join("")
       +'</select></div>';
      o+='<div class="szz"><span class="szh">Bewegung</span>'''),
    ('</style>',
     '.raster{display:grid;grid-template-columns:1fr 1fr;gap:7px}\n'
     '.zl{background:#15151A;border:1px solid #23232B;border-radius:9px;padding:7px 9px}\n'
     '.zt{font-size:9.5px;letter-spacing:.07em;text-transform:uppercase;color:#74747F}\n'
     '.zw{font-size:12px;font-weight:600;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n'
     '</style>'),
], "function standKarte", pruefen=False)

print()
print("NICHT FERTIG:", ", ".join(sorted(set(fehler))) if fehler else "alles durch")
print("TEIL 5 FERTIG")
