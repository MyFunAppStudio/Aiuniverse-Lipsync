# Patch 11: Szenen statt Bilderliste - Bild passt zum gesprochenen Moment
from pathlib import Path
import re

# --- 1. text_generator.py: Claude schreibt SZENEN ---
p = Path('text_generator.py'); s = p.read_text(encoding='utf-8')
if '"szenen"' not in s:
    alt_json = re.search(r'Antworte NUR mit JSON.*?\}\}"""', s, re.S)
    if alt_json:
        neu = '''Antworte NUR mit JSON, ohne Erklaerung, ohne Markdown.
Teile die Geschichte in {anzahl_bilder} SZENEN. Jede Szene hat ihren eigenen
Text UND das Bild das GENAU dazu passt. Das Bild zeigt was in diesem Moment
erzaehlt wird - nicht irgendein allgemeines Motiv.

{{
  "titel": "...",
  "szenen": [
    {{"text": "gesprochener Text dieser Szene",
      "bild": "englische Bildbeschreibung die genau zu diesem Text passt"}}
  ],
  "beschreibung_youtube": "...",
  "beschreibung_tiktok": "...",
  "beschreibung_instagram": "...",
  "hashtags": ["#...", "#..."],
  "pinned_comment": "..."
}}"""'''
        s = s[:alt_json.start()] + neu + s[alt_json.end():]

    # Szenen in skript + bild_prompts umwandeln (Rueckwaertskompatibel)
    alt_ret = '''    try:
        return json.loads(antwort)'''
    neu_ret = '''    def _aus_szenen(d):
        """Baut skript und bild_prompts aus den Szenen."""
        sz = d.get("szenen") or []
        if sz:
            d["skript"] = " ".join((x.get("text") or "").strip() for x in sz).strip()
            d["bild_prompts"] = [(x.get("bild") or "").strip() for x in sz if x.get("bild")]
        d.setdefault("skript", "")
        d.setdefault("bild_prompts", [])
        return d

    try:
        return _aus_szenen(json.loads(antwort))'''
    if alt_ret in s:
        s = s.replace(alt_ret, neu_ret, 1)

    # auch bei der Rettung
    s = s.replace('        print(f"[Text] Gerettet: Titel + Skript + {len(d[\'bild_prompts\'])} Bilder")\n        return d',
                  '        print(f"[Text] Gerettet: {len(d[\'bild_prompts\'])} Bilder")\n        return d')
    p.write_text(s, encoding='utf-8')
    print("text_generator.py: Claude schreibt jetzt Szenen mit passenden Bildern")
else:
    print("text_generator.py: schon ok")

# --- 2. erstelle_video.py: Szenen weiterreichen ---
p = Path('erstelle_video.py'); s = p.read_text(encoding='utf-8')
if 'szenen=paket' not in s:
    s = s.replace('skript=paket.get("skript", ""))',
                  'skript=paket.get("skript", ""),\n'
                  '                                   szenen=paket.get("szenen"))')
    p.write_text(s, encoding='utf-8')
    print("erstelle_video.py: Szenen werden weitergereicht")
else:
    print("erstelle_video.py: schon ok")

# --- 3. video_bauen.py: Bilddauer nach Textlaenge der Szene ---
p = Path('video_bauen.py'); s = p.read_text(encoding='utf-8')
if 'szenen=None' not in s:
    s = s.replace('def baue_video(kanal, bilder, ton_pfad, ziel_pfad, skript=None):',
                  'def baue_video(kanal, bilder, ton_pfad, ziel_pfad, skript=None, szenen=None):')
    s = s.replace('''    abschnitte = [(bild, i) for i, bild in enumerate(bilder)]
    pro_abschnitt = max(1.5, gesamt / len(abschnitte))
    print(f"[Video] {len(bilder)} Bilder a {pro_abschnitt:.1f}s "
          f"(1 Effekt pro Bild, Schnitt beim Bildwechsel)")''',
'''    # Standzeit je Bild: wenn Szenen da sind, nach Textlaenge gewichten,
    # damit das Bild genau so lange steht wie der Text dazu gesprochen wird.
    laengen = None
    if szenen and len(szenen) == len(bilder):
        zeichen = [max(1, len((x.get("text") or ""))) for x in szenen]
        summe = sum(zeichen)
        laengen = [max(1.2, gesamt * z / summe) for z in zeichen]
        print(f"[Video] {len(bilder)} Szenen - Bilddauer passt zum Text")
    else:
        laengen = [max(1.5, gesamt / len(bilder))] * len(bilder)
        print(f"[Video] {len(bilder)} Bilder gleichmaessig verteilt")

    abschnitte = [(bild, i) for i, bild in enumerate(bilder)]''')
    # Dauer pro Abschnitt einzeln verwenden
    s = s.replace('''    for bild, _ in abschnitte:
        if zoom_an:''',
'''    for nr, (bild, _) in enumerate(abschnitte):
        if zoom_an:''')
    s = s.replace('''            befehl += ["-loop", "1", "-t", f"{pro_abschnitt:.3f}", "-i", str(bild)]''',
                  '''            befehl += ["-loop", "1", "-t", f"{laengen[nr]:.3f}", "-i", str(bild)]''')
    s = s.replace('''            filt = (f"[{n}:v]{_effekt(effekt_nr, pro_abschnitt)},"
                    f"trim=duration={pro_abschnitt:.3f},setpts=PTS-STARTPTS,"''',
                  '''            filt = (f"[{n}:v]{_effekt(effekt_nr, laengen[n])},"
                    f"trim=duration={laengen[n]:.3f},setpts=PTS-STARTPTS,"''')
    p.write_text(s, encoding='utf-8')
    print("video_bauen.py: Bilddauer richtet sich nach der Szene")
else:
    print("video_bauen.py: schon ok")
print("FERTIG")
