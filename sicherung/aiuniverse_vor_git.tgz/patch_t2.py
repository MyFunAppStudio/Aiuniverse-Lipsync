import os, shutil, subprocess, sys
B = "/root/aiuniverse"
p = os.path.join(B, "einstellungen.py")
t = open(p, encoding="utf-8").read()
if "geloescht.json" in t:
    print("INFO  Loeschsperre war schon drin")
else:
    shutil.copy2(p, p + ".bak_t2")
    t += """

# ===== Geloeschte Kanaele bleiben geloescht (Patch T2) =====
_laden_t2 = laden


def laden():
    d = _laden_t2()
    try:
        import json as _j, os as _o
        p = _o.path.join(_o.path.dirname(_o.path.abspath(__file__)),
                         "regeln", "geloescht.json")
        if _o.path.exists(p):
            with open(p, encoding="utf-8") as f:
                weg = _j.load(f)
            for k in (weg or []):
                d.pop(k, None)
    except Exception:
        pass
    return d
"""
    open(p, "w", encoding="utf-8").write(t)
    r = subprocess.run([sys.executable, "-m", "py_compile", p], capture_output=True, text=True)
    if r.returncode:
        shutil.copy2(p + ".bak_t2", p)
        print("ACHT  zurueckgesetzt:", r.stderr[-200:])
        raise SystemExit(1)
    print("OK    Loeschsperre eingebaut")

sys.path.insert(0, B)
import vorlagen, kanaele
print("Vorlagen:", ", ".join(vorlagen.alle().keys()))
print("Kanaele:")
for x in kanaele.liste():
    print("  %-4s %-20s %-10s %s" % (x["key"], x["name"], x["vorlage"],
          ("Geschwister von " + x["eltern"]) if x["eltern"] else ""))
print("FERTIG")
