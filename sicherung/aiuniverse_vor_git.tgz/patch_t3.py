import os, shutil, subprocess, sys
B = "/root/aiuniverse"

# --- 1. kanaele.py: Kennung und Emoji vergeben ---
p = os.path.join(B, "kanaele.py")
t = open(p, encoding="utf-8").read()
if '"id": key' in t:
    print("INFO  kanaele: Kennung war schon drin")
else:
    shutil.copy2(p, p + ".bak_t3")
    t = t.replace('''    d[key] = {
        "name": str(name or "Neuer Kanal").strip(),''',
'''    d[key] = {
        "id": key,
        "emoji": "\\U0001F3AC",
        "name": str(name or "Neuer Kanal").strip(),''')
    t = t.replace('''    neu["name"] = str(name or (neu.get("name", "Kopie") + " Kopie")).strip()''',
'''    neu["id"] = key
    neu["name"] = str(name or (neu.get("name", "Kopie") + " Kopie")).strip()''')
    open(p, "w", encoding="utf-8").write(t)
    r = subprocess.run([sys.executable, "-m", "py_compile", p], capture_output=True, text=True)
    if r.returncode:
        shutil.copy2(p + ".bak_t3", p)
        print("ACHT  kanaele zurueckgesetzt:", r.stderr[-200:])
        raise SystemExit(1)
    print("OK    kanaele: jede Kanalkennung und ein Emoji werden gesetzt")

# --- 2. erstelle_video.py: Geschwisterkanaele laufen mit ---
p = os.path.join(B, "erstelle_video.py")
t = open(p, encoding="utf-8").read()
if "_gs_erstelle_alt" in t:
    print("INFO  erstelle_video: Geschwisterlauf war schon drin")
else:
    shutil.copy2(p, p + ".bak_t3")
    t += '''

# ===== Geschwisterkanaele laufen mit (Patch T3) =====
import glob as _gs_glob
import json as _gs_json
import os as _gs_os
import einstellungen as _gs_e
import kanaele as _gs_k
import medien as _gs_m

_gs_erstelle_alt = erstelle


def _gs_neuester(kid):
    try:
        muster = str(config.ORDNER_VIDEOS / (kid + "_*"))
        ordner = sorted(_gs_glob.glob(muster))
        return ordner[-1] if ordner else None
    except Exception:
        return None


def _gs_thema(ordner):
    try:
        with open(_gs_os.path.join(ordner, "paket.json"), encoding="utf-8") as f:
            return (_gs_json.load(f).get("titel") or "").strip() or None
    except Exception:
        return None


def erstelle(kanal, eigenes_thema=None):
    erg = _gs_erstelle_alt(kanal, eigenes_thema)
    try:
        eltern = kanal.get("id") or kanal.get("_key")
        kinder = _gs_k.kinder(eltern)
        if not kinder:
            return erg
        ordner = _gs_neuester(eltern)
        bilder = sorted(_gs_glob.glob(_gs_os.path.join(ordner or "", "bild_*.jpg")))
        thema = _gs_thema(ordner) if ordner else None
        if not bilder:
            print("[Geschwister] keine Bilder zum Weiterverwenden - uebersprungen")
            return erg
        daten = _gs_e.laden()
        for kid in kinder:
            print("[Geschwister] %s - gleiche Bilder, eigene Sprache" % kid)
            kd = dict(kanal)
            kd.update(daten.get(kid) or {})
            kd["id"] = kid
            alt = _gs_m.erzeuge_bilder
            _gs_m.erzeuge_bilder = lambda k, p, o, _b=list(bilder): list(_b)
            try:
                _gs_erstelle_alt(kd, thema)
            finally:
                _gs_m.erzeuge_bilder = alt
    except Exception as ex:
        print("[Geschwister] uebersprungen: %s" % ex)
    return erg
'''
    open(p, "w", encoding="utf-8").write(t)
    r = subprocess.run([sys.executable, "-m", "py_compile", p], capture_output=True, text=True)
    if r.returncode:
        shutil.copy2(p + ".bak_t3", p)
        print("ACHT  erstelle_video zurueckgesetzt:", r.stderr[-200:])
        raise SystemExit(1)
    print("OK    erstelle_video: Geschwisterkanaele laufen mit")
print("FERTIG")
