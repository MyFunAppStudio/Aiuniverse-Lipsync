import os, re, shutil, subprocess, sys
B = "/root/aiuniverse"

p1 = os.path.join(B, "einstellungen.py")
t1 = open(p1, encoding="utf-8").read()
a1 = '        d = laden()\n        f = ((d.get(kanal) or {}).get("format") or "9:16")\n'
n1 = ('        if isinstance(kanal, dict):\n'
      '            f = kanal.get("format") or "9:16"\n'
      '        else:\n'
      '            f = ((laden().get(kanal) or {}).get("format") or "9:16")\n')
if a1 in t1:
    shutil.copy2(p1, p1 + ".bak_f10")
    open(p1, "w", encoding="utf-8").write(t1.replace(a1, n1, 1))
    print("OK    einstellungen: Format versteht Kanal-Paket")
else:
    print("INFO  einstellungen: schon angepasst")

p2 = os.path.join(B, "medien.py")
t2 = open(p2, encoding="utf-8").read()
if not os.path.exists(p2 + ".bak_f10"):
    shutil.copy2(p2, p2 + ".bak_f10")
FUNK = '''

def _bild_brauchbar(ziel):
    import os as _o, re as _r, subprocess as _s
    try:
        if not _o.path.exists(str(ziel)) or _o.path.getsize(str(ziel)) < 20000:
            return False
        r = _s.run(["ffmpeg", "-hide_banner", "-nostats", "-i", str(ziel), "-vf",
                    "signalstats,metadata=print:key=lavfi.signalstats.YAVG",
                    "-f", "null", "-"], capture_output=True, text=True, timeout=60)
        m = _r.search(r"YAVG=([0-9.]+)", r.stderr or "")
        return (float(m.group(1)) if m else 128.0) >= 22.0
    except Exception:
        return True
'''
ALT = ('            _lade_datei(ergebnis["images"][0]["url"], ziel)\n'
       '            print(f"[Bild] {i+1}/{gesamt} fertig")\n')
NEU = ('            _lade_datei(ergebnis["images"][0]["url"], ziel)\n'
       '            if not _bild_brauchbar(ziel):\n'
       '                print(f"[Bild] {i+1}/{gesamt} unbrauchbar - zweiter Versuch")\n'
       '                ergebnis = _fal_anfrage(url, {\n'
       '                    "prompt": prompt + ", helles Tageslicht, klar erkennbar",\n'
       '                    "image_size": einstellungen.bild_format(kanal),\n'
       '                    "num_images": 1,\n'
       '                }, schluessel)\n'
       '                _lade_datei(ergebnis["images"][0]["url"], ziel)\n'
       '            print(f"[Bild] {i+1}/{gesamt} fertig")\n')
if "_bild_brauchbar" in t2:
    print("INFO  medien: zweiter Versuch war schon drin")
elif ALT not in t2:
    print("ACHT  medien: Stelle nicht gefunden - nichts geaendert")
else:
    t2 = t2.replace(ALT, NEU, 1) + FUNK
    open(p2, "w", encoding="utf-8").write(t2)
    r = subprocess.run([sys.executable, "-m", "py_compile", p2],
                       capture_output=True, text=True)
    if r.returncode:
        shutil.copy2(p2 + ".bak_f10", p2)
        print("ACHT  Syntaxfehler, zurueckgesetzt:", r.stderr[-200:])
        raise SystemExit(1)
    print("OK    medien: zweiter Versuch eingebaut")
print("FERTIG")
