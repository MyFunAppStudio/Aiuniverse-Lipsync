import os, shutil, subprocess, sys
B = "/root/aiuniverse"
p = os.path.join(B, "dashboard2.py")
t = open(p, encoding="utf-8").read()
NEUE_LISTE = ('    if a in ("text", "gesprochen", "untertitel", "sekunden", '
              '"bewegung", "figur", "ki_animation", "musik"):')


def nachziehen():
    """Aktionsliste auf den neuesten Stand bringen, auch wenn schon eingebaut."""
    s = open(p, encoding="utf-8").read()
    for alt in ('    if a in ("text", "gesprochen", "untertitel", "sekunden"):',
                '    if a in ("text", "gesprochen", "untertitel", "sekunden", '
                '"bewegung", "figur", "ki_animation"):'):
        if alt in s:
            open(p, "w", encoding="utf-8").write(s.replace(alt, NEUE_LISTE, 1))
            r = subprocess.run([sys.executable, "-m", "py_compile", p],
                               capture_output=True, text=True)
            if r.returncode:
                open(p, "w", encoding="utf-8").write(s)
                print("ACHT  Nachziehen zurueckgesetzt:", r.stderr[-150:])
                return
            print("OK    Aktionsliste nachgezogen (Musik je Szene)")
            return


if "def hochladen" in t:
    print("INFO  Server: Szenen waren schon drin")
    nachziehen()
    raise SystemExit(0)

methode = '''    def hochladen(self, k, q):
        name = (q.get("name") or [""])[0]
        zweck = (q.get("zweck") or ["szene"])[0]
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except Exception:
            n = 0
        if not k or k not in einstellungen.laden():
            return self.sende({"ok": False, "fehler": "Kanal unbekannt"}, code=400)
        if n <= 0:
            return self.sende({"ok": False, "fehler": "Datei ist leer"}, code=400)
        if n > 90 * 1024 * 1024:
            return self.sende({"ok": False, "fehler": "Datei zu gross, hoechstens 90 MB"}, code=400)
        a = szenen.art(name)
        if zweck == "musik" and a != "ton":
            return self.sende({"ok": False, "fehler": "Nur Tondateien: mp3, wav, m4a"}, code=400)
        if zweck != "musik" and a not in ("bild", "clip"):
            return self.sende({"ok": False, "fehler": "Nur Bilder oder Videoclips"}, code=400)
        zname = szenen.sauberer_name(name)
        ziel = os.path.join(szenen.ordner(k), zname)
        rest = n
        try:
            with open(ziel, "wb") as f:
                while rest > 0:
                    stueck = self.rfile.read(min(262144, rest))
                    if not stueck:
                        break
                    f.write(stueck)
                    rest -= len(stueck)
        except Exception:
            rest = -1
        if rest != 0:
            try:
                os.remove(ziel)
            except Exception:
                pass
            return self.sende({"ok": False, "fehler": "Hochladen abgebrochen"}, code=400)
        if zweck == "musik":
            szenen.musik_setzen(k, zname)
        else:
            szenen.hinzufuegen(k, zname, (q.get("text") or [""])[0])
        return self.sende({"ok": True, "datei": zname})

'''

hilfe = '''def szenen_schreiben(key, b):
    a = b.get("aktion") or ""
    sid = b.get("id") or ""
    if a in ("text", "gesprochen", "untertitel", "sekunden", "bewegung", "figur", "ki_animation", "musik"):
        return szenen.aendern(key, sid, a, b.get("wert"))
    if a in ("hoch", "runter"):
        return szenen.verschieben(key, sid, a)
    if a == "weg":
        return szenen.entfernen(key, sid)
    if a == "musik_weg":
        return szenen.musik_setzen(key, "")
    return {"ok": False, "fehler": "Aktion unbekannt"}


'''

paare = [
    ("sys.path.insert(0, BASIS)", "sys.path.insert(0, BASIS)\nimport szenen", 1),
    ("def api_stand(", hilfe + "def api_stand(", 1),
    ("    def do_POST(self):", methode + "    def do_POST(self):", 1),
    ('''        k = (q.get("k") or [""])[0]
        b = self.koerper()''',
     '''        k = (q.get("k") or [""])[0]

        if w == "/api/hochladen":
            return self.hochladen(k, q)

        b = self.koerper()''', 1),
    ('        if w.startswith("/video/"):',
     '''        if w == "/api/szenen":
            return self.sende(szenen.fuer_anzeige(k))

        if w.startswith("/eigen/"):
            return self.datei(szenen.datei_pfad(k, unquote(w[7:])))

        if w.startswith("/video/"):''', 1),
    ('        if w == "/api/start":',
     '''        if w == "/api/szenen":
            return self.sende(szenen_schreiben(k, b))

        if w == "/api/start":''', 1),
]
for alt, neu, n in paare:
    if t.count(alt) < 1:
        print("ACHT  Stelle nicht gefunden, nichts geaendert:", alt[:45])
        raise SystemExit(1)
shutil.copy2(p, p + ".bak_s1")
for alt, neu, n in paare:
    t = t.replace(alt, neu, n)
open(p, "w", encoding="utf-8").write(t)
r = subprocess.run([sys.executable, "-m", "py_compile", p], capture_output=True, text=True)
if r.returncode:
    shutil.copy2(p + ".bak_s1", p)
    print("ACHT  Server zurueckgesetzt:", r.stderr[-200:])
    raise SystemExit(1)
print("OK    Server: Hochladen und Szenen eingebaut")
