# Patch 7: Bildwechsel-Bug, 6 Effekte, schnelle Schnitte, Untertitel, Bildvielfalt
from pathlib import Path
import base64, zlib, sys

NEU_B64 = "eNq1WW1z2zYS/q5fgdJzZ7KmaEp20h7v2Bm7kSe5pEnGdnMzdT0cSAIlViTIAUDJskb//XYBvkmynXSupw8UBSwWD/Z9oSMS/olP74h8SaYsJ2NaMh6QyySdMkFOyG3OSf8nEjOhkhmThgqof0kUoeMVm8wlS/mUcTKKY7ZQjLtETuacpSmM3cBbomAQVpR8SljCZ2wsKOcwRn6FJ7BVwADm/xTcJCtyoYgsx4XIJ0zKegR4T/Os+cV6scgzUlA1T5MxqYY/w8+aZJLzOJn1elefb0hIzvze5fXo3e3IJW8/jd6OYGgw/NF3yQ9Dv3fz89vrd1e3MGadllKcyjkV7DTOuZKnSpRMrQt2OmV/0GV5+ga+vpQ3lMv+ZZ5OPaViq9frTVlMVM6jlDKQhI2vRUynTtAj8LEs64OeICh8EL0sSkESkCNblChkDyg0JRMgR55IwNLKwBMlt+/0vOYWxzAxZpZLrP4Sn0yIXOifcp6vIsaVSJjEgTgXGVXhtBRUJTm33JZLP4+RApDTMlUhzwuRcBWtBC0KJmQ4CHi+YOtwAFRSifZMmsW9Sya0UKVgUV6qolThLUjKJYo9mFdDpsQ6aLYUDOg5idOcKrs+qSfVFDjAl0gK2zHL2MOEFYp8oWnJRni4AyZnvudXco+YtlCbl1nGhEumYOqilfx7xvuXsEQG5DVZwskm84SBzBm5ZCs2K0EtYNu1xROZTObgAY1GYlBFRh/soQsKU7ZmTr4nYFYV1pnIJeortuSEpiwcnvt+MDh75Qcg/AmIRySzhNM0orJgExVpTYQJnwhGJXMnIi/aNWbPDH0rekCDTFanw74Nz8c8z06HTpdgrQnmmmDeEmiKJRUJ1d4YktZ0jogfkJTymaQZSDLhuAi8uJ6PrY0+ztbFiYLy8DE8zhJuD05A3v5w+H3O3YF39so5DqbhJt4GD+HxpoK7PQ7Wza/19tjqsA1kuDEOuH3YaA/cBnEBgyDHbccqj8ggAF8v5TcBA7UgmH4Xm///gzYMMPCtGF8QTsFKBNiMki9jHHjDYQcQaLJfKdMBvKcw/JdAO9uDliZ88T8gswd9A875S9Cd76ErtWGekJSBs0GuIL/Brt9ghJ4xw0Fthk+regfjGk8271f+0cr8m7G/Csg0obMcPPibEL4yEF/te8oOqhcs4Sm0f1bq971OpGwiwZ0JkORvIHduN8POfR1HH1mibFmlpDaA1kkK64Wb69v+b0Bm8koTJDMMgBge69UQIQe+75sIKZVrKKbJMsundiZdcvba9xuCLDkkeN1OQ5Q8mG6511nF2kgV+MPpNgBTqF4k0y/uJpOBfzbd1qkaq6GobMoUG7OWS6AOopmK4AwueUxY2opgJB5ZOVNY5zAtgzdUsSQgt7COzLQZZxQydTIjtIwBJyMf4AUFiikHaNNWWLgZHEYwD1K8Lazf5QkmYgIPDYTkAvZ0djNiEhOeK732IBd+zDkzUf8Ii4pFCWjJW8qKYjIHVTwykTJIcsSGgEnOh+Q3xItJj3LyH6iVZoLxR9C4ZrHKEa8AgLiXJ4sUjALAmdl5zRUWL1QJ1SDmFygG6mwJ2FcIomLTYoUDoNlVqxzt/dxe4cuA/CsEXC0tflr29RqgBBzwXDWyaVawFFS9sx72q9btju+cwsNah08bVM8gWPWe4/gyp0ppDdELmns0OomMDeryL7NRQnNHC3WOQm0YOfWaFDWhzcyoAauiWg/gVHoVA79nUHUwu6O9gdOCwTCQ4Dmr/U730cA59kZQ3qC3U7NkFxZ+TJlkKiff+0fXtyA0mA072oOQgcQQQfVZTsz67qqW2Jy6lje4fbL9nW9M8MKHsyV9iFTVCLJ2kGAOD2uHC8oMp7smqod/Cjsb71rPGIq2RaUxiBDAAXsOW0eLZtRbCYgqEfqPbcGu3h+5ORngdlzYc5JPoWEKrVLF/R+tnTCG67tBaol9mb2gkH5cMtbdm0vqUtyEqepVLsAlVIgm1Qauq5JB2Nrp+k7qjg7e2k6NPJZw4qzTipjN0K70EcfGDsdoUWbKZJkaSy2K3TahwdeV1FPzXgE9F1detpgmwjY/ZNVTsIdEqihfVH1F17UMklZHuoexrTvdzt6T9zpgV8df5mJOMTl1zODADxv/e6qbM9mo6n0r6x6YvkBryJsx2LwmiKBLixAgBPahU8VxzOsRxaq8s0IPmi4Gu7rOMY/Iv6FXkfoIZJWIKYo/Y3PBBCMX4waLifE6blRNOszXXbrmRMcd4Hf33SiBGHcDhRFrJ0QgpUQa6MNBIjUrZy9mN3vU7qk5gYTA6ZvtT4h0quOhhJpFtUC9Ye34VXxp2VZCNFqOGzVvkKrCvK3VjTFgb/W2KzKrAz22KNnsgAm8QbyVxK5kSCiI9EkSx6rOMmYxm+t0CA16VrCZbsjX+pnmUCQsWdo2660CjIQiFG4LdSdvVjazK+sjwktBRu8+kitBM0b6pKpFCauKlSnFRkoXIzMKCb7pd3cjmoF9grj7SdXrIybn/oXsurMqzfMCTzbQZ1XwhKi8J6ozqIBx9okdnkTQ+Nx9ryqaIHruWi5kMTuC6KD9JuLC2bXhjt6/Ls0YCjQsNcCmNnwbLO839a1Cw97dtVZn61oHhYWxJahNsubKJXxCEq5kqoDw9vn2pn9ze3F9Cy/PcgNaSUU4cKu7nHW5PB/6xd0SgN5bL5VAB4cyFxR1+xA07cO33FM8B0/fX+yzdFvQdWvyNfhawU1WB+SVWy2YCVlWlUbhMGapsYE2Ju1HCqd3yNbaaHbbSc4ngAWUsx8hgmU4CGjo34l8fm81UbiTKCGlQBXAeXU7kTL1aADCCiMkKVDsOqdUNmdyc6sdQ7HfhRiqOvi5B8kRwqHVknvAxGrqTOQIyQ2/PZ0vpd0xe6l0fWdbVzlXHyFchOYek+BFpouDN8kjCwc/uHipCWo71Lb1GayaivXPeZqXIvz7W9+/0h/3U6lSSLOdCfN5isllLiA236g12OGgXhkO3Zs5neYrGLpIkxmHMkTB4C9UgEV+Cc+HHTupigmMEXBWxxOsSOmE2VYAkQOaqcDqjB2bseNn7czSeoY+DESaMhkeb5A/dOLGJ6QGerxB+W2P75Z5qbo22+oeZ6znqpCO8ayYwO64c19esdv13h2QBuMkL9ZfBbAfTzu3vehSTEQTyBEpe8BY/M/Ko/RmTvdmOKOFDuJ3G7MBeNtT04fOQ3foJoG+nU6T8cPw9bkO/4VgEBrwFdridUylfu9PhL6LHp7trac4SulEE43Nz8Hwx8UOWZE8RHGmGVXBRZOLKpPgTW2XXM6h5WV6Y5zeK0jve70nNHh1hQmdQD1YxsrzvFppz97WGx18/Y68dt/mNtwUpNAgMPJdSPxnK9ur0dsPo+ug6xiaoHutDpXGXf8H3w/uXyh4szGgbyONVFTZ2F9HEiICRBx74A/P9XXO8Pzp6utK/4cUkE3LhUOI2RJ7k411kUR+uXQO2xxNCr0OHD+KcEUUkRBMOYoymvAosoKuKkILQJy/6kKwvrx7M/rUv7z4ldyObm4t51l6iDpc9zLmXyHv0/Wbj6PrSK+/wbAaaYvY7Xsk2snUNmu9WZqPbQsno++9P4qZVSeYHIv5agPgBL+9rDizDrsUvNfRdzhAcRiiK9gjIRU5LtZqnvMzqPSheuNesT4G2ytjiBwplZLx756MGqzOKaZprM76/uLjxYfoYqd7dLuA4eRmBeA+73jW3qfqL603FBoBqe/CyC2s1f9ptSHOI9ZzHGoXvIGKVOZpipfAs1JBFJNjCv0FcsR/EzOIxfq03oF5W5/eB5Z2GHMFYV2Bm0G+nMxTOoPODsrB6vqs91/TTbLV"

# 1. video_bauen.py komplett ersetzen
Path('video_bauen.py').write_bytes(zlib.decompress(base64.b64decode(NEU_B64)))
print("video_bauen.py: neu (Bildwechsel gefixt, 6 Effekte, Untertitel)")

# 2. erstelle_video.py: Skript an den Videobau weiterreichen (fuer Untertitel)
p = Path('erstelle_video.py'); s = p.read_text(encoding='utf-8')
if 'skript=paket' not in s:
    s = s.replace('video = video_bauen.baue_video(kanal, bilder, ton, ordner / "video.mp4")',
                  'video = video_bauen.baue_video(kanal, bilder, ton, ordner / "video.mp4",\n'
                  '                                   skript=paket.get("skript", ""))')
    p.write_text(s, encoding='utf-8')
    print("erstelle_video.py: Untertitel-Text wird uebergeben")
else:
    print("erstelle_video.py: schon ok")

# 3. text_generator.py: Bilder muessen verschieden sein
p = Path('text_generator.py'); s = p.read_text(encoding='utf-8')
if 'JEDES Bild deutlich anders' not in s:
    regel = ('BILDER - SEHR WICHTIG: JEDES Bild deutlich anders! '
             'Wechsle bei jedem Bild Motiv, Ort, Perspektive (nah/weit/von oben), '
             'Tageszeit und Farbstimmung. Keine zwei aehnlichen Bilder. '
             'Jedes Bild zeigt einen anderen Moment der Geschichte. '
             'Beschreibungen auf Englisch, konkret und bildhaft, wie ein Foto. '
             'Schlecht: "money", "coins", "cash". '
             'Gut: "close-up hands counting euro bills on wooden kitchen table", '
             '"wide shot of glass bank tower at sunset, city street", '
             '"overhead view of piggy bank and laptop on white desk", '
             '"person pushing cart through bright supermarket aisle".\n\n')
    for marke in ['Antworte NUR mit JSON', 'WICHTIG: Fasse dich KURZ',
                  'BILDER', 'AUFGABE:', 'REGELN:']:
        if marke in s:
            s = s.replace(marke, regel + marke, 1)
            p.write_text(s, encoding='utf-8')
            print(f"text_generator.py: Bildvielfalt-Regel eingebaut")
            break
    else:
        print("WARNUNG: Einbaustelle fuer Bildregel nicht gefunden")
else:
    print("text_generator.py: schon ok")
print("FERTIG")
