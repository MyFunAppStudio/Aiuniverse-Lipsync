# Patch 9: Bildstil + Stimm-Einstellungen im Dashboard
from pathlib import Path

# --- 1. einstellungen.py: neue Felder ---
p = Path('einstellungen.py'); s = p.read_text(encoding='utf-8')
if '"bildstil"' not in s:
    stil_a = ('cinematic dark photography, moody atmosphere, deep shadows, '
              'film grain, muted colors, dramatic lighting, 35mm look')
    stil_b = ('bright colorful modern flat illustration, bold shapes, '
              'vibrant orange and teal palette, clean vector style, '
              'finance symbols (coins, rising charts, wallet, piggy bank), '
              'happy relatable people, optimistic and energetic mood, '
              'eye-catching social media graphic')
    # Kanal A
    s = s.replace('''        "mit_avatar": True,
        "prompt": _prompt_a(),''',
        f'''        "mit_avatar": True,
        "bildstil": "{stil_a}",
        "stimme_id": "",
        "stimme_energie": 0.55,
        "prompt": _prompt_a(),''')
    # Kanal B
    s = s.replace('''        "mit_avatar": False,
        "prompt": _prompt_b(),''',
        f'''        "mit_avatar": False,
        "bildstil": "{stil_b}",
        "stimme_id": "",
        "stimme_energie": 0.85,
        "prompt": _prompt_b(),''')
    p.write_text(s, encoding='utf-8')
    print("einstellungen.py: Bildstil + Stimme ergaenzt")
else:
    print("einstellungen.py: schon ok")

# --- 2. medien.py: Bildstil anhaengen, Stimme steuern ---
p = Path('medien.py'); s = p.read_text(encoding='utf-8')
if 'bildstil' not in s:
    s = s.replace('''    def eins(paar):
        i, prompt = paar''',
'''    stil = (kanal.get("bildstil") or "").strip()

    def eins(paar):
        i, prompt = paar
        if stil:
            prompt = f"{prompt}. Style: {stil}"''')
    s = s.replace('''    daten = {"text": text}
    if stimme_id:
        daten["voice"] = stimme_id''',
'''    daten = {"text": text}
    stimme_id = stimme_id or kanal.get("stimme_id") or ""
    if stimme_id:
        daten["voice"] = stimme_id
    energie = float(kanal.get("stimme_energie", 0.6))
    # hohe Energie = lebendiger, niedrige = ruhiger/gleichmaessiger
    daten["stability"] = max(0.0, min(1.0, 1.0 - energie))
    daten["similarity_boost"] = 0.75
    daten["style"] = max(0.0, min(1.0, energie))''')
    p.write_text(s, encoding='utf-8')
    print("medien.py: Bildstil + Stimm-Energie eingebaut")
else:
    print("medien.py: schon ok")

# --- 3. dashboard.py: Felder im Einstellungen-Tab ---
p = Path('dashboard.py'); s = p.read_text(encoding='utf-8')
if 'Bildstil' not in s:
    marke = """  h+='<div class="karte"><h2>Telegram</h2><div class="inh">'"""
    neu = """
'''  h+='<div class="karte"><h2>Bildstil</h2><div class="inh">'
    +'<div class="mini" style="margin-bottom:8px">Wird an JEDE Bildbeschreibung angehaengt. Bestimmt den Look: realistisch, Illustration, Cartoon, duester...</div>'
    +'<textarea style="min-height:90px" onchange="setz(\\''+kid+'\\',\\'bildstil\\',this.value)">'+esc(k.bildstil||'')+'</textarea>'
    +'<div class="mini">Beispiele: "bright colorful flat illustration, finance symbols, happy people" oder "cinematic dark photography, moody, film grain"</div>'
    +'</div></div>';

  h+='<div class="karte"><h2>Stimme</h2><div class="inh">'
    +'<div class="feld"><div class="lbl">Stimm-ID oder Name (ElevenLabs)</div>'
    +'<input type="text" value="'+esc(k.stimme_id||'')+'" placeholder="leer = Standardstimme" onchange="setz(\\''+kid+'\\',\\'stimme_id\\',this.value)"></div>'
    +'<div class="feld"><div class="lbl">Energie / Ausdruck</div>'
    +'<input type="range" min="0" max="100" value="'+Math.round((k.stimme_energie||0.6)*100)+'" '
    +'oninput="document.getElementById(\\'se\\').textContent=this.value" '
    +'onchange="setz(\\''+kid+'\\',\\'stimme_energie\\',parseInt(this.value)/100)">'
    +'<div class="mini"><b id="se">'+Math.round((k.stimme_energie||0.6)*100)+'</b>% - hoch = lebendig und schwungvoll, niedrig = ruhig und gleichmaessig</div></div>'
    +'<div class="mini">Stimmen anhoeren und ID holen: elevenlabs.io -> Voice Library</div>'
    +'</div></div>';

  h+='<div class="karte"><h2>Telegram</h2><div class="inh">'"""
    if marke in s:
        s = s.replace(marke, neu, 1)
        p.write_text(s, encoding='utf-8')
    print("dashboard.py: Bildstil + Stimme im Dashboard")
else:
    print("dashboard.py: schon ok")
print("FERTIG")
