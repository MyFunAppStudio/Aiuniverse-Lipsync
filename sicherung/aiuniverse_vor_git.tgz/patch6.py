# Patch 6: Bilder parallel (viel schneller) + Slider steuert Videolaenge
from pathlib import Path

# --- 1. medien.py: alle Bilder gleichzeitig erzeugen ---
p = Path('medien.py'); s = p.read_text(encoding='utf-8')
if 'ThreadPoolExecutor' not in s:
    s = s.replace('import config\n', 'import config\nfrom concurrent.futures import ThreadPoolExecutor\n', 1)

    alt_start = s.find('def erzeuge_bilder(')
    alt_ende = s.find('\ndef ', alt_start + 10)
    if alt_start > 0 and alt_ende > alt_start:
        neu = '''def erzeuge_bilder(kanal, bild_prompts, ordner):
    """Erzeugt alle Bilder GLEICHZEITIG (viel schneller)."""
    ordner = Path(ordner)
    ordner.mkdir(parents=True, exist_ok=True)

    if config.TESTMODUS:
        pfade = []
        for i in range(len(bild_prompts)):
            ziel = ordner / f"bild_{i:03d}.jpg"
            _test_bild(ziel, i)
            pfade.append(ziel)
        print(f"[Bild] {len(pfade)} Test-Bilder")
        return pfade

    api = einstellungen.aktive_api(kanal, "bilder") or {}
    name = api.get("name", "?")
    url = api.get("url") or FAL_BILD
    schluessel = api.get("key")
    gesamt = len(bild_prompts)
    print(f"[Bild] {gesamt} Bilder gleichzeitig ({name})...")

    def eins(paar):
        i, prompt = paar
        ziel = ordner / f"bild_{i:03d}.jpg"
        try:
            ergebnis = _fal_anfrage(url, {
                "prompt": prompt,
                "image_size": "landscape_16_9",
                "num_images": 1,
            }, schluessel)
            _lade_datei(ergebnis["images"][0]["url"], ziel)
            print(f"[Bild] {i+1}/{gesamt} fertig")
            return ziel
        except Exception as f:
            print(f"[Bild] {i+1}/{gesamt} FEHLER: {str(f)[:120]}")
            return None

    with ThreadPoolExecutor(max_workers=6) as pool:
        ergebnisse = list(pool.map(eins, enumerate(bild_prompts)))

    pfade = [x for x in ergebnisse if x]
    print(f"[Bild] {len(pfade)}/{gesamt} erfolgreich")
    if not pfade:
        raise RuntimeError("Kein einziges Bild konnte erzeugt werden")
    return pfade

'''
        s = s[:alt_start] + neu + s[alt_ende + 1:]
        p.write_text(s, encoding='utf-8')
        print("medien.py: Bilder laufen jetzt parallel (6 gleichzeitig)")
    else:
        print("WARNUNG: erzeuge_bilder nicht gefunden")
else:
    print("medien.py: schon parallel")

# --- 2. text_generator.py: Laenge steuert die Textmenge ---
p = Path('text_generator.py'); s = p.read_text(encoding='utf-8')
if 'ZEICHEN_PRO_SEKUNDE' not in s:
    s = s.replace('import einstellungen',
                  'import einstellungen\n\nZEICHEN_PRO_SEKUNDE = 15  # gesprochene Zeichen pro Sekunde', 1)
    # Laenge sauber aus den Dashboard-Einstellungen holen
    s = s.replace('    laenge = kanal.get("laenge_min") or (kanal.get("laenge_sek", 60) / 60)',
                  '    laenge = einstellungen.laenge_in_minuten(kanal)')
    alt = 'Laenge: ca. {laenge:.1f} Minuten'
    if alt in s:
        s = s.replace(alt,
            'Laenge: ca. {laenge*60:.0f} Sekunden gesprochen\\n'
            'Das SKRIPT muss daher ca. {int(laenge*60*ZEICHEN_PRO_SEKUNDE)} Zeichen haben '
            '(plus/minus 15 Prozent). Halte dich genau daran!')
        s = s.replace('WICHTIG: Fasse dich KURZ. Skript maximal 1200 Zeichen. ', '')
        s = s.replace('Skript maximal 1200 Zeichen. ', '')
        p.write_text(s, encoding='utf-8')
        print("text_generator.py: Slider steuert jetzt die Skriptlaenge")
    else:
        print("WARNUNG: Laengen-Zeile nicht gefunden")
else:
    print("text_generator.py: schon ok")
print("FERTIG")
