import os, shutil, subprocess, sys
B = "/root/aiuniverse"

# ---------- 1. Server: Kacheln schauen auch in die Kanal-Modelle ----------
p = os.path.join(B, "dashboard2.py")
t = open(p, encoding="utf-8").read()
if "def api_stand(key=None)" in t:
    print("INFO  Server: Kachel-Fix war schon drin")
else:
    alt = '''def api_stand():
    return {
        "text": bool(schluessel("ANTHROPIC")),
        "bilder": bool(schluessel("FAL")),
        "stimme": bool(schluessel("FAL") or schluessel("ELEVEN")),
        "avatar": bool(schluessel("HEDRA")),
        "animation": bool(schluessel("KLING")),
    }'''
    neu = '''def _slot_stand(key, slot, *teile):
    eintraege = []
    try:
        eintraege = ((einstellungen.laden().get(key) or {}).get("apis") or {}).get(slot) or []
    except Exception:
        eintraege = []
    aktiv = None
    for e in eintraege:
        if isinstance(e, dict) and e.get("aktiv"):
            aktiv = e
            break
    if aktiv is not None:
        if (aktiv.get("key") or "").strip():
            return True, (aktiv.get("name") or "").strip()
        for teil in teile:
            if schluessel(teil):
                return True, (aktiv.get("name") or "").strip()
        return False, ""
    for e in eintraege:
        if isinstance(e, dict) and (e.get("key") or "").strip():
            return True, (e.get("name") or "").strip()
    for teil in teile:
        if schluessel(teil):
            return True, ""
    return False, ""


def api_stand(key=None):
    paare = [("text", "text", ("ANTHROPIC", "OPENAI")),
             ("bilder", "bilder", ("FAL",)),
             ("stimme", "stimme", ("FAL", "ELEVEN")),
             ("avatar", "avatar", ("HEDRA",)),
             ("animation", "video", ("KLING",))]
    raus = {}
    for name, slot, teile in paare:
        ok, wie = _slot_stand(key, slot, *teile)
        raus[name] = ok
        raus[name + "_name"] = wie
    return raus'''
    if alt not in t:
        print("ACHT  api_stand nicht gefunden - nichts geaendert")
        raise SystemExit(1)
    shutil.copy2(p, p + ".bak_m4")
    t = t.replace(alt, neu, 1)
    if '"apis": api_stand(),' not in t:
        shutil.copy2(p + ".bak_m4", p)
        print("ACHT  Aufruf von api_stand nicht gefunden - nichts geaendert")
        raise SystemExit(1)
    t = t.replace('"apis": api_stand(),', '"apis": api_stand(k),', 1)
    open(p, "w", encoding="utf-8").write(t)
    r = subprocess.run([sys.executable, "-m", "py_compile", p], capture_output=True, text=True)
    if r.returncode:
        shutil.copy2(p + ".bak_m4", p)
        print("ACHT  Server zurueckgesetzt:", r.stderr[-200:])
        raise SystemExit(1)
    print("OK    Server: Kacheln kennen jetzt die Kanal-Modelle")

# ---------- 2. Oberflaeche: Kachel zeigt den Namen des aktiven Modells ----------
p2 = os.path.join(B, "dashboard2.html")
h = open(p2, encoding="utf-8").read()
if "a.text_name" in h:
    print("INFO  Oberflaeche: Kachel-Fix war schon drin")
else:
    tausch = [
     ('kachel("Text",a.text?"Claude":"fehlt",a.text)+',
      'kachel("Text",a.text?kurz(a.text_name,"Claude"):"fehlt",a.text)+'),
     ('kachel("Bild",a.bilder?"Flux":"fehlt",a.bilder)+',
      'kachel("Bild",a.bilder?kurz(a.bilder_name,"Flux"):"fehlt",a.bilder)+'),
     ('kachel("Stimme",a.stimme?"bereit":"fehlt",a.stimme)+',
      'kachel("Stimme",a.stimme?kurz(a.stimme_name,"bereit"):"fehlt",a.stimme)+'),
     ('function kachel(t,w,ok){',
      'function kurz(n,fallback){n=(n||"").trim();return n?n:fallback}\nfunction kachel(t,w,ok){'),
     ('.stand{display:grid;grid-template-columns:repeat(4,1fr);gap:7px;margin-top:12px}',
      '.stand{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:7px;margin-top:12px}'),
     ('.stand .w{font-size:11.5px;font-weight:600;margin-top:4px}',
      '.stand .w{font-size:11.5px;font-weight:600;margin-top:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}'),
     ('      api("/api/preis?k="+S.kanal).then(function(x){S.preis=x})\n    ]).then(zeichne);',
      '      api("/api/preis?k="+S.kanal).then(function(x){S.preis=x}),\n      api("/api/stand?k="+S.kanal).then(function(x){S.daten.apis=x.apis})\n    ]).then(function(){zeigeKopf();zeichne()});'),
    ]
    for a, b in tausch:
        if a not in h:
            print("ACHT  Stelle nicht gefunden - nichts geaendert:", a[:40])
            raise SystemExit(1)
    shutil.copy2(p2, p2 + ".bak_m4")
    for a, b in tausch:
        h = h.replace(a, b, 1)
    open(p2, "w", encoding="utf-8").write(h)
    print("OK    Oberflaeche: Kacheln zeigen das aktive Modell")
print("TEIL 4 FERTIG")
