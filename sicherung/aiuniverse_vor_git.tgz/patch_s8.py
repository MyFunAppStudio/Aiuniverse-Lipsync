# -*- coding: utf-8 -*-
import os, shutil, subprocess, sys
B = "/root/aiuniverse"
fehler = []


def tausche(datei, paare, merkmal, pruefen=True):
    p = os.path.join(B, datei)
    t = open(p, encoding="utf-8").read()
    if merkmal in t:
        print("INFO  %s war schon angepasst" % datei)
        return
    for alt, neu in paare:
        if alt not in t:
            print("ACHT  %s: Stelle nicht gefunden -> %r" % (datei, alt[:46]))
            fehler.append(datei)
            return
    shutil.copy2(p, p + ".bak_s8")
    for alt, neu in paare:
        t = t.replace(alt, neu, 1)
    open(p, "w", encoding="utf-8").write(t)
    if pruefen:
        r = subprocess.run([sys.executable, "-m", "py_compile", p], capture_output=True, text=True)
        if r.returncode:
            shutil.copy2(p + ".bak_s8", p)
            print("ACHT  %s zurueckgesetzt: %s" % (datei, r.stderr[-150:]))
            fehler.append(datei)
            return
    print("OK    %s" % datei)


# ---------- 1. Preis kennt jetzt den Szenen-Modus ----------
ALT_P = '''def preis(key):
    d = einstellungen.laden().get(key) or {}
    try:
        sek = float(d.get("laenge") or 20)
    except Exception:
        sek = 20.0'''

NEU_P = '''def preis_szenen(key, d):
    """Eigene Szenen: keine Bilder, kein Skript - nur die Stimme kostet."""
    try:
        daten = szenen.fuer_anzeige(key)
    except Exception:
        daten = {"szenen": []}
    gesamt_sek, sprech_sek, gesprochen = 0.0, 0.0, 0
    for s in daten.get("szenen", []):
        vor = float(s.get("vorschlag") or 3)
        if s.get("gesprochen") and (s.get("text") or "").strip():
            gesamt_sek += vor
            sprech_sek += vor
            gesprochen += 1
        else:
            gesamt_sek += float(s.get("sekunden") or vor)
    stimme = round(sprech_sek * modell_preis(key, "stimme", 0.008), 3)
    return {"bilder": 0, "je_bild": 0.0, "text": 0.0, "stimme": stimme,
            "gesamt": round(stimme, 3), "modus": "szenen",
            "szenen": len(daten.get("szenen", [])), "gesprochen": gesprochen,
            "sekunden": round(gesamt_sek, 1)}


def preis(key):
    d = einstellungen.laden().get(key) or {}
    if d.get("modus") == "szenen":
        return preis_szenen(key, d)
    try:
        sek = float(d.get("laenge") or 20)
    except Exception:
        sek = 20.0'''

ALT_R = '''    return {"bilder": bilder, "je_bild": p_bild, "text": text,
            "stimme": stimme, "gesamt": gesamt}'''
NEU_R = '''    return {"bilder": bilder, "je_bild": p_bild, "text": text,
            "stimme": stimme, "gesamt": gesamt, "modus": "auto",
            "sekunden": round(sek, 1)}'''

tausche("dashboard2.py", [(ALT_P, NEU_P), (ALT_R, NEU_R)], "def preis_szenen")

# ---------- 2. Oberflaeche: Kostenkarte und Auffrischen ----------
ALT_K = '''  var o='<div class="karte p"><h2 class="kt">Was ein Video kostet</h2>'
   +'<div class="r" style="padding-top:0"><div class="lb">Text</div><div class="zahl">'+(p.text||0).toFixed(2)+' €</div></div>'
   +'<div class="r"><div class="lb">'+(p.bilder||0)+' Bilder</div><div class="zahl">'+(((p.bilder||0)*(p.je_bild||0))||0).toFixed(2)+' €</div></div>'
   +'<div class="r"><div class="lb">Stimme</div><div class="zahl">'+(p.stimme||0).toFixed(2)+' €</div></div>'
   +'<div class="r"><div class="lb"><b>Zusammen</b></div><div class="zahl"><b>'+(p.gesamt||0).toFixed(2)+' €</b></div></div></div>';'''

NEU_K = '''  var o='<div class="karte p"><h2 class="kt">Was ein Video kostet</h2>';
  if(p.modus==="szenen"){
    o+='<div class="r" style="padding-top:0"><div><div class="lb">'+(p.szenen||0)+' eigene Szenen</div>'
      +'<div class="hint">deine Bilder und Texte kosten nichts</div></div><div class="zahl">0.00 €</div></div>'
      +'<div class="r"><div><div class="lb">Stimme</div><div class="hint">'+(p.gesprochen||0)+' gesprochene Szenen</div></div>'
      +'<div class="zahl">'+(p.stimme||0).toFixed(2)+' €</div></div>'
      +'<div class="r"><div class="lb"><b>Zusammen</b></div><div class="zahl"><b>'+(p.gesamt||0).toFixed(2)+' €</b></div></div>'
      +'<div class="hinw" style="margin-top:8px">Länge etwa '+(p.sekunden||0)+' Sekunden, ergibt sich aus den Szenen.</div></div>';
  }else{
    o+='<div class="r" style="padding-top:0"><div class="lb">Text</div><div class="zahl">'+(p.text||0).toFixed(2)+' €</div></div>'
      +'<div class="r"><div class="lb">'+(p.bilder||0)+' Bilder</div><div class="zahl">'+(((p.bilder||0)*(p.je_bild||0))||0).toFixed(2)+' €</div></div>'
      +'<div class="r"><div class="lb">Stimme</div><div class="zahl">'+(p.stimme||0).toFixed(2)+' €</div></div>'
      +'<div class="r"><div class="lb"><b>Zusammen</b></div><div class="zahl"><b>'+(p.gesamt||0).toFixed(2)+' €</b></div></div>'
      +'<div class="hinw" style="margin-top:8px">Bei '+(p.sekunden||0)+' Sekunden. Ändert sich mit Länge und Bildern pro Minute.</div></div>';
  }'''

tausche("dashboard2.html", [
    (ALT_K, NEU_K),
    ('function ladeSzenen(){return api("/api/szenen?k="+S.kanal).then(function(d){S.szenen=d;zeichne()})}',
     'function ladeSzenen(){return api("/api/szenen?k="+S.kanal).then(function(d){S.szenen=d;\n'
     '  return api("/api/preis?k="+S.kanal).then(function(x){S.preis=x;zeichne()})})}'),
    ('''    if(feld==="laenge"||feld==="bilder_pro_minute"||feld==="stimme_an"){''',
     '''    if(["laenge","bilder_pro_minute","stimme_an","modus","vorlage","format"].indexOf(feld)>=0){'''),
], "p.modus===\"szenen\"", pruefen=False)

print()
print("NICHT FERTIG:", ", ".join(sorted(set(fehler))) if fehler else "alles durch")
print("TEIL 8 FERTIG")
